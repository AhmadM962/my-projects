package models;

public class Locker {
    private String studentID;
    private String lockerNumber;

    public Locker(String studentID, String lockerNumber) {
        this.studentID = studentID;
        this.lockerNumber = lockerNumber;
    }

    public String getStudentID() {
        return studentID;
    }

    public String getLockerNumber() {
        return lockerNumber;
    }

    @Override
    public String toString() {
        return "Student ID: " + studentID + ", Locker: " + lockerNumber;
    }
}
