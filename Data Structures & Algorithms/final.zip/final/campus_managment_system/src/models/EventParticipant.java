package models;

public class EventParticipant {
    private String name;
    private String studentID;

    public EventParticipant(String name, String studentID) {
        this.name = name;
        this.studentID = studentID;
    }

    @Override
    public String toString() {
        return "Student Name: " + name + ", ID: " + studentID;
    }
}
