package models;

import java.util.UUID;

public class LostFoundItem {
    private String id;
    private String description;
    private String date;
    private String location;

    public LostFoundItem(String description, String date, String location) {
        this.id = UUID.randomUUID().toString();  // Generate a unique ID for each item
        this.description = description;
        this.date = date;
        this.location = location;
    }

    public String getId() {
        return id;
    }

    public String getDescription() {
        return description;
    }

    public String getDate() {
        return date;
    }

    public String getLocation() {
        return location;
    }

    @Override
    public String toString() {
        return "ID: " + id + ", Description: " + description + ", Date: " + date + ", Location: " + location;
    }
}
