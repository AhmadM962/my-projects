package models;

public class BookingRequest {
    private String studentName;
    private String roomNumber;
    private int priority;

    public BookingRequest(String studentName, String roomNumber, int priority) {
        this.studentName = studentName;
        this.roomNumber = roomNumber;
        this.priority = priority;
    }

    public int getPriority() {
        return priority;
    }

    @Override
    public String toString() {
        return "Student: " + studentName + ", Room: " + roomNumber + ", Priority: " + priority;
    }
}
