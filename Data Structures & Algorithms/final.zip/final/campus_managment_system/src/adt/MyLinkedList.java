package adt;

public class MyLinkedList<T> {
    protected Node<T> head;

    public MyLinkedList() {
        head = null;
    }

    // Add a node to the list
    public void add(T data) {
        Node<T> newNode = new Node<>(data);
        if (head == null) {
            head = newNode;
        } else {
            Node<T> curr = head;
            while (curr.next != null) {
                curr = curr.next;
            }
            curr.next = newNode;
        }
    }

    // Remove a specific node based on its value (object equality)
    public boolean removeExact(T data) {
        if (head == null) return false;

        Node<T> curr = head;
        Node<T> prev = null;

        while (curr != null) {
            if (curr.data.equals(data)) {
                if (prev == null) {
                    head = curr.next;  // If it's the head node, we move head to the next
                } else {
                    prev.next = curr.next;  // Remove the node from the list
                }
                return true;
            }
            prev = curr;
            curr = curr.next;
        }
        return false; // Return false if the item wasn't found
    }

    public T remove() {
        if (head == null) return null;

        T data = head.data;  // Store the data of the node to be removed
        head = head.next;  // Move the head to the next node (removes the first node)
        return data;       // Return the data of the removed node
    }


    // Display all nodes
    public void display() {
        if (head == null) {
            System.out.println("List is empty.");
            return;
        }

        Node<T> curr = head;
        while (curr != null) {
            System.out.println(curr.data);
            curr = curr.next;
        }
    }

    public boolean isEmpty() {
        return head == null;
    }

    // Peek at the first node
    public T peek() {
        return head != null ? head.data : null;
    }
}
