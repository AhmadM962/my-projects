package adt;

import models.Locker;

public class MyBST {
    private Node root;

    private class Node {
        Locker locker;
        Node left, right;

        public Node(Locker locker) {
            this.locker = locker;
        }
    }

    // Insert locker based on student ID
    public void insert(Locker locker) {
        if (locker == null || locker.getStudentID() == null) {
            System.out.println("Error: Locker or student ID cannot be null.");
            return;
        }
        root = insertRec(root, locker);
    }

    private Node insertRec(Node root, Locker locker) {
        if (root == null) {
            root = new Node(locker);
            return root;
        }

        if (locker.getStudentID().compareTo(root.locker.getStudentID()) < 0) {
            root.left = insertRec(root.left, locker);
        } else if (locker.getStudentID().compareTo(root.locker.getStudentID()) > 0) {
            root.right = insertRec(root.right, locker);
        }
        return root;
    }

    // Search locker by student ID
    public Locker search(String studentID) {
        if (studentID == null || studentID.isEmpty()) {
            System.out.println("Error: Invalid student ID.");
            return null;
        }
        Node result = searchRec(root, studentID);
        return result == null ? null : result.locker;
    }

    private Node searchRec(Node root, String studentID) {
        if (root == null || root.locker.getStudentID().equals(studentID)) {
            return root;
        }

        if (studentID.compareTo(root.locker.getStudentID()) < 0) {
            return searchRec(root.left, studentID);
        }
        return searchRec(root.right, studentID);
    }

    // Delete locker by student ID
    public void delete(String studentID) {
        if (studentID == null || studentID.isEmpty()) {
            System.out.println("Error: Invalid student ID.");
            return;
        }
        root = deleteRec(root, studentID);
    }

    private Node deleteRec(Node root, String studentID) {
        if (root == null) return root;

        if (studentID.compareTo(root.locker.getStudentID()) < 0) {
            root.left = deleteRec(root.left, studentID);
        } else if (studentID.compareTo(root.locker.getStudentID()) > 0) {
            root.right = deleteRec(root.right, studentID);
        } else {
            if (root.left == null) {
                return root.right;
            } else if (root.right == null) {
                return root.left;
            }

            root.locker = minValue(root.right);
            root.right = deleteRec(root.right, root.locker.getStudentID());
        }
        return root;
    }

    private Locker minValue(Node root) {
        Locker minValue = root.locker;
        while (root.left != null) {
            minValue = root.left.locker;
            root = root.left;
        }
        return minValue;
    }

    // In-order traversal
    public void inorder() {
        inorderRec(root);
    }

    private void inorderRec(Node root) {
        if (root != null) {
            inorderRec(root.left);
            System.out.println(root.locker);
            inorderRec(root.right);
        }
    }
}
