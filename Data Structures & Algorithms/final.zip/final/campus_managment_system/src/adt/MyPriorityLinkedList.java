package adt;

import models.BookingRequest;

public class MyPriorityLinkedList {
    private MyLinkedList<BookingRequest> list = new MyLinkedList<>(); // Using MyLinkedList as the underlying structure

    // Insert a booking request based on priority using Insertion Sort
    public void insert(BookingRequest data) {
        if (list.isEmpty()) {
            list.add(data);
        } else {
            Node<BookingRequest> newNode = new Node<>(data);
            Node<BookingRequest> curr = list.head;
            Node<BookingRequest> prev = null;

            // Traverse the list and find the correct position based on priority
            while (curr != null && curr.data.getPriority() >= data.getPriority()) {
                prev = curr;
                curr = curr.next;
            }

            if (prev == null) {
                // Insert at the beginning (highest priority)
                newNode.next = list.head;
                list.head = newNode;
            } else {
                // Insert after the 'prev' node
                newNode.next = prev.next;
                prev.next = newNode;
            }
        }
    }

    // Remove the highest priority request (first item in the list)
    public BookingRequest removeHighestPriority() {
        if (list.isEmpty()) return null;
        BookingRequest data = list.peek();
        list.removeExact(data); // Call removeExact() from MyLinkedList
        return data;
    }

    // New method to remove booking request by using MyLinkedList's removeExact()
    public boolean removeBookingRequest(BookingRequest request) {
        return list.removeExact(request); // This calls MyLinkedList's removeExact()
    }

    public boolean isEmpty() {
        return list.isEmpty(); // Use MyLinkedList's isEmpty method
    }

    public void display() {
        list.display(); // Use MyLinkedList's display method
    }
}
