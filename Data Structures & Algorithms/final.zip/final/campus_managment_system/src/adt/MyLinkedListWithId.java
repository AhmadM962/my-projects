package adt;

import models.LostFoundItem;

public class MyLinkedListWithId extends MyLinkedList<LostFoundItem> {

    // Method to remove an item by ID
    public boolean removeById(String id) {
        if (head == null) return false;

        Node<LostFoundItem> curr = head;
        Node<LostFoundItem> prev = null;

        while (curr != null) {
            // Compare ID for LostFoundItem
            if (curr.data.getId().equals(id)) {
                if (prev == null) {
                    head = curr.next;
                } else {
                    prev.next = curr.next;
                }
                return true; // Successfully removed the item
            }
            prev = curr;
            curr = curr.next;
        }
        return false; // Item not found
    }
}
