package adt;

public class MyQueue<T> {
    private MyLinkedList<T> list = new MyLinkedList<>(); // Using MyLinkedList

    // Enqueue an element
    public void enqueue(T data) {
        list.add(data); // Use MyLinkedList's add method
    }

    // Dequeue an element
    public T dequeue() {
        if (isEmpty()) return null;
        T data = list.peek(); // Peek the front item
        list.remove(); // Remove the front item
        return data;
    }

    // Check if the queue is empty
    public boolean isEmpty() {
        return list.isEmpty(); // Use MyLinkedList's isEmpty method
    }

    // Display the elements in the queue
    public void display() {
        list.display(); // Use MyLinkedList's display method
    }
}
