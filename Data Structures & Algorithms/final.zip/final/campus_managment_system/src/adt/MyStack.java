package adt;

public class MyStack<T> {
    private MyLinkedList<T> list = new MyLinkedList<>(); // Using MyLinkedList

    // Push an element onto the stack
    public void push(T data) {
        list.add(data); // Use MyLinkedList's add method
    }

    // Pop an element from the stack
    public T pop() {
        if (isEmpty()) return null;
        T data = list.peek(); // Peek the top item
        list.remove(); // Remove the top item
        return data;
    }

    // Peek at the top element of the stack
    public T peek() {
        return list.peek(); // Use MyLinkedList's peek method
    }

    // Check if the stack is empty
    public boolean isEmpty() {
        return list.isEmpty(); // Use MyLinkedList's isEmpty method
    }

    // Display the elements in the stack
    public void display() {
        list.display(); // Use MyLinkedList's display method
    }
}
