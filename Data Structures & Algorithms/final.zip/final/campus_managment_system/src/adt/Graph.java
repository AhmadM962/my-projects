package adt;

public class Graph {
    private String[] buildings;         // Array to store building names
    private int[][] adjacencyMatrix;    // Matrix to store the graph connections (edges)
    private int numVertices;            // Number of vertices (buildings)

    // Constructor to initialize the graph with the number of vertices
    public Graph(int numVertices) {
        this.numVertices = numVertices;
        adjacencyMatrix = new int[numVertices][numVertices]; // Initialize adjacency matrix
        buildings = new String[numVertices]; // Initialize building names array
    }

    // Add a building to the graph
    public void addBuilding(int index, String buildingName) {
        if (index < 0 || index >= numVertices) {
            System.out.println("Error: Invalid index.");
            return;
        }
        buildings[index] = buildingName;
    }

    // Connect two buildings with a distance (bi-directional edge)
    public void connectBuildings(int from, int to, int distance) {
        if (from < 0 || from >= numVertices || to < 0 || to >= numVertices) {
            System.out.println("Error: Invalid building indices.");
            return;
        }
        if (distance < 0) {
            System.out.println("Error: Distance cannot be negative.");
            return;
        }

        adjacencyMatrix[from][to] = distance;
        adjacencyMatrix[to][from] = distance; // Since the connection is bidirectional
    }

    // Find the shortest path using Dijkstra’s algorithm
    public void findShortestPath(int start, int end) {
        if (start < 0 || start >= numVertices || end < 0 || end >= numVertices) {
            System.out.println("Error: Invalid start or end building.");
            return;
        }

        int[] distances = new int[numVertices];    // Stores the shortest distance from start
        boolean[] visited = new boolean[numVertices]; // To mark visited buildings
        int[] previous = new int[numVertices];    // To track the previous building in the path

        // Initialize all distances to infinity, and previous nodes to -1
        for (int i = 0; i < numVertices; i++) {
            distances[i] = Integer.MAX_VALUE;
            previous[i] = -1;
        }
        distances[start] = 0; // Distance to start is 0

        // Dijkstra’s algorithm loop
        for (int count = 0; count < numVertices - 1; count++) {
            int u = minDistance(distances, visited); // Get the building with the minimum distance
            visited[u] = true;

            for (int v = 0; v < numVertices; v++) {
                if (!visited[v] && adjacencyMatrix[u][v] != 0 && distances[u] != Integer.MAX_VALUE &&
                        distances[u] + adjacencyMatrix[u][v] < distances[v]) {
                    distances[v] = distances[u] + adjacencyMatrix[u][v]; // Update the distance
                    previous[v] = u; // Update the previous building
                }
            }
        }

        // Print the shortest path and distance
        printPath(previous, start, end);
        System.out.println("Total distance: " + distances[end]);
    }

    // Helper method to find the building with the minimum distance
    private int minDistance(int[] distances, boolean[] visited) {
        int min = Integer.MAX_VALUE;
        int minIndex = -1;

        for (int v = 0; v < numVertices; v++) {
            if (!visited[v] && distances[v] <= min) {
                min = distances[v];
                minIndex = v;
            }
        }

        return minIndex;
    }

    // Helper method to print the shortest path from start to end
    private void printPath(int[] previous, int start, int end) {
        if (end == -1) {
            System.out.println("No path found.");
            return;
        }

        String path = "";
        for (int at = end; at != -1; at = previous[at]) {
            path = buildings[at] + " -> " + path;
        }

        System.out.println("Shortest path: " + path.substring(0, path.length() - 4)); // Remove last arrow
    }

    // Print the adjacency matrix representation of the graph
    public void printGraph() {
        System.out.println("Adjacency Matrix Representation:");
        for (int i = 0; i < numVertices; i++) {
            System.out.print("Building " + buildings[i] + " -> ");
            for (int j = 0; j < numVertices; j++) {
                if (adjacencyMatrix[i][j] != 0) {
                    System.out.print("[" + buildings[j] + " (Distance: " + adjacencyMatrix[i][j] + ")] ");
                }
            }
            System.out.println();
        }
    }
}
