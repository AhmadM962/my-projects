package features;

import adt.MyQueue;
import models.EventParticipant;

import java.util.Scanner;

public class EventRegistrationManager {
    private MyQueue<EventParticipant> queue = new MyQueue<>();
    private Scanner scanner = new Scanner(System.in);

    public void eventMenu() {
        int choice;
        do {
            System.out.println("\n--- Tech Talk Event Registration ---");
            System.out.println("1. Register Student");
            System.out.println("2. Admit Next Student");
            System.out.println("3. View Registration Queue");
            System.out.println("0. Back to Main Menu");
            System.out.print("Enter choice: ");
            choice = scanner.nextInt(); scanner.nextLine();

            switch (choice) {
                case 1: registerStudent(); break;
                case 2: admitNext(); break;
                case 3: queue.display(); break;
                case 0: break;
                default: System.out.println("Invalid choice.");
            }
        } while (choice != 0);
    }

    private void registerStudent() {
        System.out.print("Enter student name: ");
        String name = scanner.nextLine();
        System.out.print("Enter student ID: ");
        String id = scanner.nextLine();

        EventParticipant participant = new EventParticipant(name, id);
        queue.enqueue(participant);
        System.out.println("Student registered successfully.");
    }

    private void admitNext() {
        EventParticipant next = queue.dequeue();
        if (next == null) {
            System.out.println("No students waiting.");
        } else {
            System.out.println("Admitting: " + next);
        }
    }
}
