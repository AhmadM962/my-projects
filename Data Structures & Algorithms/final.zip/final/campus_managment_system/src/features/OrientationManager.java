package features;

import adt.Graph;
import java.util.Scanner;

public class OrientationManager {
    private Graph campusGraph = new Graph(6); // Assuming there are 6 buildings
    private Scanner scanner = new Scanner(System.in);

    // Buildings are indexed, starting from 0
    private String[] buildings = {
        "Library", "Engineering", "Cafeteria", "Science", "Gym", "Admin"
    };

    public OrientationManager() {
        setupCampusMap();
    }

    private void setupCampusMap() {
        // Add buildings with their indices
        for (int i = 0; i < buildings.length; i++) {
            campusGraph.addBuilding(i, buildings[i]); // Add building with index
        }

        // Add realistic connections (undirected) with indices instead of names
        campusGraph.connectBuildings(0, 1, 4); // Library -> Engineering
        campusGraph.connectBuildings(0, 3, 6); // Library -> Science
        campusGraph.connectBuildings(1, 3, 2); // Engineering -> Science
        campusGraph.connectBuildings(1, 2, 5); // Engineering -> Cafeteria
        campusGraph.connectBuildings(3, 2, 1); // Science -> Cafeteria
        campusGraph.connectBuildings(2, 4, 7); // Cafeteria -> Gym
        campusGraph.connectBuildings(4, 5, 3); // Gym -> Admin
        campusGraph.connectBuildings(3, 5, 9); // Science -> Admin
    }

    public void orientationMenu() {
        System.out.println("\n--- Student Orientation Help ---");
        System.out.println("Campus Buildings:");
        for (int i = 0; i < buildings.length; i++) {
            System.out.println((i + 1) + ". " + buildings[i]);
        }

        int startIndex = getChoice("Select START building (1-" + buildings.length + "): ") - 1;
        int endIndex = getChoice("Select DESTINATION building (1-" + buildings.length + "): ") - 1;

        // Check for invalid selections
        if (startIndex < 0 || endIndex < 0 || startIndex >= buildings.length || endIndex >= buildings.length) {
            System.out.println("Invalid building selections.");
            return;
        }

        String start = buildings[startIndex];
        String end = buildings[endIndex];

        System.out.println("\nFinding shortest path from " + start + " to " + end + "...");
        campusGraph.findShortestPath(startIndex, endIndex); // Pass indices to the graph method
    }

    private int getChoice(String prompt) {
        System.out.print(prompt);
        while (!scanner.hasNextInt()) {
            System.out.println("Invalid input. Please enter a number.");
            scanner.next(); // discard invalid
            System.out.print(prompt);
        }
        return scanner.nextInt();
    }
}
