package features;

import adt.MyBST;
import models.Locker;

import java.util.Scanner;

public class LockerManager {
    private MyBST lockerBST = new MyBST();
    private Scanner scanner = new Scanner(System.in);

    public void lockerMenu() {
        int choice;
        do {
            System.out.println("\n--- Locker Allocation Menu ---");
            System.out.println("1. Register Student for Locker");
            System.out.println("2. Look Up Locker by Student ID");
            System.out.println("3. Remove Student's Locker");
            System.out.println("4. View All Locker Allocations");
            System.out.println("0. Back to Main Menu");
            System.out.print("Enter choice: ");
            choice = scanner.nextInt(); scanner.nextLine();

            switch (choice) {
                case 1: registerLocker(); break;
                case 2: lookUpLocker(); break;
                case 3: removeLocker(); break;
                case 4: lockerBST.inorder(); break;
                case 0: break;
                default: System.out.println("Invalid choice.");
            }
        } while (choice != 0);
    }

    private void registerLocker() {
        String studentID;
        while (true) {
            System.out.print("Enter student ID: ");
            studentID = scanner.nextLine();
            try {
                Integer.parseInt(studentID);
                break;
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Student ID must be an integer.");
            }
        }

        String lockerNumber;
        while (true) {
            System.out.print("Enter locker number: ");
            lockerNumber = scanner.nextLine();
            try {
                Integer.parseInt(lockerNumber);
                break;
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Locker number must be an integer.");
            }
        }

        Locker locker = new Locker(studentID, lockerNumber);
        lockerBST.insert(locker);
        System.out.println("Locker assigned to student.");
    }

    private void lookUpLocker() {
        System.out.print("Enter student ID: ");
        String studentID = scanner.nextLine();
        Locker locker = lockerBST.search(studentID);

        if (locker != null) {
            System.out.println("Locker found: " + locker);
        } else {
            System.out.println("Locker not found for this student.");
        }
    }

    private void removeLocker() {
        System.out.print("Enter student ID to remove locker: ");
        String studentID = scanner.nextLine();
        lockerBST.delete(studentID);
        System.out.println("Locker removed for student.");
    }
}
