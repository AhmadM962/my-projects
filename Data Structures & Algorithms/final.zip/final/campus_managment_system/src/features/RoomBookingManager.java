package features;

import adt.MyPriorityLinkedList;
import models.BookingRequest;

import java.util.InputMismatchException;
import java.util.Scanner;

public class RoomBookingManager {
    private MyPriorityLinkedList bookingList = new MyPriorityLinkedList(); // Use MyPriorityLinkedList
    private Scanner scanner = new Scanner(System.in);
    private UndoRedoManager undoRedo = new UndoRedoManager(); // UndoRedoManager for undo/redo functionality

    public void roomBookingMenu() {
        int choice;
        do {
            System.out.println("\n--- Room Booking Menu ---");
            System.out.println("1. Request Booking");
            System.out.println("2. Process Highest Priority Booking");
            System.out.println("3. View All Requests");
            System.out.println("4. Undo Last Booking");
            System.out.println("5. Redo Last Booking");
            System.out.println("6. Show Undo Stack");
            System.out.println("7. Show Redo Stack");
            System.out.println("0. Back to Main Menu");
            System.out.print("Enter choice: ");
            choice = scanner.nextInt(); scanner.nextLine();

            switch (choice) {
                case 1: requestBooking(); break;
                case 2: processBooking(); break;
                case 3: bookingList.display(); break;
                case 4: undoBooking(); break;
                case 5: redoBooking(); break;
                case 6: undoRedo.showUndoStack(); break;
                case 7: undoRedo.showRedoStack(); break;
                case 0: break;
                default: System.out.println("Invalid choice.");
            }
        } while (choice != 0);
    }

    private void requestBooking() {
        System.out.print("Enter student name: ");
        String name = scanner.nextLine();

        String room;
        while (true) {
            System.out.print("Enter room number: ");
            room = scanner.nextLine();
            try {
                Integer.parseInt(room);
                break;
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Room number must be a valid integer.");
            }
        }

        int priority;
        while (true) {
            System.out.print("Enter priority (higher number = higher priority): ");
            try {
                priority = scanner.nextInt(); scanner.nextLine();
                break;
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Priority must be an integer.");
                scanner.nextLine(); // clear invalid input
            }
        }

        BookingRequest request = new BookingRequest(name, room, priority);
        bookingList.insert(request); // Insert the booking request in sorted order based on priority
        undoRedo.addAction(request); // Save to undo stack
        System.out.println("Booking request added.");
    }

    private void processBooking() {
        if (bookingList.isEmpty()) {
            System.out.println("No bookings to process.");
            return;
        }
        BookingRequest processed = bookingList.removeHighestPriority(); // Process the highest priority request
        System.out.println("Processed booking: " + processed);
    }

    private void undoBooking() {
        BookingRequest undone = undoRedo.undo(); // Get last undone request
        if (undone != null) {
            bookingList.removeBookingRequest(undone); // Use removeBookingRequest() to remove the exact booking request
            System.out.println("Undone booking: " + undone);
        } else {
            System.out.println("Nothing to undo.");
        }
    }

    private void redoBooking() {
        BookingRequest redone = undoRedo.redo(); // Get last redone request
        if (redone != null) {
            bookingList.insert(redone); // Reinsert the booking after redo
            System.out.println("Redone booking: " + redone);
        } else {
            System.out.println("Nothing to redo.");
        }
    }
}
