package features;

import adt.MyLinkedListWithId;
import models.LostFoundItem;
import java.util.Scanner;

public class LostFoundManager {
    private MyLinkedListWithId list = new MyLinkedListWithId();  // Use the new ADT
    private Scanner scanner = new Scanner(System.in);

    public void lostFoundMenu() {
        int choice;
        do {
            System.out.println("\n--- Lost & Found Menu ---");
            System.out.println("1. Add Item");
            System.out.println("2. Remove Item by ID");
            System.out.println("3. View All Items");
            System.out.println("0. Back to Main Menu");
            System.out.print("Enter choice: ");
            choice = scanner.nextInt(); scanner.nextLine();

            switch (choice) {
                case 1: addItem(); break;
                case 2: removeItem(); break;
                case 3: list.display(); break;
                case 0: break;
                default: System.out.println("Invalid choice.");
            }
        } while (choice != 0);
    }

    private void addItem() {
        System.out.print("Enter description: ");
        String desc = scanner.nextLine();
        System.out.print("Enter date (DD/MM/YYYY): ");
        String date = scanner.nextLine();
        System.out.print("Enter location: ");
        String location = scanner.nextLine();

        if (desc.isEmpty() || date.isEmpty() || location.isEmpty()) {
            System.out.println("Error: All fields must be filled.");
            return;
        }

        LostFoundItem item = new LostFoundItem(desc, date, location);
        list.add(item);
        System.out.println("Item added with ID: " + item.getId());
    }

    private void removeItem() {
        if (list.isEmpty()) {
            System.out.println("List is empty.");
            return;
        }

        // Allow the user to remove an item by its unique ID
        System.out.print("Enter ID to remove: ");
        String id = scanner.nextLine();

        if (id.isEmpty()) {
            System.out.println("Error: ID cannot be empty.");
            return;
        }

        boolean removed = list.removeById(id);  // Use the new removeById() method
        if (removed) {
            System.out.println("Item removed.");
        } else {
            System.out.println("Item not found with ID: " + id);
        }
    }
}
