package features;

import adt.MyStack;
import models.BookingRequest;

public class UndoRedoManager {
    private MyStack<BookingRequest> undoStack = new MyStack<>();
    private MyStack<BookingRequest> redoStack = new MyStack<>();

    public void addAction(BookingRequest request) {
        undoStack.push(request);
        redoStack = new MyStack<>(); // clear redo stack after new action
    }

    public BookingRequest undo() {
        if (undoStack.isEmpty()) return null;
        BookingRequest last = undoStack.pop();
        redoStack.push(last);
        return last;
    }

    public BookingRequest redo() {
        if (redoStack.isEmpty()) return null;
        BookingRequest last = redoStack.pop();
        undoStack.push(last);
        return last;
    }

    public void showUndoStack() {
        System.out.println("Undo Stack:");
        undoStack.display();
    }

    public void showRedoStack() {
        System.out.println("Redo Stack:");
        redoStack.display();
    }
}
