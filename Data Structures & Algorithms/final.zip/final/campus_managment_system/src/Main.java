import features.LostFoundManager;
import features.RoomBookingManager;
import features.OrientationManager;
import features.EventRegistrationManager;
import features.LockerManager;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        LostFoundManager lostFoundManager = new LostFoundManager();
        RoomBookingManager roomBookingManager = new RoomBookingManager();
        OrientationManager orientationManager = new OrientationManager();
        EventRegistrationManager eventManager = new EventRegistrationManager();
        LockerManager lockerManager = new LockerManager();

        int choice;
        do {
            System.out.println("\n=== Campus Management System ===");
            System.out.println("1. Lost & Found");
            System.out.println("2. Room Booking (with Undo/Redo)");
            System.out.println("3. Student Orientation Help");
            System.out.println("4. Event Participation Registration");
            System.out.println("5. Locker Allocation");
            System.out.println("0. Exit");
            System.out.print("Enter choice: ");
            while (!scanner.hasNextInt()) {
                System.out.println("Invalid input. Please enter a number.");
                scanner.next(); // discard invalid input
                System.out.print("Enter choice: ");
            }
            choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    lostFoundManager.lostFoundMenu();
                    break;
                case 2:
                    roomBookingManager.roomBookingMenu();
                    break;
                case 3:
                    orientationManager.orientationMenu();
                    break;
                case 4:
                    eventManager.eventMenu();
                    break;
                case 5:
                    lockerManager.lockerMenu();
                    break;
                case 0:
                    System.out.println("Goodbye!");
                    break;
                default:
                    System.out.println("Invalid choice.");
            }
        } while (choice != 0);
    }
}
