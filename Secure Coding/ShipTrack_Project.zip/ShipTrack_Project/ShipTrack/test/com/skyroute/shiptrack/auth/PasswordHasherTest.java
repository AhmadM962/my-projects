package com.skyroute.shiptrack.auth;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for {@link PasswordHasher}.
 *
 * <p>Quality principle (Ch. 2 — Testability): {@code PasswordHasher} has
 * no static state, so each test runs independently with no setup.
 */
class PasswordHasherTest1 {

    /** TC-PWD-01: salt randomness — same password must produce different hashes. */
    @Test
    void samePasswordYieldsDifferentHashes() throws Exception {
        char[] pwd = "Pass1!Word".toCharArray();
        String[] a = PasswordHasher.hashWithNewSalt(pwd);
        String[] b = PasswordHasher.hashWithNewSalt(pwd);

        assertNotEquals(a[0], b[0], "Each call must use a fresh salt");
        assertNotEquals(a[1], b[1], "Different salts must yield different hashes");
    }

    /** TC-PWD-02: positive case — verify() returns true for the original password. */
    @Test
    void verifyReturnsTrueForOriginalPassword() throws Exception {
        char[] pwd = "GoodSecret#1".toCharArray();
        String[] sh = PasswordHasher.hashWithNewSalt(pwd);
        assertTrue(PasswordHasher.verify("GoodSecret#1".toCharArray(), sh[0], sh[1]));
    }

    /** TC-PWD-03: negative case — verify() returns false for a wrong password. */
    @Test
    void verifyReturnsFalseForWrongPassword() throws Exception {
        char[] pwd = "GoodSecret#1".toCharArray();
        String[] sh = PasswordHasher.hashWithNewSalt(pwd);
        assertFalse(PasswordHasher.verify("WrongSecret#1".toCharArray(), sh[0], sh[1]));
    }

    /** TC-PWD-04: fail-secure — corrupted salt or hash never returns true. */
    @Test
    void verifyReturnsFalseOnCorruptStoredValues() {
        // Both arguments are deliberately invalid Base64.
        assertFalse(PasswordHasher.verify("anything".toCharArray(), "not-base64", "not-base64"));
    }

    /** TC-PWD-05: empty password is allowed by the hasher (policy enforces minimums). */
    @Test
    void emptyPasswordHashesAndVerifies() throws Exception {
        char[] pwd = "".toCharArray();
        String[] sh = PasswordHasher.hashWithNewSalt(pwd);
        assertTrue(PasswordHasher.verify("".toCharArray(), sh[0], sh[1]));
        assertFalse(PasswordHasher.verify("x".toCharArray(), sh[0], sh[1]));
    }

    /** TC-PWD-06: salt has the configured length. */
    @Test
    void newSaltHasConfiguredLength() {
        byte[] salt = PasswordHasher.newSalt();
        // SALT_LENGTH_BYTES is 16 in Constants.
        assertEquals(16, salt.length);
    }
}
