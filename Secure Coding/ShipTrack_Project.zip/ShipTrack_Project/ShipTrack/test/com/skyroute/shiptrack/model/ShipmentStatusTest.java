package com.skyroute.shiptrack.model;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for ShipmentStatus — the delivery state machine.
 *
 * Feature: Shipment Status State Machine
 * Class under test: ShipmentStatus
 *
 * Covers every allowed and every disallowed transition, all string parsing
 * variants, and all label values.
 *
 * Q9 test plan rows: TC-STAT-01 through TC-STAT-25
 */
class ShipmentStatusTest {

    // ══════════════════════════════════════════════════════════════════
    // TC-STAT-01..05  Legal transitions (canMoveTo returns true)
    // ══════════════════════════════════════════════════════════════════

    /** TC-STAT-01 */
    @Test
    void canMoveTo_pendingToPickedUp_isAllowed() {
        assertTrue(ShipmentStatus.PENDING.canMoveTo(ShipmentStatus.PICKED_UP));
    }

    /** TC-STAT-02 */
    @Test
    void canMoveTo_pendingToInTransit_isAllowed() {
        assertTrue(ShipmentStatus.PENDING.canMoveTo(ShipmentStatus.IN_TRANSIT));
    }

    /** TC-STAT-03 */
    @Test
    void canMoveTo_pickedUpToInTransit_isAllowed() {
        assertTrue(ShipmentStatus.PICKED_UP.canMoveTo(ShipmentStatus.IN_TRANSIT));
    }

    /** TC-STAT-04 */
    @Test
    void canMoveTo_pickedUpToDelivered_isAllowed() {
        assertTrue(ShipmentStatus.PICKED_UP.canMoveTo(ShipmentStatus.DELIVERED));
    }

    /** TC-STAT-05 */
    @Test
    void canMoveTo_inTransitToDelivered_isAllowed() {
        assertTrue(ShipmentStatus.IN_TRANSIT.canMoveTo(ShipmentStatus.DELIVERED));
    }

    // ══════════════════════════════════════════════════════════════════
    // TC-STAT-06..13  Illegal transitions (canMoveTo returns false)
    // ══════════════════════════════════════════════════════════════════

    /** TC-STAT-06 — PENDING → DELIVERED is a skip (not allowed) */
    @Test
    void canMoveTo_pendingToDelivered_isNotAllowed() {
        assertFalse(ShipmentStatus.PENDING.canMoveTo(ShipmentStatus.DELIVERED));
    }

    /** TC-STAT-07 — same-state transitions are never allowed */
    @Test
    void canMoveTo_sameState_isNeverAllowed() {
        for (ShipmentStatus s : ShipmentStatus.values()) {
            assertFalse(s.canMoveTo(s),
                    "Moving to the same state must not be allowed: " + s);
        }
    }

    /** TC-STAT-08 — PICKED_UP → PENDING is backward (not allowed) */
    @Test
    void canMoveTo_pickedUpToPending_isNotAllowed() {
        assertFalse(ShipmentStatus.PICKED_UP.canMoveTo(ShipmentStatus.PENDING));
    }

    /** TC-STAT-09 — IN_TRANSIT → PENDING is backward (not allowed) */
    @Test
    void canMoveTo_inTransitToPending_isNotAllowed() {
        assertFalse(ShipmentStatus.IN_TRANSIT.canMoveTo(ShipmentStatus.PENDING));
    }

    /** TC-STAT-10 — IN_TRANSIT → PICKED_UP is backward (not allowed) */
    @Test
    void canMoveTo_inTransitToPickedUp_isNotAllowed() {
        assertFalse(ShipmentStatus.IN_TRANSIT.canMoveTo(ShipmentStatus.PICKED_UP));
    }

    /**
     * TC-STAT-11 — DELIVERED is a terminal state; no outgoing transitions.
     * Quality principle: once a package is delivered it cannot go back.
     */
    @Test
    void canMoveTo_fromDelivered_allTargets_areNotAllowed() {
        assertFalse(ShipmentStatus.DELIVERED.canMoveTo(ShipmentStatus.PENDING));
        assertFalse(ShipmentStatus.DELIVERED.canMoveTo(ShipmentStatus.PICKED_UP));
        assertFalse(ShipmentStatus.DELIVERED.canMoveTo(ShipmentStatus.IN_TRANSIT));
        assertFalse(ShipmentStatus.DELIVERED.canMoveTo(ShipmentStatus.DELIVERED));
    }

    /** TC-STAT-12 — null target is never allowed from any state */
    @Test
    void canMoveTo_nullTarget_returnsFalseForAllStates() {
        for (ShipmentStatus s : ShipmentStatus.values()) {
            assertFalse(s.canMoveTo(null),
                    "canMoveTo(null) must return false for state: " + s);
        }
    }

    /** TC-STAT-13 — total allowed transitions: exactly 5 pairs */
    @Test
    void canMoveTo_totalAllowedTransitions_isExactlyFive() {
        int count = 0;
        for (ShipmentStatus from : ShipmentStatus.values()) {
            for (ShipmentStatus to : ShipmentStatus.values()) {
                if (from.canMoveTo(to)) count++;
            }
        }
        assertEquals(5, count,
                "The state machine must have exactly 5 allowed transitions");
    }

    // ══════════════════════════════════════════════════════════════════
    // TC-STAT-14..18  fromString — valid inputs (case and separator insensitivity)
    // ══════════════════════════════════════════════════════════════════

    /** TC-STAT-14 */
    @ParameterizedTest(name = "\"{0}\"")
    @ValueSource(strings = { "pending", "PENDING", "Pending" })
    void fromString_pendingVariants_parsesCorrectly(String s) {
        assertEquals(ShipmentStatus.PENDING, ShipmentStatus.fromString(s));
    }

    /** TC-STAT-15 */
    @ParameterizedTest(name = "\"{0}\"")
    @ValueSource(strings = { "picked up", "PICKED_UP", "picked_up", "picked-up", "Picked Up" })
    void fromString_pickedUpVariants_parsesCorrectly(String s) {
        assertEquals(ShipmentStatus.PICKED_UP, ShipmentStatus.fromString(s));
    }

    /** TC-STAT-16 */
    @ParameterizedTest(name = "\"{0}\"")
    @ValueSource(strings = { "in transit", "IN_TRANSIT", "in_transit", "in-transit", "IN TRANSIT" })
    void fromString_inTransitVariants_parsesCorrectly(String s) {
        assertEquals(ShipmentStatus.IN_TRANSIT, ShipmentStatus.fromString(s));
    }

    /** TC-STAT-17 */
    @ParameterizedTest(name = "\"{0}\"")
    @ValueSource(strings = { "delivered", "DELIVERED", "Delivered" })
    void fromString_deliveredVariants_parsesCorrectly(String s) {
        assertEquals(ShipmentStatus.DELIVERED, ShipmentStatus.fromString(s));
    }

    // ══════════════════════════════════════════════════════════════════
    // TC-STAT-18..19  fromString — invalid inputs
    // ══════════════════════════════════════════════════════════════════

    /** TC-STAT-18 — unrecognised strings throw IllegalArgumentException */
    @ParameterizedTest(name = "\"{0}\"")
    @ValueSource(strings = { "unknown", "dispatch", "sent", "", "   " })
    void fromString_invalidString_throwsIllegalArgumentException(String s) {
        assertThrows(IllegalArgumentException.class,
                () -> ShipmentStatus.fromString(s),
                "fromString must throw for unrecognised input: [" + s + "]");
    }

    /** TC-STAT-19 */
    @Test
    void fromString_null_throwsIllegalArgumentException() {
        assertThrows(IllegalArgumentException.class,
                () -> ShipmentStatus.fromString(null));
    }

    // ══════════════════════════════════════════════════════════════════
    // TC-STAT-20..23  label — human-readable lowercase representations
    // ══════════════════════════════════════════════════════════════════

    /** TC-STAT-20 */
    @Test
    void label_pending_isAllLowercaseNoUnderscore() {
        assertEquals("pending", ShipmentStatus.PENDING.label());
    }

    /** TC-STAT-21 */
    @Test
    void label_pickedUp_containsSpaceNotUnderscore() {
        assertEquals("picked up", ShipmentStatus.PICKED_UP.label());
    }

    /** TC-STAT-22 */
    @Test
    void label_inTransit_containsSpaceNotUnderscore() {
        assertEquals("in transit", ShipmentStatus.IN_TRANSIT.label());
    }

    /** TC-STAT-23 */
    @Test
    void label_delivered_isAllLowercase() {
        assertEquals("delivered", ShipmentStatus.DELIVERED.label());
    }

    // ══════════════════════════════════════════════════════════════════
    // TC-STAT-24..25  Enum completeness
    // ══════════════════════════════════════════════════════════════════

    /** TC-STAT-24 — the enum contains exactly 4 states */
    @Test
    void values_exactlyFourStatuses() {
        assertEquals(4, ShipmentStatus.values().length,
                "State machine must have exactly 4 states: PENDING, PICKED_UP, IN_TRANSIT, DELIVERED");
    }

    /** TC-STAT-25 — every status can be round-tripped through fromString(label()) */
    @Test
    void label_roundtripThroughFromString_forAllStatuses() {
        for (ShipmentStatus s : ShipmentStatus.values()) {
            assertEquals(s, ShipmentStatus.fromString(s.label()),
                    "fromString(label()) must return the original status for: " + s);
        }
    }
}