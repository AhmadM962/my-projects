package com.skyroute.shiptrack.util;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for {@link InputValidator}.
 *
 * <p>These are the foundation of every other security layer: if the
 * validator lets bad input through, the rest of the application is
 * undermined.
 */
class InputValidatorTest {

    /** TC-VAL-01: usernames with whitespace are rejected. */
    @Test
    void rejectsWhitespaceInUsername() {
        assertFalse(InputValidator.isValidUsername("john doe"));
    }

    /** TC-VAL-02: usernames with the field separator are rejected. */
    @Test
    void rejectsPipeInUsername() {
        assertFalse(InputValidator.isValidUsername("hack|er"));
    }

    /** TC-VAL-03: usernames that are too short are rejected. */
    @Test
    void rejectsTooShortUsername() {
        assertFalse(InputValidator.isValidUsername("ab"));
    }

    /** TC-VAL-04: well-formed usernames are accepted. */
    @Test
    void acceptsGoodUsernames() {
        assertTrue(InputValidator.isValidUsername("alice"));
        assertTrue(InputValidator.isValidUsername("alice.smith_42"));
        assertTrue(InputValidator.isValidUsername("user-1"));
    }

    /** TC-VAL-05: storage-safe rejects strings with newlines or pipes. */
    @Test
    void storageSafeRejectsControlChars() {
        assertFalse(InputValidator.isStorageSafe("hello\nworld"));
        assertFalse(InputValidator.isStorageSafe("hello|world"));
        assertFalse(InputValidator.isStorageSafe("hello\u0007"));
        assertTrue (InputValidator.isStorageSafe("hello world"));
    }

    /** TC-VAL-06: phone validator. */
    @Test
    void phoneValidator() {
        assertTrue (InputValidator.isValidPhone("+962700000000"));
        assertTrue (InputValidator.isValidPhone("0791234567"));
        assertFalse(InputValidator.isValidPhone("12-34"));
        assertFalse(InputValidator.isValidPhone("abc"));
    }

    /** TC-VAL-07: null inputs are rejected, never NPE. */
    @Test
    void nullsAreSafe() {
        assertFalse(InputValidator.isValidUsername(null));
        assertFalse(InputValidator.isValidPhone(null));
        assertFalse(InputValidator.isValidId(null));
        assertFalse(InputValidator.isValidName(null));
        assertFalse(InputValidator.isStorageSafe(null));
    }
}
