package com.skyroute.shiptrack.auth;

import com.skyroute.shiptrack.util.Constants;
import org.junit.jupiter.api.Test;

import java.security.GeneralSecurityException;
import java.util.Arrays;
import java.util.Base64;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for PasswordHasher — PBKDF2-HMAC-SHA-256 hashing.
 *
 * Feature: Login (Authentication) — cryptographic layer
 * Class under test: PasswordHasher
 *
 * Q9 test plan rows: TC-HASH-01 through TC-HASH-14
 */
class PasswordHasherTest {

    private static final char[] PASSWORD       = "TestPass1!".toCharArray();
    private static final char[] WRONG_PASSWORD = "WrongPass9!".toCharArray();
    private static final char[] EMPTY_PASSWORD = new char[0];

    // ══════════════════════════════════════════════════════════════════
    // TC-HASH-01..04  hashWithNewSalt — structure
    // ══════════════════════════════════════════════════════════════════

    /** TC-HASH-01 — method returns exactly two elements: [salt, hash] */
    @Test
    void hashWithNewSalt_returnsTwoElementArray() throws GeneralSecurityException {
        String[] result = PasswordHasher.hashWithNewSalt(PASSWORD);

        assertEquals(2, result.length,
                "hashWithNewSalt must return exactly [salt, hash]");
        assertNotNull(result[0], "Salt must not be null");
        assertNotNull(result[1], "Hash must not be null");
    }

    /** TC-HASH-02 — salt element decodes to exactly SALT_LENGTH_BYTES bytes */
    @Test
    void hashWithNewSalt_saltIsCorrectLength() throws GeneralSecurityException {
        String[] result = PasswordHasher.hashWithNewSalt(PASSWORD);
        byte[] salt = Base64.getDecoder().decode(result[0]);

        assertEquals(Constants.SALT_LENGTH_BYTES, salt.length,
                "Salt must be " + Constants.SALT_LENGTH_BYTES + " bytes");
    }

    /** TC-HASH-03 — hash element decodes to exactly PBKDF2_KEY_LENGTH / 8 bytes (256 bits) */
    @Test
    void hashWithNewSalt_hashIs256Bits() throws GeneralSecurityException {
        String[] result = PasswordHasher.hashWithNewSalt(PASSWORD);
        byte[] hash = Base64.getDecoder().decode(result[1]);

        assertEquals(Constants.PBKDF2_KEY_LENGTH / 8, hash.length,
                "Hash must be 256 bits = 32 bytes");
    }

    /** TC-HASH-04 — calling twice for the same password produces DIFFERENT salts (random) */
    @Test
    void hashWithNewSalt_samePwd_twoCalls_produceDifferentSalts() throws GeneralSecurityException {
        String[] r1 = PasswordHasher.hashWithNewSalt(PASSWORD);
        String[] r2 = PasswordHasher.hashWithNewSalt(PASSWORD);

        assertNotEquals(r1[0], r2[0],
                "Each call must generate a new random salt — equal salts break rainbow-table resistance");
        assertNotEquals(r1[1], r2[1],
                "Different salts must produce different hashes for the same password");
    }

    // ══════════════════════════════════════════════════════════════════
    // TC-HASH-05..10  verify — correct and incorrect inputs
    // ══════════════════════════════════════════════════════════════════

    /** TC-HASH-05 — original password verifies against its own hash */
    @Test
    void verify_correctPassword_returnsTrue() throws GeneralSecurityException {
        String[] sh = PasswordHasher.hashWithNewSalt(PASSWORD);

        assertTrue(PasswordHasher.verify(PASSWORD, sh[0], sh[1]));
    }

    /** TC-HASH-06 — a different password does not verify */
    @Test
    void verify_wrongPassword_returnsFalse() throws GeneralSecurityException {
        String[] sh = PasswordHasher.hashWithNewSalt(PASSWORD);

        assertFalse(PasswordHasher.verify(WRONG_PASSWORD, sh[0], sh[1]));
    }

    /** TC-HASH-07 — empty password does not verify against a hash of a real password */
    @Test
    void verify_emptyPassword_returnsFalse() throws GeneralSecurityException {
        String[] sh = PasswordHasher.hashWithNewSalt(PASSWORD);

        assertFalse(PasswordHasher.verify(EMPTY_PASSWORD, sh[0], sh[1]));
    }

    /** TC-HASH-08 — case difference alone causes verify to fail */
    @Test
    void verify_passwordDiffersInCase_returnsFalse() throws GeneralSecurityException {
        String[] sh = PasswordHasher.hashWithNewSalt("TestPass1!".toCharArray());

        assertFalse(PasswordHasher.verify("testpass1!".toCharArray(), sh[0], sh[1]),
                "Hash comparison must be case-sensitive");
    }

    /** TC-HASH-09 — one extra character at the end causes verify to fail */
    @Test
    void verify_passwordWithExtraCharacter_returnsFalse() throws GeneralSecurityException {
        String[] sh = PasswordHasher.hashWithNewSalt(PASSWORD);

        assertFalse(PasswordHasher.verify("TestPass1!X".toCharArray(), sh[0], sh[1]));
    }

    /** TC-HASH-10 — verify is deterministic: calling twice gives the same answer */
    @Test
    void verify_calledTwiceWithSameInputs_returnsSameResult() throws GeneralSecurityException {
        String[] sh = PasswordHasher.hashWithNewSalt(PASSWORD);

        assertTrue(PasswordHasher.verify(PASSWORD, sh[0], sh[1]));
        assertTrue(PasswordHasher.verify(PASSWORD, sh[0], sh[1]),
                "verify() must be deterministic");
    }

    // ══════════════════════════════════════════════════════════════════
    // TC-HASH-11..12  verify — Fail Securely (bad inputs must not throw)
    // ══════════════════════════════════════════════════════════════════

    /**
     * TC-HASH-11 — invalid Base64 salt must return false, not throw.
     * (Ch.2 Fail Securely: any internal error means "credentials do not match")
     */
    @Test
    void verify_invalidBase64Salt_returnsFalseNotException() {
        assertFalse(PasswordHasher.verify(PASSWORD, "!!!NOT_BASE64!!!", "AAAA=="),
                "Invalid salt must cause verify() to return false, not throw");
    }

    /**
     * TC-HASH-12 — invalid Base64 hash must return false, not throw.
     */
    @Test
    void verify_invalidBase64Hash_returnsFalseNotException() {
        String validSalt = Base64.getEncoder().encodeToString(new byte[Constants.SALT_LENGTH_BYTES]);
        assertFalse(PasswordHasher.verify(PASSWORD, validSalt, "!!!NOT_BASE64!!!"),
                "Invalid hash must cause verify() to return false, not throw");
    }

    // ══════════════════════════════════════════════════════════════════
    // TC-HASH-13..14  newSalt and derive — low-level primitives
    // ══════════════════════════════════════════════════════════════════

    /** TC-HASH-13 — two freshly generated salts must not be equal */
    @Test
    void newSalt_twoCalls_returnDifferentValues() {
        byte[] s1 = PasswordHasher.newSalt();
        byte[] s2 = PasswordHasher.newSalt();

        assertFalse(Arrays.equals(s1, s2),
                "Two random 16-byte salts should not be equal");
        assertEquals(Constants.SALT_LENGTH_BYTES, s1.length);
        assertEquals(Constants.SALT_LENGTH_BYTES, s2.length);
    }

    /** TC-HASH-14 — derive is deterministic: same input → same output */
    @Test
    void derive_sameInputs_producesSameOutput() throws GeneralSecurityException {
        byte[] salt = PasswordHasher.newSalt();

        byte[] h1 = PasswordHasher.derive(PASSWORD, salt);
        byte[] h2 = PasswordHasher.derive(PASSWORD, salt);

        assertArrayEquals(h1, h2, "derive() must be deterministic for the same password and salt");
        assertEquals(Constants.PBKDF2_KEY_LENGTH / 8, h1.length,
                "Output must be exactly " + (Constants.PBKDF2_KEY_LENGTH / 8) + " bytes");
    }
}