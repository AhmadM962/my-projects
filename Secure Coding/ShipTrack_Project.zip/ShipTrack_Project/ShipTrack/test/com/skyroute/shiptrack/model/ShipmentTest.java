package com.skyroute.shiptrack.model;

import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for Shipment — creation, state machine enforcement, and serialisation.
 *
 * Feature: Shipment Status State Machine
 * Class under test: Shipment
 *
 * Q9 test plan rows: TC-SHIP-01 through TC-SHIP-22
 */
class ShipmentTest {

    // ── Fixed test data ────────────────────────────────────────────────
    private static final String ID   = "S0001";
    private static final String CUST = "alice";
    private static final String DESC = "Fragile electronics";
    private static final String DRV  = "bob";

    /** Helper — a fresh PENDING shipment with no driver. */
    private static Shipment pending() {
        return Shipment.newRequest(ID, CUST, DESC);
    }

    // ══════════════════════════════════════════════════════════════════
    // TC-SHIP-01..07  newRequest factory method
    // ══════════════════════════════════════════════════════════════════

    /** TC-SHIP-01 */
    @Test
    void newRequest_initialStatus_isPending() {
        assertEquals(ShipmentStatus.PENDING, pending().getStatus());
    }

    /** TC-SHIP-02 */
    @Test
    void newRequest_idField_isStoredCorrectly() {
        assertEquals(ID, pending().getId());
    }

    /** TC-SHIP-03 */
    @Test
    void newRequest_customerUsernameField_isStoredCorrectly() {
        assertEquals(CUST, pending().getCustomerUsername());
    }

    /** TC-SHIP-04 */
    @Test
    void newRequest_descriptionField_isStoredCorrectly() {
        assertEquals(DESC, pending().getDescription());
    }

    /** TC-SHIP-05 — no driver is assigned at creation time */
    @Test
    void newRequest_driverUsername_isEmptyString() {
        assertTrue(pending().getDriverUsername().isEmpty(),
                "Newly created shipment must have an empty driverUsername");
    }

    /** TC-SHIP-06 */
    @Test
    void newRequest_createdAt_isNotNull() {
        assertNotNull(pending().getCreatedAt());
    }

    /** TC-SHIP-07 — createdAt is set to approximately now */
    @Test
    void newRequest_createdAt_isWithinOneSecondOfNow() {
        LocalDateTime before = LocalDateTime.now().minusSeconds(1);
        Shipment s = Shipment.newRequest(ID, CUST, DESC);
        LocalDateTime after = LocalDateTime.now().plusSeconds(1);

        assertTrue(s.getCreatedAt().isAfter(before) && s.getCreatedAt().isBefore(after),
                "createdAt must be approximately now");
    }

    // ══════════════════════════════════════════════════════════════════
    // TC-SHIP-08..11  assignDriver
    // ══════════════════════════════════════════════════════════════════

    /** TC-SHIP-08 */
    @Test
    void assignDriver_setsDriverUsername() {
        Shipment s = pending();
        s.assignDriver(DRV);
        assertEquals(DRV, s.getDriverUsername());
    }

    /** TC-SHIP-09 — driver can be reassigned */
    @Test
    void assignDriver_canReassignToNewDriver() {
        Shipment s = pending();
        s.assignDriver("driver1");
        s.assignDriver("driver2");
        assertEquals("driver2", s.getDriverUsername());
    }

    /** TC-SHIP-10 */
    @Test
    void assignDriver_nullDriver_throwsIllegalArgumentException() {
        assertThrows(IllegalArgumentException.class, () -> pending().assignDriver(null));
    }

    /** TC-SHIP-11 */
    @Test
    void assignDriver_emptyString_throwsIllegalArgumentException() {
        assertThrows(IllegalArgumentException.class, () -> pending().assignDriver(""));
    }

    // ══════════════════════════════════════════════════════════════════
    // TC-SHIP-12..18  advanceTo — state machine enforcement
    // ══════════════════════════════════════════════════════════════════

    /** TC-SHIP-12 — valid transition returns true and updates the status */
    @Test
    void advanceTo_validTransition_returnsTrueAndUpdatesStatus() {
        Shipment s = pending();
        assertTrue(s.advanceTo(ShipmentStatus.IN_TRANSIT));
        assertEquals(ShipmentStatus.IN_TRANSIT, s.getStatus());
    }

    /** TC-SHIP-13 — illegal transition returns false and status is unchanged */
    @Test
    void advanceTo_illegalTransition_returnsFalse_statusUnchanged() {
        Shipment s = pending();
        // PENDING → DELIVERED is not a legal single step
        assertFalse(s.advanceTo(ShipmentStatus.DELIVERED));
        assertEquals(ShipmentStatus.PENDING, s.getStatus(),
                "Status must not change after a rejected transition");
    }

    /** TC-SHIP-14 — DELIVERED is terminal: no further transitions accepted */
    @Test
    void advanceTo_fromTerminalDelivered_allTransitionsRejected() {
        Shipment s = pending();
        s.advanceTo(ShipmentStatus.IN_TRANSIT);
        s.advanceTo(ShipmentStatus.DELIVERED);

        assertFalse(s.advanceTo(ShipmentStatus.PENDING));
        assertFalse(s.advanceTo(ShipmentStatus.PICKED_UP));
        assertFalse(s.advanceTo(ShipmentStatus.IN_TRANSIT));
        assertEquals(ShipmentStatus.DELIVERED, s.getStatus(),
                "Terminal state must not change");
    }

    /** TC-SHIP-15 — full legal lifecycle: PENDING → PICKED_UP → IN_TRANSIT → DELIVERED */
    @Test
    void advanceTo_fullLegalLifecycle_succeedsAtEveryStep() {
        Shipment s = pending();

        assertTrue(s.advanceTo(ShipmentStatus.PICKED_UP));
        assertEquals(ShipmentStatus.PICKED_UP, s.getStatus());

        assertTrue(s.advanceTo(ShipmentStatus.IN_TRANSIT));
        assertEquals(ShipmentStatus.IN_TRANSIT, s.getStatus());

        assertTrue(s.advanceTo(ShipmentStatus.DELIVERED));
        assertEquals(ShipmentStatus.DELIVERED, s.getStatus());
    }

    /** TC-SHIP-16 — dispatcher path: PENDING → IN_TRANSIT (skipping PICKED_UP) is allowed */
    @Test
    void advanceTo_pendingToInTransit_skippingPickedUp_isAllowed() {
        Shipment s = pending();
        assertTrue(s.advanceTo(ShipmentStatus.IN_TRANSIT));
        assertEquals(ShipmentStatus.IN_TRANSIT, s.getStatus());
    }

    /** TC-SHIP-17 — same-state transition is always rejected */
    @Test
    void advanceTo_sameStatus_returnsFalse() {
        Shipment s = pending();
        assertFalse(s.advanceTo(ShipmentStatus.PENDING),
                "Advancing to the current state must always return false");
    }

    /** TC-SHIP-18 — null transition is rejected safely */
    @Test
    void advanceTo_null_returnsFalse_statusUnchanged() {
        Shipment s = pending();
        assertFalse(s.advanceTo(null));
        assertEquals(ShipmentStatus.PENDING, s.getStatus());
    }

    // ══════════════════════════════════════════════════════════════════
    // TC-SHIP-19..22  Serialisation: toRecord / fromRecord
    // ══════════════════════════════════════════════════════════════════

    /** TC-SHIP-19 — toRecord produces exactly 6 pipe-separated fields */
    @Test
    void toRecord_containsExactlySixPipeDelimitedFields() {
        String record = pending().toRecord();
        long pipes = record.chars().filter(c -> c == '|').count();

        assertEquals(5, pipes,
                "Record must contain 5 pipes = 6 fields");
    }

    /** TC-SHIP-20 — full round-trip: fromRecord(toRecord(s)) recovers all fields */
    @Test
    void fromRecord_roundtrip_preservesAllFields() {
        LocalDateTime ts = LocalDateTime.of(2026, 3, 10, 14, 30, 0);
        Shipment original = new Shipment(ID, CUST, DRV, DESC,
                ShipmentStatus.IN_TRANSIT, ts);

        Shipment restored = Shipment.fromRecord(original.toRecord());

        assertEquals(original.getId(),               restored.getId());
        assertEquals(original.getCustomerUsername(), restored.getCustomerUsername());
        assertEquals(original.getDriverUsername(),   restored.getDriverUsername());
        assertEquals(original.getDescription(),      restored.getDescription());
        assertEquals(original.getStatus(),           restored.getStatus());
        assertEquals(original.getCreatedAt(),        restored.getCreatedAt());
    }

    /**
     * TC-SHIP-21 — pipe character in description is sanitised so the record format is not broken.
     * (SEC-INP-02: pipe is our field separator; it must never appear in a field value)
     */
    @Test
    void toRecord_pipeInDescription_isSanitised_recordStillHasFivesPipes() {
        Shipment s = Shipment.newRequest(ID, CUST, "Confidential|Documents");
        String record = s.toRecord();

        assertEquals(5, record.chars().filter(c -> c == '|').count(),
                "Pipe in description must be replaced; record must still have exactly 5 separators");
    }

    /** TC-SHIP-22 — fromRecord with fewer than 6 fields throws */
    @Test
    void fromRecord_tooFewFields_throwsException() {
        assertThrows(Exception.class,
                () -> Shipment.fromRecord("S001|alice|bob"));
    }
}