// This file belongs to the "ui" package.
package com.skyroute.shiptrack.ui;

// List is the interface for ordered collections (used when listing shipments).
import java.util.List;

// Shipment is the data class for package deliveries.
import com.skyroute.shiptrack.model.Shipment;

// User is the data class for user accounts.
import com.skyroute.shiptrack.model.User;

// ShipmentRepository reads and writes shipments.dat.
import com.skyroute.shiptrack.repository.ShipmentRepository;

// UserRepository is needed to save profile changes.
import com.skyroute.shiptrack.repository.UserRepository;

// AuditLogger records all customer actions to audit.log.
import com.skyroute.shiptrack.util.AuditLogger;

// ConsoleUI provides the prompt/print/error methods for terminal interaction.
import com.skyroute.shiptrack.util.ConsoleUI;

// InputValidator validates names and phone numbers when the customer edits their profile.
import com.skyroute.shiptrack.util.InputValidator;

// "public class CustomerMenu" — the screen that customers see after login.
// Customers can only:
//   - Create a new shipment request
//   - Track (view) THEIR OWN shipments
//   - Update their own profile (name and phone)
// Security principle (Least Privilege): customers see ONLY their own shipments.
// They cannot see other customers' packages or any admin/dispatcher features.
public class CustomerMenu {

    // ── FIELDS ───────────────────────────────────────────────────────────────

    private final ConsoleUI io;                 // For printing and reading input
    private final User me;                      // The currently logged-in customer
    private final UserRepository users;         // For saving profile changes
    private final ShipmentRepository shipments; // For creating and reading shipments

    // ── CONSTRUCTOR ──────────────────────────────────────────────────────────
    public CustomerMenu(ConsoleUI io, User me,
                        UserRepository users, ShipmentRepository shipments) {
        this.io        = io;        // Store the console UI helper
        this.me        = me;        // Store the logged-in customer
        this.users     = users;     // Store the user repository
        this.shipments = shipments; // Store the shipment repository
    }

    // ── run ───────────────────────────────────────────────────────────────────
    // The main loop for the Customer Menu. Shows options and processes choices.
    public void run() {
        while (true) { // Keep showing the menu until the customer logs out.
            io.println("");
            // Print the menu header with the customer's username.
            io.println("=== Customer Menu (" + me.getUsername() + ") ===");
            io.println("1) Create shipment request"); // Request a new package delivery
            io.println("2) Track my shipments");       // View status of own shipments
            io.println("3) View / update my profile"); // Edit own name and phone
            io.println("0) Logout");                  // Exit the menu

            int choice = io.promptInt("> "); // Read the customer's choice.

            switch (choice) {
                case 1: createShipment(); break; // Go to create shipment flow
                case 2: trackMine();      break; // Show customer's own shipments
                case 3: editProfile();    break; // Edit profile
                case 0: return;                   // Exit the loop (logs out)
                default: io.error("Unknown option."); // Invalid input
            }
        }
    }

    // ── createShipment ────────────────────────────────────────────────────────
    // Creates a new shipment request for this customer.
    private void createShipment() {
        // Ask the customer to describe what they're shipping.
        String desc = io.prompt("Package description (free text, no '|'): ");

        // Validate the description:
        //   isStorageSafe(desc) → rejects "|", newlines, and control characters
        //   desc.isEmpty()      → rejects a blank description
        //   desc.length() > 200 → rejects descriptions that are too long
        if (!InputValidator.isStorageSafe(desc) || desc.isEmpty() || desc.length() > 200) {
            io.error("Description is required and must be storage-safe (no '|', newlines, control chars), up to 200 chars.");
            return;
        }

        // Generate a unique ID for this new shipment (e.g. "S0001-12345").
        String id = shipments.nextId();

        // Create a new Shipment object with:
        //   - the generated ID
        //   - the logged-in customer's username (me.getUsername())
        //   - the package description
        //   - status = PENDING (automatically set by newRequest())
        //   - createdAt = now (automatically set by newRequest())
        Shipment s = Shipment.newRequest(id, me.getUsername(), desc);

        // Save the new shipment to shipments.dat.
        shipments.save(s);

        // Log the creation event.
        AuditLogger.log(me.getUsername(), "CREATE_SHIPMENT", id);

        // Confirm to the customer with the ID and initial status.
        io.println("Created shipment " + id + " (status: " + s.getStatus().label() + ").");
    }

    // ── trackMine ────────────────────────────────────────────────────────────
    // Shows ALL shipments that belong to this customer only.
    // Security (Least Privilege): findByCustomer() filters by username so
    // the customer NEVER sees another customer's packages.
    private void trackMine() {
        // Get only the shipments where customerUsername == this customer's username.
        List<Shipment> mine = shipments.findByCustomer(me.getUsername());

        if (mine.isEmpty()) {
            io.info("No shipments yet."); // Tell them they have no shipments.
            return;
        }

        io.println(""); // Blank line for readability.
        // Print each shipment. s.toString() gives e.g.:
        //   "S0001-12345 [pending] customer=alice driver=(none) desc=Fragile glassware"
        for (Shipment s : mine) {
            io.println("  " + s);
        }
    }

    // ── editProfile ────────────────────────────────────────────────────────────
    // Allows the customer to update their own full name and/or phone number.
    private void editProfile() {
        // Show the customer their current information.
        io.println("Current: " + me.getFullName() + " | id=" + me.getIdNumber()
                + " | phone=" + me.getContactNumber());

        // ── Update name (optional) ─────────────────────────────────────────
        String name = io.prompt("New full name (blank=keep): ");
        if (!name.isEmpty()) { // Only update if they typed something.
            // Validate the new name format.
            if (!InputValidator.isValidName(name)) { io.error("Invalid name."); return; }
            // Update the name in the User object (in memory, not yet saved to file).
            me.setFullName(name);
        }

        // ── Update phone (optional) ────────────────────────────────────────
        String phone = io.prompt("New phone (blank=keep): ");
        if (!phone.isEmpty()) { // Only update if they typed something.
            // Validate the new phone format.
            if (!InputValidator.isValidPhone(phone)) { io.error("Invalid phone."); return; }
            // Update the phone in the User object (in memory).
            me.setContactNumber(phone);
        }

        // Save the updated user to users.dat (writes all users atomically).
        users.save(me);

        // Log the profile update.
        AuditLogger.log(me.getUsername(), "UPDATE_PROFILE", "self");

        io.println("Profile saved."); // Confirm to customer.
    }
}
