// This file belongs to the "model" package — blueprints for data objects.
package com.skyroute.shiptrack.model;

// Import Constants so we can use the field separator character defined there.
import com.skyroute.shiptrack.util.Constants;

// "public class User" declares the User blueprint.
// Every account in the system (admin, dispatcher, customer, driver) is a User object.
// All four roles share the same fields — one class is simpler than four separate classes.
public class User {

    // ── FIELDS ──────────────────────────────────────────────────────────────
    // These are the pieces of information stored for each user.

    // The login name. "final" means once set in the constructor, it CANNOT be changed.
    // This prevents code from accidentally renaming a user.
    private final String username;

    // Which role this user has (ADMIN, DISPATCHER, CUSTOMER, DELIVERY_PERSONNEL).
    // "final" means the role can never be changed — a customer cannot become an admin.
    private final Role role;

    // The random salt used when hashing this user's password.
    // Stored as Base64 text so it can be saved in a plain-text file.
    private String salt;

    // The PBKDF2 hash of this user's password.
    // Stored as Base64 text. The real password is NEVER stored — only this hash.
    private String hash;

    // Whether this account is locked. true = the user cannot log in.
    private boolean locked;

    // How many times in a row the user has typed the wrong password.
    // When this reaches the policy limit, the account is locked.
    private int failedAttempts;

    // The user's real full name (e.g. "Alice Smith").
    private String fullName;

    // The user's national ID number (e.g. "12345678").
    private String idNumber;

    // The user's phone number (e.g. "0797000001").
    private String contactNumber;

    // ── CONSTRUCTOR ─────────────────────────────────────────────────────────
    // A constructor runs when you write "new User(...)".
    // It receives all 9 values and stores them in the fields above.
    // "this.username = username" means: set MY field called username to the value passed in.
    public User(String username, Role role,
                String salt, String hash,
                boolean locked, int failedAttempts,
                String fullName, String idNumber, String contactNumber) {
        this.username       = username;        // Store the login name
        this.role           = role;            // Store the role
        this.salt           = salt;            // Store the password salt
        this.hash           = hash;            // Store the password hash
        this.locked         = locked;          // Store whether account is locked
        this.failedAttempts = failedAttempts;  // Store the wrong-password count
        this.fullName       = fullName;        // Store the full name
        this.idNumber       = idNumber;        // Store the ID number
        this.contactNumber  = contactNumber;   // Store the phone number
    }

    // ── GETTERS (read-only access to private fields) ─────────────────────────
    // These methods let other classes READ the fields without being able to change them.
    // Because the fields are private, outside code MUST go through these methods.

    public String  getUsername()       { return username; }        // Returns the login name
    public Role    getRole()           { return role; }            // Returns ADMIN/CUSTOMER/etc.
    public String  getSalt()           { return salt; }            // Returns the password salt
    public String  getHash()           { return hash; }            // Returns the password hash
    public boolean isLocked()          { return locked; }          // Returns true if locked
    public int     getFailedAttempts() { return failedAttempts; }  // Returns the wrong-attempt count
    public String  getFullName()       { return fullName; }        // Returns the display name
    public String  getIdNumber()       { return idNumber; }        // Returns the ID number
    public String  getContactNumber()  { return contactNumber; }   // Returns the phone number

    // ── SETTERS (controlled write access) ────────────────────────────────────
    // Only a few fields can be changed, and only through these specific methods.
    // username and role are NOT here because they are final — they can never change.

    // Replaces the stored salt and hash when the password is changed.
    public void setSaltAndHash(String salt, String hash) {
        this.salt = salt;   // Update the salt
        this.hash = hash;   // Update the hash
    }

    // Locks or unlocks the account. Called by the admin.
    public void setLocked(boolean locked)  { this.locked = locked; }

    // Adds 1 to the failed-attempts counter. Called after each wrong password.
    public void incrementFailedAttempts()  { this.failedAttempts++; }

    // Resets the counter to zero. Called after a successful login or an unlock.
    public void resetFailedAttempts()      { this.failedAttempts = 0; }

    // Updates the display name (user can edit their own profile).
    public void setFullName(String fullName)             { this.fullName      = fullName; }

    // Updates the ID number (user can edit their own profile).
    public void setIdNumber(String idNumber)             { this.idNumber      = idNumber; }

    // Updates the phone number (user can edit their own profile).
    public void setContactNumber(String contactNumber)   { this.contactNumber = contactNumber; }

    // ── SERIALIZATION ────────────────────────────────────────────────────────
    // Serialization = converting an object into a line of text so it can be saved to a file.
    // Deserialization = reading that line back and turning it into an object again.

    // Converts this User object into a single pipe-separated line for saving to users.dat.
    // Example output: alice|CUSTOMER|saltB64|hashB64|false|0|Alice Smith|12345678|0797000001
    public String toRecord() {
        // String.join(separator, value1, value2, ...) puts the separator between each value.
        return String.join(Constants.FIELD_SEPARATOR,
                username,                        // field 1: login name
                role.name(),                     // field 2: role as text (e.g. "CUSTOMER")
                nullSafe(salt),                  // field 3: salt (or empty string if null)
                nullSafe(hash),                  // field 4: hash (or empty string if null)
                Boolean.toString(locked),        // field 5: "true" or "false"
                Integer.toString(failedAttempts),// field 6: number as text
                nullSafe(fullName),              // field 7: full name
                nullSafe(idNumber),              // field 8: ID number
                nullSafe(contactNumber));        // field 9: phone number
    }

    // Reads one line from users.dat and turns it back into a User object.
    // This is the reverse of toRecord().
    public static User fromRecord(String line) {
        // Split the line at every pipe "|" character. -1 means keep trailing empty fields.
        // Result: an array of 9 strings, one for each field.
        String[] parts = line.split(Constants.FIELD_SEPARATOR_REGEX, -1);

        // Sanity check: if we don't get exactly 9 parts, the line is corrupt — throw an error.
        if (parts.length != 9) {
            throw new IllegalArgumentException("Bad user record: " + parts.length + " fields");
        }

        // Build and return a new User object using the 9 parsed fields.
        return new User(
                parts[0],                        // username (field 1)
                Role.valueOf(parts[1]),           // role: converts "CUSTOMER" → Role.CUSTOMER (field 2)
                parts[2],                        // salt (field 3)
                parts[3],                        // hash (field 4)
                Boolean.parseBoolean(parts[4]),  // locked: converts "true"/"false" → boolean (field 5)
                Integer.parseInt(parts[5]),      // failedAttempts: converts "0" → 0 (field 6)
                parts[6],                        // fullName (field 7)
                parts[7],                        // idNumber (field 8)
                parts[8]                         // contactNumber (field 9)
        );
    }

    // Helper: returns an empty string if the input is null, otherwise returns it as-is.
    // This prevents the word "null" from appearing in the saved file.
    private static String nullSafe(String s) { return s == null ? "" : s; }

    // ── toString ─────────────────────────────────────────────────────────────
    // @Override means we are replacing the default toString() inherited from Object.
    // toString() is called automatically when you print a User object or use it in a string.
    // IMPORTANT: salt and hash are intentionally NOT included here — never expose credentials in logs.
    @Override
    public String toString() {
        // String.format works like printf: %s = string placeholder, %d = integer placeholder.
        // Example output: "alice [CUSTOMER] Alice Smith lock=false attempts=0"
        return String.format("%s [%s] %s lock=%s attempts=%d",
                username,        // %s → the login name
                role.name(),     // %s → the role text
                fullName,        // %s → the full name
                locked,          // %s → true or false
                failedAttempts); // %d → the integer count
    }
}
