// This file belongs to the "auth" package — everything related to authentication.
package com.skyroute.shiptrack.auth;

// For throwing/catching security-related errors from Java's crypto library.
import java.security.GeneralSecurityException;

// MessageDigest is imported but its main use here is conceptual — we use constantTimeEquals instead.
import java.security.MessageDigest;

// SecureRandom generates cryptographically safe random numbers (unlike Math.random()).
// It gets its randomness from the operating system's entropy pool.
import java.security.SecureRandom;

// Arrays.equals could be used for comparison, but we use our own constantTimeEquals instead.
import java.util.Arrays;

// Base64 converts raw bytes (binary data) into printable text so it can be stored in a text file.
import java.util.Base64;

// SecretKeyFactory is the engine that runs the PBKDF2 algorithm.
import javax.crypto.SecretKeyFactory;

// PBEKeySpec packages the password, salt, iteration count, and key length for PBKDF2.
import javax.crypto.spec.PBEKeySpec;

// Constants holds the algorithm name, iteration count, salt length, and key length.
import com.skyroute.shiptrack.util.Constants;

// "public final class" — public: visible everywhere; final: cannot be extended.
// This is a utility class that handles ALL password hashing logic for the app.
// Security principle: passwords must NEVER be stored as plain text.
// We use PBKDF2-HMAC-SHA256, a standard algorithm approved by NIST and OWASP.
public final class PasswordHasher {

    // One shared SecureRandom instance for the whole class.
    // Creating SecureRandom is expensive, so we do it once and reuse it.
    // "static final" = created once when the class is loaded, never recreated.
    private static final SecureRandom RNG = new SecureRandom();

    // Private constructor — nobody can create a PasswordHasher object.
    private PasswordHasher() { /* utility class — not instantiable */ }

    // ── newSalt ───────────────────────────────────────────────────────────────
    // Generates a new random salt: an array of random bytes.
    // A salt is unique random data mixed into the password before hashing.
    // Without a salt, two users with the same password would have identical hashes.
    // With a salt, their hashes are completely different even with the same password.
    // This defeats "rainbow table" attacks (pre-computed lists of password hashes).
    public static byte[] newSalt() {
        // Create an empty byte array with the configured length (16 bytes = 128 bits).
        byte[] salt = new byte[Constants.SALT_LENGTH_BYTES];

        // Fill the array with random bytes from the secure random number generator.
        RNG.nextBytes(salt);

        // Return the filled array.
        return salt;
    }

    // ── derive ────────────────────────────────────────────────────────────────
    // Runs the PBKDF2 algorithm: takes a password and salt and produces a fixed-length hash.
    // PBKDF2 applies SHA-256 repeatedly (65,536 times) — making brute-force attacks slow.
    // Returns the raw bytes of the hash.
    // "throws GeneralSecurityException" means this method might fail if the algorithm is unavailable.
    public static byte[] derive(char[] password, byte[] salt) throws GeneralSecurityException {

        // PBEKeySpec packages all 4 PBKDF2 parameters into one object:
        //   password      → the char[] password to hash
        //   salt          → the random salt bytes
        //   PBKDF2_ITERATIONS → 65,536 rounds (makes brute force slow)
        //   PBKDF2_KEY_LENGTH → 256 bits of output
        PBEKeySpec spec = new PBEKeySpec(password, salt,
                Constants.PBKDF2_ITERATIONS, Constants.PBKDF2_KEY_LENGTH);

        try {
            // Get the PBKDF2WithHmacSHA256 engine from Java's built-in security library.
            SecretKeyFactory f = SecretKeyFactory.getInstance(Constants.PBKDF2_ALGORITHM);

            // Run the algorithm: generateSecret(spec) does all 65,536 hash iterations.
            // .getEncoded() returns the result as a raw byte array.
            return f.generateSecret(spec).getEncoded();

        } finally {
            // "finally" always runs — even if an exception occurred above.
            // spec.clearPassword() overwrites the password inside the PBEKeySpec with zeros.
            // This removes the password from memory immediately after it's no longer needed.
            spec.clearPassword();
        }
    }

    // ── hashWithNewSalt ───────────────────────────────────────────────────────
    // Convenient one-call method: generates a new random salt, hashes the password,
    // and returns BOTH as Base64-encoded strings.
    // Returns a 2-element array: [0] = Base64(salt), [1] = Base64(hash)
    // These two strings are what gets saved into users.dat for each user.
    public static String[] hashWithNewSalt(char[] password) throws GeneralSecurityException {
        byte[] salt = newSalt();              // Generate 16 random bytes as the salt.
        byte[] hash = derive(password, salt); // Run PBKDF2: password + salt → hash bytes.

        // Get a Base64 encoder to convert raw bytes to text.
        Base64.Encoder enc = Base64.getEncoder();

        // Return a 2-element String array: [Base64 salt, Base64 hash]
        return new String[] { enc.encodeToString(salt), enc.encodeToString(hash) };
    }

    // ── verify ────────────────────────────────────────────────────────────────
    // Checks whether a candidate password matches the stored salt and hash.
    // This is called during login.
    // Returns true if the password is correct, false if it is wrong OR if anything goes wrong.
    // Security principle (Fail Securely): any internal error returns false (denied), NEVER true.
    public static boolean verify(char[] candidate, String saltB64, String hashB64) {
        try {
            // Decode the stored Base64 salt back to raw bytes.
            byte[] salt = Base64.getDecoder().decode(saltB64);

            // Decode the stored Base64 hash back to raw bytes — this is the "expected" answer.
            byte[] expected = Base64.getDecoder().decode(hashB64);

            // Run PBKDF2 on the candidate password using the SAME salt as when it was stored.
            // If the candidate is the correct password, the result will match "expected".
            byte[] actual = derive(candidate, salt);

            // Compare the two hash results using constant-time comparison (explained below).
            return constantTimeEquals(actual, expected);

        } catch (GeneralSecurityException | IllegalArgumentException e) {
            // If anything goes wrong (bad Base64, algorithm unavailable, etc.):
            // Return false — do NOT let an error accidentally grant access.
            // This is the "Fail Securely" principle.
            return false;
        }
    }

    // ── constantTimeEquals ────────────────────────────────────────────────────
    // A TIMING-SAFE comparison of two byte arrays.
    //
    // WHY NOT JUST USE Arrays.equals?
    // A normal comparison stops as soon as it finds the first mismatch (short-circuit).
    // This means comparing wrong passwords takes slightly different amounts of time
    // depending on HOW wrong they are. An attacker measuring nanosecond differences
    // can learn which bytes of the hash are correct — a "timing side-channel attack".
    //
    // This method always loops through ALL bytes, taking the same time regardless of mismatches.
    // The XOR trick (^) computes a difference bit — if any byte differs, diff becomes non-zero.
    // At the end: diff == 0 means ALL bytes matched (correct password).
    private static boolean constantTimeEquals(byte[] a, byte[] b) {
        // If either array is null or they have different lengths, they can't be equal.
        if (a == null || b == null || a.length != b.length) {
            return false;
        }

        // Start with diff = 0 (no differences found yet).
        int diff = 0;

        // Loop through every byte in both arrays.
        for (int i = 0; i < a.length; i++) {
            // XOR (^) two bytes: the result is 0 only if both bytes are identical.
            // OR-assign (|=) accumulates: if ANY byte differs, diff becomes non-zero.
            // This loop ALWAYS runs to completion — it never stops early.
            diff |= a[i] ^ b[i];
        }

        // diff == 0 means no differences were found → arrays are equal → password is correct.
        return diff == 0;
    }
}
