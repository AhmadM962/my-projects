// This file belongs to the "model" package — blueprints for data objects.
package com.skyroute.shiptrack.model;

// "public enum" declares an enumeration — a type that can only be one of a fixed set of values.
// Think of it like a traffic light: it can only be RED, YELLOW, or GREEN.
// Here the four possible roles are: ADMIN, DISPATCHER, CUSTOMER, DELIVERY_PERSONNEL.
// Security principle: using an enum means the compiler catches typos — "ADMINE" would be a compile error.
public enum Role {

    // The system administrator — manages users and security settings.
    ADMIN,

    // The dispatcher — assigns packages to drivers and updates statuses.
    DISPATCHER,

    // A customer — requests shipments and tracks them.
    CUSTOMER,

    // A delivery driver — picks up and delivers packages.
    DELIVERY_PERSONNEL;

    // ── fromString ──────────────────────────────────────────────────────────
    // This method converts a human-typed string (like "admin" or "Customer") into
    // the matching Role enum value. It is "tolerant" — it accepts different cases and
    // spellings so the user doesn't have to type SHOUTING_CASE exactly.
    public static Role fromString(String s) {

        // If the caller passed null (no value at all), throw an error immediately.
        // "throw" stops the program and sends an error message up to whoever called this method.
        if (s == null) {
            throw new IllegalArgumentException("Role is required");
        }

        // Normalize the input so "admin", "Admin", "ADMIN" all become "ADMIN":
        // .trim()                → removes spaces from start and end: "  admin  " → "admin"
        // .toUpperCase(Locale.ROOT) → converts to uppercase using the neutral locale (safe for all languages)
        // .replace(' ', '_')     → turns spaces into underscores: "delivery personnel" → "delivery_personnel"
        // .replace('-', '_')     → turns dashes into underscores: "delivery-personnel" → "delivery_personnel"
        String norm = s.trim().toUpperCase(java.util.Locale.ROOT).replace(' ', '_').replace('-', '_');

        // Loop through all enum values (ADMIN, DISPATCHER, CUSTOMER, DELIVERY_PERSONNEL).
        // values() returns them all as an array.
        for (Role r : values()) {
            // r.name() returns the exact text of the enum constant, e.g. "ADMIN".
            // If the normalized input matches, return that Role.
            if (r.name().equals(norm)) {
                return r;
            }
        }

        // Friendly synonyms: someone who types "driver" or "delivery" also gets DELIVERY_PERSONNEL.
        // "DRIVER".equals(norm) is written this way (constant first) to avoid a NullPointerException
        // if norm were somehow null — but it can't be here because trim() on a non-null string is safe.
        if ("DRIVER".equals(norm) || "DELIVERY".equals(norm)) {
            return DELIVERY_PERSONNEL;
        }

        // If nothing matched, throw an error with the original bad input in the message.
        throw new IllegalArgumentException("Unknown role: " + s);
    }

    // ── label ───────────────────────────────────────────────────────────────
    // Returns a human-readable display name for menus and messages.
    // For example, Role.DELIVERY_PERSONNEL.label() → "Delivery Personnel"
    public String label() {
        // "this" refers to whichever Role value this method is called on.
        switch (this) {
            case ADMIN:              return "System Admin";        // Pretty name for admins
            case DISPATCHER:         return "Dispatcher";          // Pretty name for dispatchers
            case CUSTOMER:           return "Customer";            // Pretty name for customers
            case DELIVERY_PERSONNEL: return "Delivery Personnel";  // Pretty name for drivers
            default:                 return name();                // Fallback: return the raw enum name
        }
    }
}
