// This file belongs to the "auth" package.
package com.skyroute.shiptrack.auth;

// User is the data class that holds all information about a logged-in account.
import com.skyroute.shiptrack.model.User;

// UserRepository is how we look up users stored in users.dat.
import com.skyroute.shiptrack.repository.UserRepository;

// AuditLogger records every login attempt (success or failure) to audit.log.
import com.skyroute.shiptrack.util.AuditLogger;

// InputValidator checks that the username has a valid format before we even search for it.
import com.skyroute.shiptrack.util.InputValidator;

// "public class AuthService" — handles login and password changes.
// This is the most security-critical class in the entire application.
// It applies FOUR layers of defense (Defense in Depth) on every login attempt.
public class AuthService {

    // ── AuthOutcome ───────────────────────────────────────────────────────────
    // An enum that represents the possible results of a login attempt.
    // Defined as a nested enum inside AuthService because it only makes sense in this context.
    public enum AuthOutcome {
        OK,              // Login succeeded
        BAD_CREDENTIALS, // Username not found OR wrong password (same message — prevents username guessing)
        ACCOUNT_LOCKED,  // The account has been locked after too many failed attempts
        BAD_INPUT        // The username format was invalid or the password was empty
    }

    // ── AuthResult ────────────────────────────────────────────────────────────
    // A tiny "value class" that groups the login result into one object.
    // "public static final class" — static means it doesn't need an outer AuthService instance.
    // final means it cannot be subclassed.
    public static final class AuthResult {
        public final AuthOutcome outcome; // What happened (OK, BAD_CREDENTIALS, etc.)
        public final User user;           // The logged-in User object — null unless outcome == OK
        public final String message;      // A human-readable message safe to show on screen

        // Constructor: stores all three values.
        public AuthResult(AuthOutcome o, User u, String m) {
            this.outcome = o;  // Store the outcome
            this.user    = u;  // Store the user (or null)
            this.message = m;  // Store the display message
        }
    }

    // ── FIELDS ───────────────────────────────────────────────────────────────
    // These are passed in via the constructor (constructor injection pattern).

    // The repository used to look up users by username.
    private final UserRepository users;

    // The password policy used to enforce lockout thresholds.
    private final PasswordPolicy policy;

    // ── CONSTRUCTOR ──────────────────────────────────────────────────────────
    // Receives both dependencies from outside (injected).
    // This makes the class testable — you can pass a fake repository in tests.
    public AuthService(UserRepository users, PasswordPolicy policy) {
        this.users  = users;  // Store the user repository
        this.policy = policy; // Store the password policy
    }

    // ── login ─────────────────────────────────────────────────────────────────
    // The main login method. Applies 4 security layers in order.
    // username = what the user typed in the "Username:" field
    // password = what the user typed in the "Password:" field (as char[] for security)
    // Returns an AuthResult with the outcome, the User object (if OK), and a message.
    public AuthResult login(String username, char[] password) {

        // ════════════════════════════════════════════════════════════════════
        // LAYER 1 — INPUT VALIDATION
        // Reject obviously bad input before doing any database lookups.
        // ════════════════════════════════════════════════════════════════════

        // Check that the username matches the allowed format (3-20 letters/digits/._-)
        // AND that the password is not null and not empty.
        if (!InputValidator.isValidUsername(username) || password == null || password.length == 0) {
            // Log the failed attempt with the actor as "safe(username)" in case username is null.
            AuditLogger.warn(safe(username), "LOGIN", "BAD_INPUT");
            // Return failure. Note: we use the SAME message as a wrong password — on purpose.
            // If we said "invalid username format", an attacker learns the username is wrong format.
            return new AuthResult(AuthOutcome.BAD_INPUT, null,
                    "Invalid username or password.");
        }

        // ════════════════════════════════════════════════════════════════════
        // LAYER 2 — EXISTENCE CHECK (with timing protection)
        // Look up the user in the database.
        // ════════════════════════════════════════════════════════════════════

        // Try to find the user by username in users.dat (loaded into memory).
        User u = users.findByUsername(username);

        if (u == null) {
            // The username does NOT exist in the database.

            // SECURITY: we run a DUMMY hash check here — even though we know the user doesn't exist.
            // Why? Because PasswordHasher.verify() takes time (65,536 PBKDF2 iterations).
            // If we return immediately for non-existent users but take time for existing users,
            // an attacker can measure the response time and deduce which usernames exist.
            // By always running a hash, both paths take similar time → timing attack mitigated.
            // The fake salt and hash are valid Base64 — they just don't match anything real.
            PasswordHasher.verify(password,
                    "AAAAAAAAAAAAAAAAAAAAAA==",              // fake salt (valid Base64)
                    "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA="); // fake hash (valid Base64)

            AuditLogger.warn(username, "LOGIN", "NO_SUCH_USER");
            // Return the SAME generic message — never say "user not found".
            return new AuthResult(AuthOutcome.BAD_CREDENTIALS, null,
                    "Invalid username or password.");
        }

        // ════════════════════════════════════════════════════════════════════
        // LAYER 3 — ACCOUNT LOCKOUT CHECK
        // Reject locked accounts immediately — don't even check the password.
        // ════════════════════════════════════════════════════════════════════

        if (u.isLocked()) {
            // The account was locked (either by admin or by too many failed attempts).
            AuditLogger.warn(username, "LOGIN", "BLOCKED_LOCKED");
            // This time we DO reveal that the account is locked — the user needs to know
            // to contact the admin. This is acceptable because it's not information that
            // helps an attacker (they would still need the correct password AND unlock).
            return new AuthResult(AuthOutcome.ACCOUNT_LOCKED, null,
                    "Account is locked. Contact the System Admin.");
        }

        // ════════════════════════════════════════════════════════════════════
        // LAYER 4 — CRYPTOGRAPHIC PASSWORD VERIFICATION
        // Run PBKDF2 on the candidate password and compare to the stored hash.
        // ════════════════════════════════════════════════════════════════════

        // PasswordHasher.verify() returns true if the password is correct, false otherwise.
        // It uses the user's stored salt and hash from users.dat.
        boolean match = PasswordHasher.verify(password, u.getSalt(), u.getHash());

        if (!match) {
            // Wrong password.

            // Increment the failed attempt counter on the User object.
            u.incrementFailedAttempts();

            // Check if the number of failed attempts has reached the policy's maximum.
            if (u.getFailedAttempts() >= policy.getMaxLoginAttempts()) {
                // Threshold reached — lock the account immediately.
                u.setLocked(true);
                AuditLogger.warn(username, "LOGIN", "LOCKED_AFTER_ATTEMPTS");
            } else {
                // Not yet locked — just log the failed attempt with the current count.
                AuditLogger.warn(username, "LOGIN",
                        "BAD_PASSWORD attempt=" + u.getFailedAttempts());
            }

            // Save the updated failed-attempt count (and possibly locked=true) to the file.
            users.save(u);

            // Return the same generic message — never reveal whether the username or password was wrong.
            return new AuthResult(AuthOutcome.BAD_CREDENTIALS, null,
                    "Invalid username or password.");
        }

        // ════════════════════════════════════════════════════════════════════
        // SUCCESS — password was correct
        // ════════════════════════════════════════════════════════════════════

        // Reset the failed-attempt counter back to zero (a successful login clears the count).
        u.resetFailedAttempts();

        // Save the updated user (counter = 0) back to the file.
        users.save(u);

        // Record the successful login in the audit log.
        AuditLogger.log(username, "LOGIN", "OK");

        // Return a success result containing the User object and a welcome message.
        return new AuthResult(AuthOutcome.OK, u, "Welcome, " + u.getFullName() + ".");
    }

    // ── changePassword ────────────────────────────────────────────────────────
    // Replaces a user's password with a new one.
    // Validates the new password against the policy before hashing and saving.
    // Returns true if the change succeeded, false if it failed for any reason.
    public boolean changePassword(User user, char[] newPassword) {
        // Sanity check — neither argument should be null.
        if (user == null || newPassword == null) {
            return false;
        }

        // Check the new password against all policy rules (length, uppercase, digits, etc.).
        String violations = policy.describeViolations(newPassword);
        if (violations != null) {
            // Password does not meet the rules — log a warning and reject.
            AuditLogger.warn(user.getUsername(), "CHANGE_PASSWORD", "POLICY_VIOLATION");
            return false;
        }

        try {
            // Generate a brand-new random salt and hash the new password with it.
            // sh[0] = Base64 salt, sh[1] = Base64 hash
            String[] sh = PasswordHasher.hashWithNewSalt(newPassword);

            // Store the new salt and hash in the User object.
            user.setSaltAndHash(sh[0], sh[1]);

            // Persist the updated User to the file.
            users.save(user);

            // Log the successful password change.
            AuditLogger.log(user.getUsername(), "CHANGE_PASSWORD", "OK");

            return true; // Success

        } catch (Exception e) {
            // If the hashing fails for any reason (shouldn't happen on normal JVMs),
            // log the error and return false — never grant access on failure.
            AuditLogger.error("PBKDF2 failed in changePassword", e);
            return false;
        }
    }

    // ── safe (private helper) ─────────────────────────────────────────────────
    // Returns "(null)" if the string is null, otherwise returns the string as-is.
    // Used when logging, to avoid passing null to AuditLogger which would crash.
    private static String safe(String s) { return s == null ? "(null)" : s; }
}
