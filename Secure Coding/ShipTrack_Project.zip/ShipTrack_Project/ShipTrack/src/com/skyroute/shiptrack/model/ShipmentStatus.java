// This file belongs to the "model" package.
package com.skyroute.shiptrack.model;

// An enum representing the four possible states a shipment can be in.
// A shipment always moves FORWARD: PENDING → PICKED_UP → IN_TRANSIT → DELIVERED.
// It can never go backwards. This is enforced by the canMoveTo() method below.
public enum ShipmentStatus {

    // The initial state — shipment has been requested but not picked up yet.
    PENDING,

    // A driver has physically picked up the package.
    PICKED_UP,

    // The package is on its way to the destination.
    IN_TRANSIT,

    // The package has been delivered to the customer. This is the FINAL state — no further moves.
    DELIVERED;

    // ── fromString ──────────────────────────────────────────────────────────
    // Converts human-typed text into the matching ShipmentStatus enum value.
    // Tolerant: "in transit", "IN_TRANSIT", "in-transit" all give IN_TRANSIT.
    public static ShipmentStatus fromString(String s) {

        // Reject null input immediately.
        if (s == null) {
            throw new IllegalArgumentException("Status is required");
        }

        // Normalize the input the same way Role.fromString() does:
        // trim whitespace, convert to uppercase, replace spaces/dashes with underscores.
        String norm = s.trim().toUpperCase(java.util.Locale.ROOT).replace(' ', '_').replace('-', '_');

        // Loop through all enum values looking for a match.
        for (ShipmentStatus st : values()) {
            // st.name() returns the exact enum constant name, e.g. "IN_TRANSIT".
            if (st.name().equals(norm)) {
                return st; // Found a match — return it.
            }
        }

        // Nothing matched — throw an error with the bad input in the message.
        throw new IllegalArgumentException("Unknown status: " + s);
    }

    // ── label ───────────────────────────────────────────────────────────────
    // Returns a lowercase human-readable name for display in menus.
    // Example: IN_TRANSIT.label() → "in transit"
    public String label() {
        // name() returns the enum constant as-is, e.g. "IN_TRANSIT".
        // .toLowerCase(Locale.ROOT) → "in_transit"
        // .replace('_', ' ')        → "in transit"
        return name().toLowerCase(java.util.Locale.ROOT).replace('_', ' ');
    }

    // ── canMoveTo ───────────────────────────────────────────────────────────
    // This method is the STATE MACHINE GUARD.
    // It answers: "Is it legal to move from MY current state to the 'next' state?"
    // Returns true if the move is allowed, false if it is not.
    //
    // Allowed transitions:
    //   PENDING    → PICKED_UP  (driver picks it up)
    //   PENDING    → IN_TRANSIT (dispatcher skips picked-up state)
    //   PICKED_UP  → IN_TRANSIT (driver marks it in transit)
    //   PICKED_UP  → DELIVERED  (unusual but allowed)
    //   IN_TRANSIT → DELIVERED  (driver delivers it)
    //   DELIVERED  → (nothing)  DELIVERED is a terminal state — no further moves.
    public boolean canMoveTo(ShipmentStatus next) {

        // Reject null (no status given) or trying to "move" to the same state you're already in.
        if (next == null || next == this) {
            return false;
        }

        // Check the allowed transitions based on the CURRENT state (this).
        switch (this) {
            // From PENDING: can move to PICKED_UP or IN_TRANSIT.
            case PENDING:    return next == PICKED_UP || next == IN_TRANSIT;

            // From PICKED_UP: can move to IN_TRANSIT or DELIVERED.
            case PICKED_UP:  return next == IN_TRANSIT || next == DELIVERED;

            // From IN_TRANSIT: can only move to DELIVERED.
            case IN_TRANSIT: return next == DELIVERED;

            // From DELIVERED: no moves allowed — this is the end state.
            case DELIVERED:  return false;

            // Default fallback (never actually reached with a proper enum).
            default:         return false;
        }
    }
}
