// This file belongs to the "util" package.
package com.skyroute.shiptrack.util;

// Scanner is Java's built-in class for reading text typed by the user in the terminal.
import java.util.Scanner;

// "public class ConsoleUI" — a regular class (not final, not static).
// This class wraps Scanner and provides a consistent, clean interface for all menus.
// Quality principle: every menu uses the same helper, so error messages, trimming,
// and prompts are consistent across the whole application.
public class ConsoleUI {

    // The scanner object that reads keyboard input.
    // "private final" = only this class can use it, and it is set once in the constructor and never changed.
    private final Scanner scanner;

    // ── CONSTRUCTOR ──────────────────────────────────────────────────────────
    // The Scanner is passed in ("injected") rather than created inside this class.
    // This makes testing easier — in tests you can pass a Scanner that reads from a
    // pre-written string instead of waiting for real keyboard input.
    public ConsoleUI(Scanner scanner) {
        this.scanner = scanner; // Store the scanner for use in all the methods below.
    }

    // ── prompt ───────────────────────────────────────────────────────────────
    // Prints a label (like "Username: ") on the screen, waits for the user to type,
    // and returns what they typed with whitespace removed from the start and end.
    // Never returns null — returns "" if the input was somehow null.
    public String prompt(String label) {
        System.out.print(label);     // Print the label WITHOUT a newline (cursor stays on same line).
        String line = scanner.nextLine(); // Read the entire line the user types (until Enter).
        // If nextLine() somehow returns null (rare EOF), return empty string instead.
        // Otherwise return the input with leading/trailing spaces removed (.trim()).
        return line == null ? "" : line.trim();
    }

    // ── promptInt ────────────────────────────────────────────────────────────
    // Prints a label, waits for the user to type a whole number, and returns it.
    // If the user types something that is NOT a number, it politely asks again.
    // This loops forever until the user types a valid integer.
    public int promptInt(String label) {
        while (true) { // Keep asking until we get a valid number.
            String s = prompt(label); // Get whatever the user typed.
            try {
                // Integer.parseInt("42") converts the text "42" to the number 42.
                return Integer.parseInt(s); // If this succeeds, return the number.
            } catch (NumberFormatException nfe) {
                // If the user typed "abc" or "3.14", parseInt throws NumberFormatException.
                // We catch it here and print a friendly message, then the loop repeats.
                System.out.println("  Please enter a whole number.");
            }
        }
    }

    // ── promptPassword ───────────────────────────────────────────────────────
    // Prints a label and reads a password from the user.
    // Tries to use the system console so the password is hidden while typing.
    // Falls back to the Scanner if running inside Eclipse (where console is not available).
    //
    // WHY char[] INSTEAD OF String?
    // String objects in Java are immutable — once created, they stay in memory until the
    // garbage collector removes them (which you cannot control). An attacker who dumps memory
    // could find the password still sitting there.
    // char[] (an array of characters) can be manually wiped by writing zeros into it:
    //   Arrays.fill(password, '\0')
    // This removes the password from memory as soon as we're done with it.
    public char[] promptPassword(String label) {
        // System.console() returns the real terminal console, but it is null when
        // running inside Eclipse's built-in console. In a real terminal, passwords are hidden.
        if (System.console() != null) {
            // readPassword() hides what the user types — no echo on screen. Returns char[].
            return System.console().readPassword(label);
        }
        // Fallback for Eclipse: just read the password visibly (it will show on screen).
        System.out.print(label);         // Print the label.
        String line = scanner.nextLine();  // Read the password as a normal line.
        // .toCharArray() converts the String "abc" to the char array ['a','b','c'].
        // This is better than keeping it as a String for the memory-wiping reason above.
        return line.toCharArray();
    }

    // ── println ───────────────────────────────────────────────────────────────
    // Prints a line of text followed by a newline. Used for normal output.
    public void println(String s) { System.out.println(s); }

    // ── error ─────────────────────────────────────────────────────────────────
    // Prints an error message with a "[error]" prefix. Used when something goes wrong.
    public void error(String s)   { System.out.println("  [error] " + s); }

    // ── info ──────────────────────────────────────────────────────────────────
    // Prints an informational message with 2 spaces of indentation. Used for soft notices.
    public void info(String s)    { System.out.println("  " + s); }
}
