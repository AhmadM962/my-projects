// This file belongs to the "model" package.
package com.skyroute.shiptrack.model;

// Import for working with dates and times (LocalDateTime = date + time without timezone).
import java.time.LocalDateTime;

// Import for formatting/parsing dates into/from text.
import java.time.format.DateTimeFormatter;

// Import Constants so we can use the field separator character defined there.
import com.skyroute.shiptrack.util.Constants;

// This class is the blueprint for a single package shipment.
// Each shipment has an ID, knows which customer ordered it, which driver carries it,
// what the package is, what state it's in (pending/in-transit/etc.) and when it was created.
public class Shipment {

    // A formatter that converts LocalDateTime to/from ISO format: "2025-05-27T14:30:00"
    // "static final" means one shared formatter for all Shipment objects — more efficient.
    private static final DateTimeFormatter TS = DateTimeFormatter.ISO_LOCAL_DATE_TIME;

    // ── FIELDS ───────────────────────────────────────────────────────────────

    // The unique ID for this shipment, e.g. "S0001-12345". final = never changes.
    private final String id;

    // The username of the customer who created this shipment. final = never changes.
    private final String customerUsername;

    // The username of the driver assigned to deliver this shipment.
    // NOT final — starts empty and is set later when a dispatcher assigns a driver.
    private String driverUsername;

    // A short text description of what is in the package (e.g. "Fragile glassware").
    // final = the description of a package never changes.
    private final String description;

    // The current delivery state: PENDING, PICKED_UP, IN_TRANSIT, or DELIVERED.
    // NOT final — this changes as the package moves through the delivery process.
    private ShipmentStatus status;

    // The exact date and time this shipment was created. final = never changes.
    private final LocalDateTime createdAt;

    // ── CONSTRUCTOR ──────────────────────────────────────────────────────────
    // This constructor creates a Shipment object from all its parts.
    // It is used when loading a shipment from the file (fromRecord) or creating a new one.
    public Shipment(String id, String customerUsername, String driverUsername,
                    String description, ShipmentStatus status, LocalDateTime createdAt) {
        this.id               = id;               // Store the shipment ID
        this.customerUsername = customerUsername;  // Store who ordered it
        // If driverUsername is null (not yet assigned), store empty string "" instead.
        // The ternary "x == null ? "" : x" means: if x is null use "", otherwise use x.
        this.driverUsername   = driverUsername == null ? "" : driverUsername;
        this.description      = description;      // Store the package description
        this.status           = status;           // Store the current delivery status
        this.createdAt        = createdAt;        // Store the creation timestamp
    }

    // ── FACTORY METHOD ────────────────────────────────────────────────────────
    // A "factory method" is a static method that creates and returns a new object.
    // This one is a convenient shortcut for creating a brand-new shipment request.
    // All new shipments start as PENDING with no driver assigned yet.
    public static Shipment newRequest(String id, String customerUsername, String description) {
        // Call the full constructor with:
        //   - empty string "" for driverUsername (no driver yet)
        //   - ShipmentStatus.PENDING as the starting status
        //   - LocalDateTime.now() as the creation time (current moment)
        return new Shipment(id, customerUsername, "", description,
                ShipmentStatus.PENDING, LocalDateTime.now());
    }

    // ── GETTERS ──────────────────────────────────────────────────────────────
    // Methods that allow other classes to READ the private fields.

    public String         getId()               { return id; }               // Returns the shipment ID
    public String         getCustomerUsername() { return customerUsername; }  // Returns who ordered it
    public String         getDriverUsername()   { return driverUsername; }    // Returns the assigned driver
    public String         getDescription()      { return description; }       // Returns the package description
    public ShipmentStatus getStatus()           { return status; }            // Returns current state
    public LocalDateTime  getCreatedAt()        { return createdAt; }         // Returns creation timestamp

    // ── assignDriver ─────────────────────────────────────────────────────────
    // Sets the driver for this shipment. Called by the Dispatcher when assigning a delivery.
    public void assignDriver(String driverUsername) {
        // Reject null or empty driver username — a real driver username is required.
        if (driverUsername == null || driverUsername.isEmpty()) {
            throw new IllegalArgumentException("Driver username required");
        }
        // Store the driver's username.
        this.driverUsername = driverUsername;
    }

    // ── advanceTo ────────────────────────────────────────────────────────────
    // Tries to move the shipment to the given next status.
    // Returns true if the move was allowed and done, false if the move is illegal.
    // The actual rules for what moves are legal live in ShipmentStatus.canMoveTo().
    public boolean advanceTo(ShipmentStatus next) {
        // Ask the current status if it's allowed to move to "next".
        // If not allowed, return false — the caller must show an error to the user.
        if (!status.canMoveTo(next)) {
            return false;
        }
        // The move is legal — update the status field.
        this.status = next;
        // Tell the caller the move succeeded.
        return true;
    }

    // ── toRecord ─────────────────────────────────────────────────────────────
    // Converts this Shipment to a single pipe-separated line for saving to shipments.dat.
    // Example: "S0001-12345|alice|bob_driver|Fragile glassware|IN_TRANSIT|2025-05-27T14:30:00"
    public String toRecord() {
        return String.join(Constants.FIELD_SEPARATOR,
                id,                                   // field 1: shipment ID
                customerUsername,                     // field 2: customer's username
                driverUsername,                       // field 3: driver's username (or "")
                description.replace('|', '/'),        // field 4: description — replace any "|" with "/" for safety
                status.name(),                        // field 5: status as text (e.g. "IN_TRANSIT")
                createdAt.format(TS));                // field 6: date/time as ISO text
    }

    // ── fromRecord ───────────────────────────────────────────────────────────
    // Reads one line from shipments.dat and converts it back into a Shipment object.
    // This is the reverse of toRecord().
    public static Shipment fromRecord(String line) {
        // Split at each pipe "|" into an array. -1 keeps trailing empty fields.
        String[] parts = line.split(Constants.FIELD_SEPARATOR_REGEX, -1);

        // A shipment line must have exactly 6 fields. Anything else means the file is corrupt.
        if (parts.length != 6) {
            throw new IllegalArgumentException("Bad shipment record");
        }

        // Build and return a Shipment from the 6 parsed fields.
        return new Shipment(
                parts[0],                           // id (field 1)
                parts[1],                           // customerUsername (field 2)
                parts[2],                           // driverUsername (field 3)
                parts[3],                           // description (field 4)
                ShipmentStatus.valueOf(parts[4]),   // status: converts "IN_TRANSIT" → ShipmentStatus.IN_TRANSIT (field 5)
                LocalDateTime.parse(parts[5], TS)  // createdAt: parses ISO text back into a LocalDateTime (field 6)
        );
    }

    // ── toString ─────────────────────────────────────────────────────────────
    // Called automatically when a Shipment is printed or used in a string.
    // Example output: "S0001-12345 [in transit] customer=alice driver=bob_driver desc=Fragile glassware"
    @Override
    public String toString() {
        return String.format("%s [%s] customer=%s driver=%s desc=%s",
                id,                                                    // shipment ID
                status.label(),                                        // human-readable status
                customerUsername,                                      // who ordered it
                driverUsername.isEmpty() ? "(none)" : driverUsername,  // driver, or "(none)" if not assigned yet
                description);                                          // package description
    }
}
