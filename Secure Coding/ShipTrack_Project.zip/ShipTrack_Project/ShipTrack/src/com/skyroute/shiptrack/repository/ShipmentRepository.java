// This file belongs to the "repository" package.
package com.skyroute.shiptrack.repository;

// IOException is thrown when file operations fail.
import java.io.IOException;

// StandardCharsets.UTF_8 ensures consistent text encoding.
import java.nio.charset.StandardCharsets;

// Files provides static methods for file operations.
import java.nio.file.Files;

// Path represents a file path as an object.
import java.nio.file.Path;

// Paths converts a String path to a Path object.
import java.nio.file.Paths;

// StandardCopyOption provides ATOMIC_MOVE and REPLACE_EXISTING for safe file moves.
import java.nio.file.StandardCopyOption;

// ArrayList is a resizable list for collecting shipments.
import java.util.ArrayList;

// Collections.unmodifiableList prevents callers from modifying the returned list.
import java.util.Collections;

// HashMap maps shipment ID (String) → Shipment object for fast lookups.
import java.util.HashMap;

// List is the interface for ordered collections.
import java.util.List;

// Map is the interface for key-value collections.
import java.util.Map;

// Shipment is the data object we load and save.
import com.skyroute.shiptrack.model.Shipment;

// AuditLogger records errors and events during file operations.
import com.skyroute.shiptrack.util.AuditLogger;

// Constants holds the shipments file path and other shared values.
import com.skyroute.shiptrack.util.Constants;

// "public class ShipmentRepository" — manages reading and writing shipments.dat.
// Uses the same ATOMIC WRITE pattern as UserRepository to prevent file corruption.
// Quality principle (Reusability): this follows the same design as UserRepository.
// If a third repository were ever needed, we would extract a shared base class.
public class ShipmentRepository {

    // ── FIELDS ───────────────────────────────────────────────────────────────

    // Path to the shipments data file ("data/shipments.dat"). Set once, never changed.
    private final Path file;

    // In-memory map: shipment ID (String) → Shipment object.
    // Allows instant lookup of any shipment by its ID.
    private final Map<String, Shipment> byId = new HashMap<>();

    // ── CONSTRUCTOR ───────────────────────────────────────────────────────────
    // Sets up the file path, ensures the data/ folder exists, and loads all shipments.
    public ShipmentRepository() {
        this.file = Paths.get(Constants.SHIPMENTS_FILE); // "data/shipments.dat" as a Path
        ensureDir(); // Create the data/ folder if missing
        load();      // Load all shipments from the file into the HashMap
    }

    // ── ensureDir ─────────────────────────────────────────────────────────────
    // Creates the data/ directory if it doesn't exist yet.
    private void ensureDir() {
        try {
            Path dir = Paths.get(Constants.DATA_DIR); // Path to "data/"
            if (!Files.exists(dir)) {                 // If data/ doesn't exist...
                Files.createDirectories(dir);          // ...create it.
            }
        } catch (IOException e) {
            AuditLogger.error("Cannot create data dir", e); // Log but don't crash.
        }
    }

    // ── load ──────────────────────────────────────────────────────────────────
    // Reads all shipments from shipments.dat into the in-memory HashMap.
    // "synchronized" = only one thread can run this at a time (thread safety).
    public synchronized void load() {
        byId.clear(); // Start fresh — remove any previously loaded shipments.

        // If the file doesn't exist yet (first run, no shipments), skip reading.
        if (!Files.exists(file)) {
            return;
        }

        try {
            // Read every line of the file. Each line = one shipment.
            for (String line : Files.readAllLines(file, StandardCharsets.UTF_8)) {
                if (line.isEmpty()) { // Skip blank lines.
                    continue;
                }
                try {
                    Shipment s = Shipment.fromRecord(line); // Parse the line into a Shipment object.
                    byId.put(s.getId(), s); // Add to the HashMap (shipment ID → Shipment).
                } catch (RuntimeException re) {
                    // If one line is corrupt, skip it and log a warning. Don't crash.
                    AuditLogger.warn("system", "LOAD_SHIPMENT", re.getMessage());
                }
            }
        } catch (IOException ioe) {
            AuditLogger.error("Failed to read shipments file", ioe);
        }
    }

    // ── findById ──────────────────────────────────────────────────────────────
    // Looks up a shipment by its ID string (e.g. "S0001-12345").
    // Returns null if no shipment with that ID exists.
    public synchronized Shipment findById(String id) {
        return byId.get(id); // HashMap lookup — instant.
    }

    // ── findAll ───────────────────────────────────────────────────────────────
    // Returns all shipments as a sorted, unmodifiable list (sorted by ID alphabetically).
    public synchronized List<Shipment> findAll() {
        List<Shipment> list = new ArrayList<>(byId.values()); // Copy all values into a list.
        list.sort((a, b) -> a.getId().compareTo(b.getId())); // Sort by ID alphabetically.
        return Collections.unmodifiableList(list); // Return a read-only view.
    }

    // ── findByCustomer ────────────────────────────────────────────────────────
    // Returns all shipments that belong to the given customer.
    // Used by CustomerMenu so customers can only see THEIR own shipments (Least Privilege).
    public synchronized List<Shipment> findByCustomer(String customerUsername) {
        List<Shipment> out = new ArrayList<>();
        for (Shipment s : byId.values()) {
            // Check if this shipment's customer username matches the requested username.
            if (s.getCustomerUsername().equals(customerUsername)) {
                out.add(s); // Only add shipments belonging to this customer.
            }
        }
        return out;
    }

    // ── findByDriver ──────────────────────────────────────────────────────────
    // Returns all shipments assigned to the given driver.
    // Used by DriverMenu so drivers can only see THEIR assigned deliveries (Least Privilege).
    public synchronized List<Shipment> findByDriver(String driverUsername) {
        List<Shipment> out = new ArrayList<>();
        for (Shipment s : byId.values()) {
            // Check if this shipment's driver username matches.
            if (driverUsername.equals(s.getDriverUsername())) {
                out.add(s); // Only add shipments assigned to this driver.
            }
        }
        return out;
    }

    // ── nextId ────────────────────────────────────────────────────────────────
    // Generates a unique ID for a new shipment.
    // Format: "S" + 4-digit count padded with zeros + "-" + last 5 digits of timestamp.
    // Example: "S0001-12345" for the first shipment.
    // "synchronized" = only one thread at a time, preventing duplicate IDs.
    public synchronized String nextId() {
        // byId.size() + 1 → the next shipment number (e.g. 1, 2, 3...).
        // %04d formats it with leading zeros to 4 digits: 1 → "0001".
        // System.currentTimeMillis() returns the current time in milliseconds since 1970.
        // % 100000 takes the last 5 digits — a timestamp suffix to make IDs unique even after restart.
        return String.format("S%04d-%d", byId.size() + 1, System.currentTimeMillis() % 100000);
    }

    // ── save ──────────────────────────────────────────────────────────────────
    // Inserts or updates a shipment in the in-memory map, then writes all shipments to disk.
    public synchronized void save(Shipment s) {
        byId.put(s.getId(), s); // Insert or replace in the HashMap.
        persistAll();           // Write the updated map to disk.
    }

    // ── persistAll ───────────────────────────────────────────────────────────
    // Writes all shipments to disk using the ATOMIC WRITE pattern (same as UserRepository).
    // Steps: write to temp file → atomically rename temp file to shipments.dat.
    // This prevents data corruption if the app crashes mid-write.
    private void persistAll() {
        Path tmp = null;
        try {
            // Create a temp file in the data/ directory (e.g. "shipments3829475.tmp").
            tmp = Files.createTempFile(Paths.get(Constants.DATA_DIR), "shipments", ".tmp");

            // Build a list of strings — one record per shipment.
            List<String> lines = new ArrayList<>();
            for (Shipment s : byId.values()) {
                lines.add(s.toRecord()); // Convert each Shipment to a pipe-separated line.
            }

            // Write all lines to the temp file.
            Files.write(tmp, lines, StandardCharsets.UTF_8);

            // Atomically rename the temp file to shipments.dat.
            // If this succeeds, shipments.dat is the new complete file.
            // If the computer crashes before this, shipments.dat is still the old complete file.
            Files.move(tmp, file,
                    StandardCopyOption.REPLACE_EXISTING,
                    StandardCopyOption.ATOMIC_MOVE);

        } catch (IOException ioe) {
            AuditLogger.error("Failed to persist shipments", ioe);
            // Try to clean up the temp file to avoid disk clutter.
            if (tmp != null) {
                try {
                    Files.deleteIfExists(tmp);
                } catch (IOException ignore) {
                    System.err.println("[Cleanup] Could not delete temp file: " + ignore.getMessage());
                }
            }
        }
    }
}
