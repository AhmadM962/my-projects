// This file belongs to the "ui" package.
package com.skyroute.shiptrack.ui;

// List is the interface for ordered collections (used when listing deliveries).
import java.util.List;

// Shipment is the data class for package deliveries.
import com.skyroute.shiptrack.model.Shipment;

// ShipmentStatus is the enum of delivery states (PENDING, PICKED_UP, IN_TRANSIT, DELIVERED).
import com.skyroute.shiptrack.model.ShipmentStatus;

// User is the data class for the logged-in driver.
import com.skyroute.shiptrack.model.User;

// ShipmentRepository reads and writes shipments.dat.
import com.skyroute.shiptrack.repository.ShipmentRepository;

// AuditLogger records every driver action to audit.log.
import com.skyroute.shiptrack.util.AuditLogger;

// ConsoleUI provides the prompt/print/error methods for terminal interaction.
import com.skyroute.shiptrack.util.ConsoleUI;

// "public class DriverMenu" — the screen that delivery drivers see after login.
// Drivers can ONLY:
//   - View the shipments that are ASSIGNED TO THEM
//   - Update the status of shipments that are ASSIGNED TO THEM
// Security principle (Least Privilege):
//   - Drivers cannot see other drivers' shipments.
//   - Drivers cannot update shipments not assigned to them.
//   - Drivers cannot revert a shipment back to PENDING.
public class DriverMenu {

    // ── FIELDS ───────────────────────────────────────────────────────────────

    private final ConsoleUI io;               // For printing and reading input
    private final User me;                    // The currently logged-in driver
    private final ShipmentRepository shipments; // For reading and updating shipments

    // ── CONSTRUCTOR ──────────────────────────────────────────────────────────
    // Note: DriverMenu does NOT receive UserRepository — drivers don't manage users.
    // This limits the driver's access to only what they need (Least Privilege).
    public DriverMenu(ConsoleUI io, User me, ShipmentRepository shipments) {
        this.io        = io;        // Store the console UI helper
        this.me        = me;        // Store the logged-in driver
        this.shipments = shipments; // Store the shipment repository
    }

    // ── run ───────────────────────────────────────────────────────────────────
    // The main loop for the Driver Menu. Shows options and processes choices.
    public void run() {
        while (true) { // Keep showing the menu until the driver logs out.
            io.println("");
            // Print the menu header with the driver's username.
            io.println("=== Delivery Personnel Menu (" + me.getUsername() + ") ===");
            io.println("1) View my assigned deliveries"); // See only shipments assigned to this driver
            io.println("2) Update status of a delivery"); // Advance a shipment's status
            io.println("0) Logout");                     // Exit the menu

            int choice = io.promptInt("> "); // Read the driver's choice.

            switch (choice) {
                case 1: viewMine();     break; // Show assigned deliveries
                case 2: updateStatus(); break; // Update status
                case 0: return;                // Exit the loop (logs out)
                default: io.error("Unknown option."); // Invalid input
            }
        }
    }

    // ── viewMine ─────────────────────────────────────────────────────────────
    // Shows all shipments that are currently assigned to this driver.
    // Security: findByDriver() filters by driverUsername so the driver NEVER
    // sees another driver's deliveries.
    private void viewMine() {
        // Get only shipments where driverUsername matches this driver's username.
        List<Shipment> mine = shipments.findByDriver(me.getUsername());

        if (mine.isEmpty()) {
            io.info("No assigned deliveries."); // Tell them nothing is assigned yet.
            return;
        }

        io.println(""); // Blank line for readability.
        // Print each shipment. s.toString() gives e.g.:
        //   "S0001-12345 [in transit] customer=alice driver=bob_driver desc=Fragile glassware"
        for (Shipment s : mine) {
            io.println("  " + s);
        }
    }

    // ── updateStatus ──────────────────────────────────────────────────────────
    // Moves a shipment to a new status. Drivers can set: picked up, in transit, delivered.
    // They CANNOT revert to PENDING and CANNOT update shipments not assigned to them.
    private void updateStatus() {
        // Ask the driver which shipment they want to update.
        String shipId = io.prompt("Shipment ID: ");

        // Look up the shipment by ID in the repository.
        Shipment s = shipments.findById(shipId);
        if (s == null) { io.error("No such shipment."); return; } // Not found — stop.

        // ── CRITICAL SECURITY CHECK ─────────────────────────────────────────
        // A driver can ONLY update shipments assigned to THEM.
        // me.getUsername() = the logged-in driver's username.
        // s.getDriverUsername() = the username stored on the shipment.
        // If these don't match, the driver is trying to update someone else's delivery — reject it.
        if (!me.getUsername().equals(s.getDriverUsername())) {
            io.error("That shipment is not assigned to you.");
            // Log this as a WARNING — this is a potential security incident.
            // Either the driver made a mistake, or they're deliberately probing.
            AuditLogger.warn(me.getUsername(), "UPDATE_STATUS", "DENIED " + shipId);
            return;
        }

        // Tell the driver what statuses they can set.
        io.println("Allowed: picked up | in transit | delivered");

        // Read the status text the driver types.
        String label = io.prompt("New status: ");

        // Convert the text to a ShipmentStatus enum value.
        ShipmentStatus next;
        try {
            // fromString() is tolerant: "picked up", "PICKED_UP", "picked-up" all work.
            next = ShipmentStatus.fromString(label);
        } catch (RuntimeException re) {
            // The text didn't match any known status.
            io.error("Invalid status."); return;
        }

        // Security rule: drivers cannot revert a shipment back to PENDING.
        // PENDING means "not yet picked up" — if a driver has it, it can't be "pending" anymore.
        // Allowing this would let a driver hide that they picked up a package.
        if (next == ShipmentStatus.PENDING) {
            io.error("Drivers cannot revert to 'pending'.");
            return;
        }

        // Try to advance the shipment's status using the state machine.
        // advanceTo() checks ShipmentStatus.canMoveTo() to verify the transition is legal.
        // For example, you cannot go from DELIVERED back to IN_TRANSIT.
        if (!s.advanceTo(next)) {
            io.error("Illegal transition from " + s.getStatus().label()
                    + " to " + next.label() + ".");
            return;
        }

        // Save the updated shipment to the file.
        shipments.save(s);

        // Log the status change: "S0001-12345 -> picked up"
        AuditLogger.log(me.getUsername(), "UPDATE_STATUS", shipId + " -> " + next.label());

        io.println("Status updated."); // Confirm to driver.
    }
}
