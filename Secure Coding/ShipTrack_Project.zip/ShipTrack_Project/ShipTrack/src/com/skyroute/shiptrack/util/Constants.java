// This file belongs to the "util" package — a folder of helper classes used everywhere in the app.
package com.skyroute.shiptrack.util;

// "public final class" means:
//   - public  → any other file in the project can use this class
//   - final   → no other class is allowed to extend (inherit from) this class
// This class is a "bag of constants" — it only holds fixed values, no logic.
public final class Constants {

    // private constructor means nobody can write "new Constants()" to create an object.
    // This enforces that Constants is used as a namespace, not as an actual object.
    private Constants() {
        // Empty on purpose — this constructor should never be called.
    }

    // ── FILE PATHS ──────────────────────────────────────────────────────────
    // All data files live inside a folder called "data/" next to where you run the app.
    // Keeping paths in one place means if you rename the folder, you only edit it here.

    // The folder where all data files are stored.
    public static final String DATA_DIR       = "data";

    // The file that stores all user accounts (one user per line).
    public static final String USERS_FILE     = "data/users.dat";

    // The file that stores all shipment records (one shipment per line).
    public static final String SHIPMENTS_FILE = "data/shipments.dat";

    // The file that stores the admin-configured password rules.
    public static final String POLICY_FILE    = "data/policy.cfg";

    // The file that records every security event (login, lockout, etc.).
    public static final String AUDIT_LOG      = "data/audit.log";

    // ── FILE-FORMAT SEPARATORS ──────────────────────────────────────────────
    // We separate fields on each line with the pipe "|" character.
    // Example line in users.dat: alice|CUSTOMER|saltValue|hashValue|false|0|Alice Smith|12345|0797000001
    // The pipe character is safe because InputValidator rejects it from user input.

    // The actual character used between fields when saving to a file.
    public static final String FIELD_SEPARATOR       = "|";

    // The same character but written as a regex pattern.
    // In regex, "|" means "or", so we must escape it with "\|".
    // In Java strings, a backslash needs to be written as "\\", so we write "\\|".
    public static final String FIELD_SEPARATOR_REGEX = "\\|";

    // ── CRYPTOGRAPHIC PARAMETERS ────────────────────────────────────────────
    // These control how passwords are hashed (turned into unreadable scrambled bytes).
    // We use the PBKDF2-HMAC-SHA256 algorithm — a standard approved by NIST and OWASP.

    // How many times the hash function is repeated. More = slower for attackers to brute-force.
    // 65,536 is the OWASP (security standards body) minimum recommendation.
    // The underscore in 65_536 is just a readability separator — Java ignores it.
    public static final int    PBKDF2_ITERATIONS = 65_536;

    // The length of the output hash, measured in bits. 256 bits = 32 bytes.
    public static final int    PBKDF2_KEY_LENGTH = 256;

    // How many random bytes to use for the salt. 16 bytes = 128 bits of randomness.
    // A salt is random data mixed into the password before hashing.
    // This makes two users with the same password have completely different stored hashes.
    public static final int    SALT_LENGTH_BYTES = 16;

    // The official Java name for the PBKDF2 algorithm we want to use.
    // This exact string is required by Java's built-in security library (javax.crypto).
    public static final String PBKDF2_ALGORITHM  = "PBKDF2WithHmacSHA256";

    // ── DEFAULT PASSWORD POLICY ──────────────────────────────────────────────
    // These are the starting rules for password strength. The admin can change them at runtime.

    // A password must be at least 8 characters long.
    public static final int DEFAULT_MIN_LENGTH   = 8;

    // A password must contain at least 1 uppercase letter (A-Z).
    public static final int DEFAULT_MIN_UPPER    = 1;

    // A password must contain at least 1 lowercase letter (a-z).
    public static final int DEFAULT_MIN_LOWER    = 1;

    // A password must contain at least 1 digit (0-9).
    public static final int DEFAULT_MIN_DIGIT    = 1;

    // A password must contain at least 1 special character (like !, @, #).
    public static final int DEFAULT_MIN_SPECIAL  = 1;

    // After 3 wrong password attempts in a row, the account gets locked.
    public static final int DEFAULT_MAX_ATTEMPTS = 3;

    // ── DEFAULT ADMIN CREDENTIALS ────────────────────────────────────────────
    // On the very first run there are no users yet, so we create one admin automatically.
    // The admin MUST change this password before they can do anything — enforced in AdminMenu.

    // The username for the auto-created first admin account.
    public static final String DEFAULT_ADMIN_USERNAME = "admin";

    // The default password for the auto-created first admin account.
    // This is shown on screen so the admin knows how to log in on first run.
    public static final String DEFAULT_ADMIN_PASSWORD = "Admin@123";
}
