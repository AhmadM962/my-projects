// This file belongs to the "ui" package.
package com.skyroute.shiptrack.ui;

// List is the interface for ordered collections (used when listing shipments).
import java.util.List;

// Role is needed to verify that a user being assigned is actually a driver.
import com.skyroute.shiptrack.model.Role;

// Shipment is the data class for package deliveries.
import com.skyroute.shiptrack.model.Shipment;

// ShipmentStatus is the enum of delivery states (PENDING, PICKED_UP, IN_TRANSIT, DELIVERED).
import com.skyroute.shiptrack.model.ShipmentStatus;

// User is the data class for user accounts.
import com.skyroute.shiptrack.model.User;

// ShipmentRepository reads and writes shipments.dat.
import com.skyroute.shiptrack.repository.ShipmentRepository;

// UserRepository is needed to look up drivers by username.
import com.skyroute.shiptrack.repository.UserRepository;

// AuditLogger records every dispatcher action to audit.log.
import com.skyroute.shiptrack.util.AuditLogger;

// ConsoleUI provides the prompt/print/error methods for terminal interaction.
import com.skyroute.shiptrack.util.ConsoleUI;

// InputValidator validates names and phone numbers when the dispatcher edits their profile.
import com.skyroute.shiptrack.util.InputValidator;

// "public class DispatcherMenu" — the screen that dispatchers see after login.
// Dispatchers can assign shipments to drivers, update statuses, and view all shipments.
// They can also update their own profile (name and phone number).
public class DispatcherMenu {

    // ── FIELDS ───────────────────────────────────────────────────────────────

    private final ConsoleUI io;               // For printing and reading input
    private final User me;                    // The currently logged-in dispatcher
    private final UserRepository users;       // For looking up driver accounts
    private final ShipmentRepository shipments; // For reading and updating shipments

    // ── CONSTRUCTOR ──────────────────────────────────────────────────────────
    public DispatcherMenu(ConsoleUI io, User me,
                          UserRepository users, ShipmentRepository shipments) {
        this.io        = io;        // Store the console UI helper
        this.me        = me;        // Store the logged-in dispatcher
        this.users     = users;     // Store the user repository
        this.shipments = shipments; // Store the shipment repository
    }

    // ── run ───────────────────────────────────────────────────────────────────
    // The main loop for the Dispatcher Menu. Shows options and processes choices.
    public void run() {
        while (true) { // Keep showing the menu until the dispatcher logs out.
            io.println("");
            // Print the menu header with the dispatcher's username.
            io.println("=== Dispatcher Menu (" + me.getUsername() + ") ===");
            io.println("1) Assign delivery to driver");  // Link a shipment to a driver
            io.println("2) Update delivery status");     // Move a shipment's status forward
            io.println("3) View all shipments");         // See every shipment in the system
            io.println("4) View / update my profile");   // Edit own name and phone number
            io.println("0) Logout");                    // Exit the menu

            int choice = io.promptInt("> "); // Read the dispatcher's choice.

            switch (choice) {
                case 1: assignDelivery(); break; // Go to assign flow
                case 2: updateStatus();   break; // Go to status update flow
                case 3: listShipments();  break; // Show all shipments
                case 4: editProfile();    break; // Edit profile
                case 0: return;                   // Exit the loop (logs out)
                default: io.error("Unknown option."); // Invalid input
            }
        }
    }

    // ── assignDelivery ────────────────────────────────────────────────────────
    // Links a shipment to a specific driver. The dispatcher chooses both.
    private void assignDelivery() {
        // Ask for the shipment ID (e.g. "S0001-12345").
        String shipId = io.prompt("Shipment ID: ");

        // Look up the shipment in the repository.
        Shipment s = shipments.findById(shipId);
        if (s == null) { io.error("No such shipment."); return; } // Not found — stop.

        // Ask for the driver's username.
        String driver = io.prompt("Driver username: ");

        // Look up the driver's account.
        User d = users.findByUsername(driver);

        // Security check: make sure the specified user exists AND has the DELIVERY_PERSONNEL role.
        // A dispatcher cannot accidentally assign a shipment to another dispatcher or an admin.
        if (d == null || d.getRole() != Role.DELIVERY_PERSONNEL) {
            io.error("That user is not a delivery person.");
            return;
        }

        // Set the driver on the shipment object. This throws if the username is empty.
        s.assignDriver(driver);

        // Save the updated shipment to the file.
        shipments.save(s);

        // Log the assignment: "S0001-12345 -> bob_driver"
        AuditLogger.log(me.getUsername(), "ASSIGN_DELIVERY", shipId + " -> " + driver);

        io.println("Assigned " + shipId + " to " + driver + "."); // Confirm to dispatcher.
    }

    // ── updateStatus ──────────────────────────────────────────────────────────
    // Moves a shipment to a new status. Dispatchers can set: pending, in transit, delivered.
    // They CANNOT set "picked up" — only drivers can do that.
    private void updateStatus() {
        // Ask for the shipment ID.
        String shipId = io.prompt("Shipment ID: ");

        // Look up the shipment.
        Shipment s = shipments.findById(shipId);
        if (s == null) { io.error("No such shipment."); return; } // Not found — stop.

        // Tell the dispatcher what statuses they're allowed to enter.
        io.println("Allowed: pending | in transit | delivered");

        // Read the status text the dispatcher types.
        String label = io.prompt("New status: ");

        // Convert the text to a ShipmentStatus enum value.
        ShipmentStatus next;
        try {
            // fromString() is tolerant: "in transit", "IN_TRANSIT", "in-transit" all work.
            next = ShipmentStatus.fromString(label);
        } catch (RuntimeException re) {
            // The text didn't match any known status.
            io.error("Invalid status."); return;
        }

        // Security rule: dispatchers cannot set PICKED_UP.
        // PICKED_UP is a driver-only state — it means the driver physically has the package.
        if (next == ShipmentStatus.PICKED_UP) {
            io.error("Dispatchers cannot set 'picked up' (driver-only state).");
            return;
        }

        // Try to advance the shipment's status using the state machine.
        // advanceTo() calls ShipmentStatus.canMoveTo() to check if the transition is legal.
        // Returns false if the move is not allowed (e.g. trying to go from DELIVERED → PENDING).
        if (!s.advanceTo(next)) {
            io.error("Illegal transition from " + s.getStatus().label() + " to " + next.label() + ".");
            return;
        }

        // Save the updated shipment to the file.
        shipments.save(s);

        // Log the status change: "S0001-12345 -> in transit"
        AuditLogger.log(me.getUsername(), "UPDATE_STATUS", shipId + " -> " + next.label());

        io.println("Status updated."); // Confirm to dispatcher.
    }

    // ── listShipments ─────────────────────────────────────────────────────────
    // Prints all shipments in the system (dispatchers can see everything).
    private void listShipments() {
        List<Shipment> all = shipments.findAll(); // Get all shipments sorted by ID.
        if (all.isEmpty()) { io.info("No shipments yet."); return; } // Nothing to show.

        io.println(""); // Blank line.
        // Print each shipment. s.toString() gives e.g. "S0001-12345 [in transit] customer=alice driver=bob desc=..."
        for (Shipment s : all) {
            io.println("  " + s);
        }
    }

    // ── editProfile ────────────────────────────────────────────────────────────
    // Allows the dispatcher to update their full name and/or phone number.
    private void editProfile() {
        // Show the dispatcher their current information.
        io.println("Current: " + me.getFullName() + " | id=" + me.getIdNumber()
                + " | phone=" + me.getContactNumber());

        // ── Update name (optional) ─────────────────────────────────────────
        String name = io.prompt("New full name (blank=keep): ");
        if (!name.isEmpty()) { // Only update if they typed something (blank = keep current).
            if (!InputValidator.isValidName(name)) { io.error("Invalid name."); return; }
            me.setFullName(name); // Update the name in the User object (in memory).
        }

        // ── Update phone (optional) ────────────────────────────────────────
        String phone = io.prompt("New phone (blank=keep): ");
        if (!phone.isEmpty()) { // Only update if they typed something.
            if (!InputValidator.isValidPhone(phone)) { io.error("Invalid phone."); return; }
            me.setContactNumber(phone); // Update the phone in the User object (in memory).
        }

        // Save the updated user to the file (even if nothing changed — harmless).
        users.save(me);

        // Log the profile update.
        AuditLogger.log(me.getUsername(), "UPDATE_PROFILE", "self");

        io.println("Profile saved."); // Confirm to dispatcher.
    }
}
