// This file belongs to the "repository" package — classes that read and write data files.
package com.skyroute.shiptrack.repository;

// IOException is thrown when file operations fail (disk full, missing permissions, etc.)
import java.io.IOException;

// StandardCharsets.UTF_8 ensures text is encoded consistently across all platforms.
import java.nio.charset.StandardCharsets;

// Files provides static methods for reading, writing, creating, and moving files.
import java.nio.file.Files;

// Path represents a file system path as an object.
import java.nio.file.Path;

// Paths converts a String like "data/users.dat" into a Path object.
import java.nio.file.Paths;

// StandardCopyOption provides options like ATOMIC_MOVE and REPLACE_EXISTING for file moves.
import java.nio.file.StandardCopyOption;

// For security exceptions thrown when hashing the default admin password.
import java.security.GeneralSecurityException;

// ArrayList is a resizable list — used to collect users for sorting and saving.
import java.util.ArrayList;

// Collections.unmodifiableList wraps a list so callers cannot accidentally modify it.
import java.util.Collections;

// HashMap is the in-memory map: maps username (String) → User object.
import java.util.HashMap;

// List is the interface (contract) for ordered collections.
import java.util.List;

// Map is the interface for key-value collections.
import java.util.Map;

// PasswordHasher hashes the default admin password when bootstrapping.
import com.skyroute.shiptrack.auth.PasswordHasher;

// Role is needed to identify admin accounts during bootstrapping.
import com.skyroute.shiptrack.model.Role;

// User is the data object we load and save.
import com.skyroute.shiptrack.model.User;

// AuditLogger records errors and events that happen during file operations.
import com.skyroute.shiptrack.util.AuditLogger;

// Constants holds file paths and default credentials.
import com.skyroute.shiptrack.util.Constants;

// "public class UserRepository" — manages reading and writing users.dat.
// Quality principle (Reliability): writes are ATOMIC — they use a temp file + rename
// so a crash mid-write can never corrupt the users file.
// Quality principle (Maintainability): the in-memory HashMap is always kept in sync
// with the file, so there's no complex caching or synchronization logic needed.
public class UserRepository {

    // ── FIELDS ───────────────────────────────────────────────────────────────

    // The path to the users data file (e.g. "data/users.dat").
    // "final" = set once in the constructor and never changed.
    private final Path file;

    // In-memory storage: maps each username (String) to its User object.
    // When we look up a user by username, this gives us the answer instantly (O(1) lookup).
    // This map is always kept in sync with the file on disk.
    private final Map<String, User> byUsername = new HashMap<>();

    // ── CONSTRUCTOR ───────────────────────────────────────────────────────────
    // Creates the repository, makes sure the data/ folder exists, and loads all users into memory.
    public UserRepository() {
        this.file = Paths.get(Constants.USERS_FILE); // Convert "data/users.dat" to a Path object
        ensureDataDir(); // Create the data/ directory if it doesn't exist
        load();          // Load all users from the file into the HashMap
    }

    // ── ensureDataDir ─────────────────────────────────────────────────────────
    // Makes sure the data/ directory exists before we try to read or write files inside it.
    private void ensureDataDir() {
        Path dir = Paths.get(Constants.DATA_DIR); // Path to "data/"
        try {
            if (!Files.exists(dir)) {             // If the directory doesn't exist yet...
                Files.createDirectories(dir);     // ...create it (and any parent folders needed).
            }
        } catch (IOException e) {
            AuditLogger.error("Cannot create data dir", e); // Log the error but don't crash.
        }
    }

    // ── load ──────────────────────────────────────────────────────────────────
    // Reads all users from users.dat into the in-memory HashMap.
    // "synchronized" means only one thread can run this at a time — prevents data corruption
    // if two threads tried to load simultaneously (important for correctness).
    public synchronized void load() {
        byUsername.clear(); // Remove any previously loaded users (start fresh).

        // If the file doesn't exist yet (first run), skip reading and just bootstrap the admin.
        if (!Files.exists(file)) {
            bootstrapAdminIfMissing();
            return; // Stop here — nothing to read.
        }

        try {
            // Read every line of the file into a List of Strings. Each line = one user.
            List<String> lines = Files.readAllLines(file, StandardCharsets.UTF_8);

            for (String line : lines) { // Loop through each line.
                if (line.isEmpty()) {   // Skip blank lines (e.g. trailing newline at end of file).
                    continue;
                }
                try {
                    User u = User.fromRecord(line); // Parse the line into a User object.
                    byUsername.put(u.getUsername(), u); // Add user to the HashMap (username → User).
                } catch (RuntimeException re) {
                    // If one line is corrupt (bad format), skip it and log a warning.
                    // Don't crash — a bad line should not prevent loading all other users.
                    AuditLogger.warn("system", "LOAD_USER", "BAD_RECORD: " + re.getMessage());
                }
            }
        } catch (IOException ioe) {
            // If the whole file can't be read (permissions, missing, etc.), log the error.
            AuditLogger.error("Failed to read users file", ioe);
        }

        // After loading, make sure there is at least one admin account.
        // If there isn't, create the default admin.
        bootstrapAdminIfMissing();
    }

    // ── bootstrapAdminIfMissing ───────────────────────────────────────────────
    // On the very first run (empty or no users.dat), automatically creates a default admin.
    // The admin is forced to change the password on first login (enforced in AdminMenu).
    private void bootstrapAdminIfMissing() {
        // .stream() makes the collection's values iterable in a functional style.
        // .anyMatch(condition) returns true if at least one User has Role.ADMIN.
        boolean hasAdmin = byUsername.values().stream().anyMatch(u -> u.getRole() == Role.ADMIN);

        if (hasAdmin) {
            return; // An admin already exists — nothing to do.
        }

        try {
            // Hash the default password "Admin@123" with a fresh random salt.
            // toCharArray() converts the String to a char[] for the hasher.
            String[] sh = PasswordHasher.hashWithNewSalt(
                    Constants.DEFAULT_ADMIN_PASSWORD.toCharArray());

            // Create the default admin User object.
            User admin = new User(
                    Constants.DEFAULT_ADMIN_USERNAME, // username: "admin"
                    Role.ADMIN,                       // role: ADMIN
                    sh[0], sh[1],                     // salt and hash of "Admin@123"
                    false, 0,                         // not locked, 0 failed attempts
                    "System Administrator",           // full name
                    "0000000000",                     // placeholder ID
                    "0000000000"                      // placeholder phone
            );

            // Add the admin to the in-memory map.
            byUsername.put(admin.getUsername(), admin);

            // Save to the file immediately.
            persistAll();

            // Log that a default admin was created — this is a security-relevant event.
            AuditLogger.warn("system", "BOOTSTRAP_ADMIN",
                    "default admin created — change password on first login");

        } catch (GeneralSecurityException gse) {
            // If hashing failed (extremely unlikely), log the error.
            AuditLogger.error("Failed to bootstrap admin", gse);
        }
    }

    // ── findByUsername ────────────────────────────────────────────────────────
    // Looks up a user by their username. Returns null if not found.
    // "synchronized" = thread-safe: only one thread can read at a time.
    public synchronized User findByUsername(String username) {
        return byUsername.get(username); // HashMap lookup — instant, returns null if not found.
    }

    // ── exists ────────────────────────────────────────────────────────────────
    // Returns true if a username is already taken, false if it is available.
    public synchronized boolean exists(String username) {
        return byUsername.containsKey(username); // Check if the username key is in the map.
    }

    // ── findAll ───────────────────────────────────────────────────────────────
    // Returns all users as a sorted, unmodifiable list (sorted alphabetically by username).
    // "unmodifiable" means callers cannot add or remove users from the returned list —
    // they must go through save() and remove() to make changes.
    public synchronized List<User> findAll() {
        List<User> list = new ArrayList<>(byUsername.values()); // Copy all values into a new list.
        // Sort alphabetically: (a, b) -> a.getUsername().compareTo(b.getUsername())
        // compareTo returns negative/zero/positive to tell sort the order.
        list.sort((a, b) -> a.getUsername().compareTo(b.getUsername()));
        return Collections.unmodifiableList(list); // Wrap in an unmodifiable view.
    }

    // ── findByRole ────────────────────────────────────────────────────────────
    // Returns all users with the given role, sorted alphabetically.
    // Used by AdminMenu when listing dispatchers or drivers.
    public synchronized List<User> findByRole(Role role) {
        List<User> out = new ArrayList<>();
        for (User u : byUsername.values()) {
            if (u.getRole() == role) { // Only include users whose role matches.
                out.add(u);
            }
        }
        out.sort((a, b) -> a.getUsername().compareTo(b.getUsername())); // Sort alphabetically.
        return out;
    }

    // ── save ──────────────────────────────────────────────────────────────────
    // Inserts or updates a user in the in-memory map, then writes all users to the file.
    // If the user already exists (same username), their data is replaced.
    // If they're new, they are added.
    public synchronized void save(User user) {
        byUsername.put(user.getUsername(), user); // Insert or replace in the HashMap.
        persistAll(); // Write the updated map to disk.
    }

    // ── remove ────────────────────────────────────────────────────────────────
    // Removes a user from the in-memory map and updates the file.
    // Returns true if the user was found and removed, false if they didn't exist.
    public synchronized boolean remove(String username) {
        User removed = byUsername.remove(username); // Returns the removed User, or null if not found.
        if (removed == null) {
            return false; // Username wasn't in the map — nothing to remove.
        }
        persistAll(); // Write the updated map to disk (now without this user).
        return true; // Successfully removed.
    }

    // ── persistAll ───────────────────────────────────────────────────────────
    // Writes all users in the in-memory HashMap to disk using the ATOMIC WRITE pattern.
    //
    // ATOMIC WRITE EXPLAINED:
    //   Step 1: Write all data to a TEMPORARY file (users12345.tmp).
    //   Step 2: RENAME the temp file over users.dat in one atomic OS operation.
    //
    // Why? If we wrote directly to users.dat and the computer crashed mid-write,
    // the file would be half-written and corrupted. With atomic rename:
    //   - If crash before rename: old users.dat is untouched, temp file is deleted on cleanup.
    //   - If crash after rename: new complete users.dat is in place.
    //   Either way, users.dat is always a complete, valid file.
    private void persistAll() {
        Path tmp = null; // We'll set this to the temp file path once it's created.
        try {
            // Create a temporary file in the data/ directory.
            // The name will be something like "users3829475634.tmp".
            tmp = Files.createTempFile(Paths.get(Constants.DATA_DIR), "users", ".tmp");

            // Build a list of strings — one record per user.
            List<String> lines = new ArrayList<>();
            for (User u : byUsername.values()) {
                lines.add(u.toRecord()); // Convert each User to a pipe-separated line.
            }

            // Write all lines to the temp file (UTF-8 encoding).
            Files.write(tmp, lines, StandardCharsets.UTF_8);

            // Atomically rename the temp file to users.dat.
            // REPLACE_EXISTING: overwrite users.dat if it already exists.
            // ATOMIC_MOVE: the rename is a single OS operation — either it completes or it doesn't.
            Files.move(tmp, file,
                    StandardCopyOption.REPLACE_EXISTING,
                    StandardCopyOption.ATOMIC_MOVE);

        } catch (IOException ioe) {
            // If anything went wrong, log the error.
            AuditLogger.error("Failed to persist users", ioe);

            // Try to clean up the temp file so it doesn't accumulate on disk.
            if (tmp != null) {
                try {
                    Files.deleteIfExists(tmp); // Delete temp file if it exists.
                } catch (IOException ignore) {
                    // Even cleanup failed — just print a message. Don't crash.
                    System.err.println("[Cleanup] Could not delete temp file: " + ignore.getMessage());
                }
            }
        }
    }
}
