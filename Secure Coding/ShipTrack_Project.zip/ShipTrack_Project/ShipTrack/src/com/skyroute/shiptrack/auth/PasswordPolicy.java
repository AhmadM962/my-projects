// This file belongs to the "auth" package.
package com.skyroute.shiptrack.auth;

// IOException is thrown when reading or writing files fails.
import java.io.IOException;

// StandardCharsets.UTF_8 is the text encoding we use when reading/writing files.
import java.nio.charset.StandardCharsets;

// Files provides methods for reading, writing, and checking existence of files.
import java.nio.file.Files;

// Path represents a file path as an object.
import java.nio.file.Path;

// Paths converts a String path like "data/policy.cfg" into a Path object.
import java.nio.file.Paths;

// Properties is Java's built-in class for reading/writing key=value configuration files.
import java.util.Properties;

// Constants holds file paths and default values.
import com.skyroute.shiptrack.util.Constants;

// "public class PasswordPolicy" — a regular class that can be instantiated.
// This class holds ALL the configurable password strength and lockout rules.
// The admin can change these rules at runtime through the Admin Menu.
// Changes are saved to "data/policy.cfg" and loaded back on next startup.
// Quality principle: no "magic numbers" in the auth code — everything goes through this class.
public class PasswordPolicy {

    // ── FIELDS ───────────────────────────────────────────────────────────────
    // Each field stores one configurable rule. They are set in the constructor
    // and can be changed by the admin through the setter methods below.

    // Minimum total number of characters a password must have.
    private int minLength;

    // Minimum number of uppercase letters (A-Z) required.
    private int minUppercase;

    // Minimum number of lowercase letters (a-z) required.
    private int minLowercase;

    // Minimum number of digits (0-9) required.
    private int minDigits;

    // Minimum number of special characters (like !, @, #) required.
    private int minSpecial;

    // Maximum number of wrong password attempts before the account is locked.
    private int maxLoginAttempts;

    // ── DEFAULT CONSTRUCTOR ───────────────────────────────────────────────────
    // Creates a PasswordPolicy with the safe default values from Constants.
    // Called when no policy.cfg file exists yet (first run).
    public PasswordPolicy() {
        this.minLength        = Constants.DEFAULT_MIN_LENGTH;   // 8 characters minimum
        this.minUppercase     = Constants.DEFAULT_MIN_UPPER;    // at least 1 uppercase
        this.minLowercase     = Constants.DEFAULT_MIN_LOWER;    // at least 1 lowercase
        this.minDigits        = Constants.DEFAULT_MIN_DIGIT;    // at least 1 digit
        this.minSpecial       = Constants.DEFAULT_MIN_SPECIAL;  // at least 1 special char
        this.maxLoginAttempts = Constants.DEFAULT_MAX_ATTEMPTS; // lock after 3 failures
    }

    // ── GETTERS ───────────────────────────────────────────────────────────────
    // Read-only access to each policy rule.

    public int getMinLength()        { return minLength; }         // Returns minimum length
    public int getMinUppercase()     { return minUppercase; }      // Returns minimum uppercase count
    public int getMinLowercase()     { return minLowercase; }      // Returns minimum lowercase count
    public int getMinDigits()        { return minDigits; }         // Returns minimum digit count
    public int getMinSpecial()       { return minSpecial; }        // Returns minimum special char count
    public int getMaxLoginAttempts() { return maxLoginAttempts; }  // Returns the lockout threshold

    // ── SETTERS WITH CLAMP ────────────────────────────────────────────────────
    // Each setter calls clamp() to make sure the value is within a sensible range.
    // This prevents absurd settings like "max attempts = -1" or "min length = 9999".

    // Set minimum password length. Allowed range: 1 to 64 characters.
    public void setMinLength(int v)        { this.minLength        = clamp(v, 1, 64); }

    // Set minimum uppercase count. Allowed range: 0 to 20.
    public void setMinUppercase(int v)     { this.minUppercase     = clamp(v, 0, 20); }

    // Set minimum lowercase count. Allowed range: 0 to 20.
    public void setMinLowercase(int v)     { this.minLowercase     = clamp(v, 0, 20); }

    // Set minimum digit count. Allowed range: 0 to 20.
    public void setMinDigits(int v)        { this.minDigits        = clamp(v, 0, 20); }

    // Set minimum special character count. Allowed range: 0 to 20.
    public void setMinSpecial(int v)       { this.minSpecial       = clamp(v, 0, 20); }

    // Set maximum login attempts before lockout. Allowed range: 1 to 20.
    public void setMaxLoginAttempts(int v) { this.maxLoginAttempts = clamp(v, 1, 20); }

    // ── clamp (private helper) ────────────────────────────────────────────────
    // Keeps a value within the range [lo, hi].
    // clamp(-5, 1, 64) → 1   (too low, snapped up to 1)
    // clamp(42, 1, 64) → 42  (within range, returned as-is)
    // clamp(99, 1, 64) → 64  (too high, snapped down to 64)
    private static int clamp(int v, int lo, int hi) {
        // Math.min(hi, v) → makes sure v is not bigger than hi
        // Math.max(lo, ...) → makes sure the result is not smaller than lo
        return Math.max(lo, Math.min(hi, v));
    }

    // ── describeViolations ────────────────────────────────────────────────────
    // Checks a proposed password against all rules in this policy.
    // Returns null if the password is acceptable.
    // Returns a multi-line string listing all the broken rules if it is NOT acceptable.
    // Called before saving a new password anywhere in the app.
    public String describeViolations(char[] password) {
        // A null password is always rejected.
        if (password == null) {
            return "Password is required.";
        }

        // Count the characters in each category by scanning the password char by char.
        int upper   = 0; // Count of uppercase letters found
        int lower   = 0; // Count of lowercase letters found
        int digit   = 0; // Count of digits found
        int special = 0; // Count of special characters found

        // "for (char c : password)" loops through every character in the array.
        for (char c : password) {
            if (Character.isUpperCase(c)) {
                upper++;   // Found an uppercase letter (A-Z)
            } else if (Character.isLowerCase(c)) {
                lower++;   // Found a lowercase letter (a-z)
            } else if (Character.isDigit(c)) {
                digit++;   // Found a digit (0-9)
            } else if (!Character.isWhitespace(c)) {
                special++; // Found something else that's not whitespace → it's a special char (!, @, etc.)
            }
        }

        // Build a report of every rule that was broken.
        // StringBuilder is more efficient than concatenating strings with "+".
        StringBuilder sb = new StringBuilder();

        // Check total length. password.length is the number of characters in the array.
        if (password.length < minLength) {
            sb.append("- Need at least ").append(minLength).append(" characters total.\n");
        }
        // Check uppercase count.
        if (upper < minUppercase) {
            sb.append("- Need at least ").append(minUppercase).append(" uppercase letter(s).\n");
        }
        // Check lowercase count.
        if (lower < minLowercase) {
            sb.append("- Need at least ").append(minLowercase).append(" lowercase letter(s).\n");
        }
        // Check digit count.
        if (digit < minDigits) {
            sb.append("- Need at least ").append(minDigits).append(" digit(s).\n");
        }
        // Check special character count.
        if (special < minSpecial) {
            sb.append("- Need at least ").append(minSpecial).append(" special character(s).\n");
        }

        // If the StringBuilder is empty, no rules were broken → return null (password OK).
        // Otherwise, return the violations message with trailing whitespace trimmed.
        return sb.length() == 0 ? null : sb.toString().trim();
    }

    // ── isAcceptable ─────────────────────────────────────────────────────────
    // Convenience method: returns true if the password passes all rules, false if not.
    // Used in tests for cleaner assertions.
    public boolean isAcceptable(char[] password) {
        return describeViolations(password) == null; // null violations means it's acceptable
    }

    // ── loadOrDefault (static factory) ────────────────────────────────────────
    // Reads the policy from "data/policy.cfg".
    // If the file doesn't exist or can't be read, returns a policy with default values.
    // Called once at startup in App.java.
    public static PasswordPolicy loadOrDefault() {
        PasswordPolicy p = new PasswordPolicy(); // Start with safe defaults.
        Path file = Paths.get(Constants.POLICY_FILE); // Path to "data/policy.cfg"

        // If the config file doesn't exist, just return the defaults.
        if (!Files.exists(file)) {
            return p;
        }

        try {
            // Properties is Java's key=value file reader (for files like "key=value").
            Properties props = new Properties();

            // try-with-resources: opens a buffered file reader and AUTOMATICALLY closes it when done,
            // even if an exception occurs. "var" lets Java figure out the type automatically.
            try (var in = Files.newBufferedReader(file, StandardCharsets.UTF_8)) {
                props.load(in); // Read all key=value pairs from the file into props.
            }

            // Read each policy value from the file, using the default from Constants as a fallback
            // if a key is missing or its value is not a valid integer.
            p.minLength        = parse(props, "minLength",        Constants.DEFAULT_MIN_LENGTH);
            p.minUppercase     = parse(props, "minUppercase",     Constants.DEFAULT_MIN_UPPER);
            p.minLowercase     = parse(props, "minLowercase",     Constants.DEFAULT_MIN_LOWER);
            p.minDigits        = parse(props, "minDigits",        Constants.DEFAULT_MIN_DIGIT);
            p.minSpecial       = parse(props, "minSpecial",       Constants.DEFAULT_MIN_SPECIAL);
            p.maxLoginAttempts = parse(props, "maxLoginAttempts", Constants.DEFAULT_MAX_ATTEMPTS);

        } catch (IOException ioe) {
            // If the file can't be read (permissions, disk error, etc.), just print a warning
            // and continue with default values. The app does not crash.
            System.err.println("[PasswordPolicy] failed to load: " + ioe.getMessage());
        }
        return p; // Return the policy (either loaded or defaults).
    }

    // ── parse (private helper) ────────────────────────────────────────────────
    // Reads a single integer value from a Properties object.
    // If the key is missing, uses the fallback. If the value is not a valid integer, uses the fallback.
    // This makes loading robust against a manually edited or corrupted policy.cfg file.
    private static int parse(Properties p, String key, int fallback) {
        try {
            // p.getProperty(key, defaultValue) → reads the value for "key",
            // or returns String.valueOf(fallback) if the key is not in the file.
            // Integer.parseInt(...) converts the text to an integer.
            return Integer.parseInt(p.getProperty(key, String.valueOf(fallback)));
        } catch (NumberFormatException nfe) {
            // The value was not a valid number (e.g. someone typed "abc" in the file).
            return fallback; // Use the safe default instead.
        }
    }

    // ── save ─────────────────────────────────────────────────────────────────
    // Writes the current policy values to "data/policy.cfg".
    // Called by the Admin Menu when the admin changes the password policy.
    public void save() {
        // Build a Properties object with the current values.
        Properties props = new Properties();
        props.setProperty("minLength",        String.valueOf(minLength));        // e.g. "8"
        props.setProperty("minUppercase",     String.valueOf(minUppercase));     // e.g. "1"
        props.setProperty("minLowercase",     String.valueOf(minLowercase));     // e.g. "1"
        props.setProperty("minDigits",        String.valueOf(minDigits));        // e.g. "1"
        props.setProperty("minSpecial",       String.valueOf(minSpecial));       // e.g. "1"
        props.setProperty("maxLoginAttempts", String.valueOf(maxLoginAttempts)); // e.g. "3"

        try {
            // Make sure the data/ directory exists. Create it if not.
            Path dir = Paths.get(Constants.DATA_DIR);
            if (!Files.exists(dir)) {
                Files.createDirectories(dir); // Creates data/ (and any parent folders needed).
            }

            // Open the policy file for writing. try-with-resources closes it automatically.
            try (var out = Files.newBufferedWriter(Paths.get(Constants.POLICY_FILE),
                    StandardCharsets.UTF_8)) {
                // props.store() writes all key=value pairs to the file.
                // The second argument is a comment added at the top of the file.
                props.store(out, "ShipTrack password policy");
            }
        } catch (IOException ioe) {
            // If saving fails, print a warning but don't crash the app.
            System.err.println("[PasswordPolicy] failed to save: " + ioe.getMessage());
        }
    }

    // ── toString ─────────────────────────────────────────────────────────────
    // @Override replaces the default Object.toString() with a readable summary.
    // Used when the admin views the current policy or when logging policy changes.
    // Example: "PasswordPolicy(len>=8, upper>=1, lower>=1, digit>=1, special>=1, attempts<=3)"
    @Override
    public String toString() {
        // String.format with %d placeholders inserts the integer values.
        return String.format(
                "PasswordPolicy(len>=%d, upper>=%d, lower>=%d, digit>=%d, special>=%d, attempts<=%d)",
                minLength, minUppercase, minLowercase, minDigits, minSpecial, maxLoginAttempts);
    }
}
