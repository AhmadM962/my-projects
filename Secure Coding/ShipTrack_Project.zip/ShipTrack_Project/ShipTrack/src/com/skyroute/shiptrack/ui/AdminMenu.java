// This file belongs to the "ui" package — the user interface screens.
package com.skyroute.shiptrack.ui;

// AuthService is needed for the changePassword() method.
import com.skyroute.shiptrack.auth.AuthService;

// PasswordHasher is used here to detect if the admin still uses the default password.
import com.skyroute.shiptrack.auth.PasswordHasher;

// PasswordPolicy holds the configurable password rules the admin can change.
import com.skyroute.shiptrack.auth.PasswordPolicy;

// Role is needed to set the role when registering new staff.
import com.skyroute.shiptrack.model.Role;

// User is the data class for user accounts.
import com.skyroute.shiptrack.model.User;

// UserRepository reads and writes users.dat.
import com.skyroute.shiptrack.repository.UserRepository;

// AuditLogger records all admin actions to audit.log.
import com.skyroute.shiptrack.util.AuditLogger;

// ConsoleUI provides the prompt/print/error methods for terminal interaction.
import com.skyroute.shiptrack.util.ConsoleUI;

// Constants holds the default admin password (used to detect first login).
import com.skyroute.shiptrack.util.Constants;

// InputValidator checks that new usernames, names, IDs, and phones are correctly formatted.
import com.skyroute.shiptrack.util.InputValidator;

// "public class AdminMenu" — the screen that admins see after logging in.
// Security principle (Least Privilege): only admins ever reach this class.
// A Customer or Dispatcher is never routed here by App.java.
// All operations in this class require admin-level access by design.
public class AdminMenu {

    // ── FIELDS ───────────────────────────────────────────────────────────────
    // All dependencies are passed in through the constructor (constructor injection).
    // This makes the class easy to test — you can pass fake objects in unit tests.

    private final ConsoleUI io;           // For printing and reading input
    private final User currentAdmin;      // The currently logged-in admin
    private final UserRepository users;   // For looking up, saving, and removing users
    private final PasswordPolicy policy;  // For enforcing and updating password rules
    private final AuthService auth;       // For changing the admin's own password

    // ── CONSTRUCTOR ──────────────────────────────────────────────────────────
    // Receives all needed objects and stores them in the fields above.
    public AdminMenu(ConsoleUI io, User admin, UserRepository users,
                     PasswordPolicy policy, AuthService auth) {
        this.io           = io;      // Store the console UI helper
        this.currentAdmin = admin;   // Store the logged-in admin
        this.users        = users;   // Store the user repository
        this.policy       = policy;  // Store the password policy
        this.auth         = auth;    // Store the auth service
    }

    // ── run ───────────────────────────────────────────────────────────────────
    // The main loop for the Admin Menu. Shows options and processes choices.
    public void run() {

        // ── FIRST-LOGIN PASSWORD CHANGE ──────────────────────────────────────
        // Check if the admin still has the default password "Admin@123".
        // PasswordHasher.verify() returns true if the default password matches the stored hash.
        // If it does match, the admin must change it BEFORE they can do anything else.
        // This is Defense in Depth: even though the default password is hashed (not plain text),
        // it's still a known default and must be changed immediately.
        if (PasswordHasher.verify(Constants.DEFAULT_ADMIN_PASSWORD.toCharArray(),
                currentAdmin.getSalt(), currentAdmin.getHash())) {
            io.println("\nThis is the first login on the default admin account.");
            io.println("You must change the password before continuing.");
            forcePasswordChange(); // Call the password-change method below.
        }

        // ── ADMIN MENU LOOP ───────────────────────────────────────────────────
        // "while (true)" keeps showing the menu until the admin chooses "Logout" (case 0: return).
        while (true) {
            io.println(""); // Blank line for readability.
            // Print the menu header with the admin's username.
            io.println("=== Admin Menu (" + currentAdmin.getUsername() + ") ===");
            io.println("1) Register new dispatcher");           // Create a DISPATCHER account
            io.println("2) Register new delivery personnel");   // Create a DELIVERY_PERSONNEL account
            io.println("3) Remove dispatcher / delivery personnel"); // Delete a staff account
            io.println("4) Define password policy");            // Change strength rules
            io.println("5) Define max login attempts");         // Change lockout threshold
            io.println("6) Lock account");                     // Manually lock a user
            io.println("7) Unlock account");                   // Manually unlock a user
            io.println("8) List all users");                   // Display all accounts
            io.println("9) Change my password");               // Change admin's own password
            io.println("0) Logout");                           // Exit the admin menu

            // Read the admin's numeric choice.
            int choice = io.promptInt("> ");

            // Route to the appropriate method based on choice.
            switch (choice) {
                case 1: registerStaff(Role.DISPATCHER);         break; // Register a dispatcher
                case 2: registerStaff(Role.DELIVERY_PERSONNEL); break; // Register a driver
                case 3: removeStaff();                          break; // Remove a staff member
                case 4: configurePasswordPolicy();              break; // Update password rules
                case 5: configureMaxAttempts();                 break; // Update lockout threshold
                case 6: lockAccount(true);                      break; // Lock an account (lock=true)
                case 7: lockAccount(false);                     break; // Unlock an account (lock=false)
                case 8: listUsers();                            break; // List all users
                case 9: forcePasswordChange();                  break; // Change own password
                case 0: io.println("Logging out..."); return;          // Exit the loop and log out
                default: io.error("Unknown option.");                   // Invalid input
            }
        }
    }

    // ── registerStaff ────────────────────────────────────────────────────────
    // Creates a new DISPATCHER or DELIVERY_PERSONNEL account.
    // The "role" parameter determines which type of staff account to create.
    private void registerStaff(Role role) {
        io.println("\n-- Register new " + role.label() + " --"); // Print header with role name.

        // ── Collect and validate username ───────────────────────────────────
        String username = io.prompt("Username (3-20 chars, letters/digits/._-): ");
        // Check username format: only letters, digits, ._-, 3-20 chars.
        if (!InputValidator.isValidUsername(username)) { io.error("Invalid username."); return; }
        // Check that no other account already uses this username.
        if (users.exists(username)) { io.error("Username already taken."); return; }

        // ── Collect and validate full name ──────────────────────────────────
        String fullName = io.prompt("Full name: ");
        // Full name: letters and spaces, 2-50 characters.
        if (!InputValidator.isValidName(fullName)) { io.error("Invalid name."); return; }

        // ── Collect and validate ID number ──────────────────────────────────
        String idNumber = io.prompt("ID number: ");
        // ID: 4-15 digits only.
        if (!InputValidator.isValidId(idNumber)) { io.error("Invalid ID."); return; }

        // ── Collect and validate contact number ─────────────────────────────
        String contact = io.prompt("Contact number: ");
        // Phone: optional "+", then 7-15 digits.
        if (!InputValidator.isValidPhone(contact)) { io.error("Invalid phone."); return; }

        // ── Collect and validate initial password ───────────────────────────
        char[] pwd = io.promptPassword("Initial password: ");
        // Check the password against the current policy rules.
        // describeViolations() returns null if acceptable, or a message listing violations.
        String violations = policy.describeViolations(pwd);
        if (violations != null) { io.println(violations); return; } // Reject weak password.

        try {
            // Hash the password: generate a random salt and run PBKDF2.
            // sh[0] = Base64 salt, sh[1] = Base64 hash.
            String[] sh = PasswordHasher.hashWithNewSalt(pwd);

            // Create the new User object with the given role (DISPATCHER or DELIVERY_PERSONNEL).
            User u = new User(username, role, sh[0], sh[1], false, 0, fullName, idNumber, contact);

            // Save the new user to the file.
            users.save(u);

            // Log the registration action. "REGISTER_" + role.name() gives "REGISTER_DISPATCHER" etc.
            AuditLogger.log(currentAdmin.getUsername(), "REGISTER_" + role.name(), username);

            io.println("Registered " + role.label() + " '" + username + "'."); // Confirm to admin.

        } catch (Exception e) {
            // If hashing or saving failed, show an error and log it.
            io.error("Failed to register: " + e.getMessage());
            AuditLogger.error("Register failed", e);
        }
    }

    // ── removeStaff ──────────────────────────────────────────────────────────
    // Deletes a DISPATCHER or DELIVERY_PERSONNEL account. Cannot delete admins or customers.
    private void removeStaff() {
        String username = io.prompt("Username to remove: ");
        // Validate the username format first.
        if (!InputValidator.isValidUsername(username)) { io.error("Invalid username."); return; }

        // Look up the user in the database.
        User u = users.findByUsername(username);
        if (u == null) { io.error("No such user."); return; } // User not found.

        // Security restriction: admins cannot remove other admins or customers.
        // Only dispatchers and delivery personnel can be removed through this option.
        if (u.getRole() == Role.ADMIN || u.getRole() == Role.CUSTOMER) {
            io.error("Brief allows removing only Dispatchers and Delivery Personnel.");
            return;
        }

        // Remove the user from the database and file.
        users.remove(username);

        // Log the removal action.
        AuditLogger.log(currentAdmin.getUsername(), "REMOVE_USER", username);

        io.println("Removed " + username + "."); // Confirm to admin.
    }

    // ── configurePasswordPolicy ───────────────────────────────────────────────
    // Lets the admin update all 5 password strength rules.
    private void configurePasswordPolicy() {
        // Print current policy values so the admin knows what they're changing.
        io.println("\n-- Password policy (current: " + policy + ") --");

        // Ask for each rule and update the policy object.
        // The setter methods (setMinLength, etc.) use clamp() internally
        // to keep values within safe ranges.
        policy.setMinLength(io.promptInt("Min length: "));
        policy.setMinUppercase(io.promptInt("Min uppercase: "));
        policy.setMinLowercase(io.promptInt("Min lowercase: "));
        policy.setMinDigits(io.promptInt("Min digits: "));
        policy.setMinSpecial(io.promptInt("Min special: "));

        // Save the updated policy to data/policy.cfg so it persists after restart.
        policy.save();

        // Log the policy change with the new values.
        AuditLogger.log(currentAdmin.getUsername(), "POLICY_UPDATE", policy.toString());

        io.println("Updated: " + policy); // Show the admin what the new policy is.
    }

    // ── configureMaxAttempts ──────────────────────────────────────────────────
    // Lets the admin change how many wrong password attempts are allowed before lockout.
    private void configureMaxAttempts() {
        // Ask the admin how many attempts to allow.
        int n = io.promptInt("Max login attempts: ");

        // Update the policy. The setter clamps the value between 1 and 20.
        policy.setMaxLoginAttempts(n);

        // Save to data/policy.cfg.
        policy.save();

        // Log the change with the actual clamped value (not what the admin typed, in case it was clamped).
        AuditLogger.log(currentAdmin.getUsername(), "MAX_ATTEMPTS_UPDATE",
                String.valueOf(policy.getMaxLoginAttempts()));

        io.println("Max login attempts is now " + policy.getMaxLoginAttempts() + ".");
    }

    // ── lockAccount ───────────────────────────────────────────────────────────
    // Locks or unlocks a user account. Called with lock=true to lock, lock=false to unlock.
    private void lockAccount(boolean lock) {
        String username = io.prompt("Username: "); // Ask which account to lock/unlock.

        User u = users.findByUsername(username);
        if (u == null) { io.error("No such user."); return; } // User not found.

        // Set the locked field on the User object.
        u.setLocked(lock);

        // If UNLOCKING: also reset the failed-attempt counter.
        // Otherwise, the user would be locked again on their very next wrong password.
        if (!lock) {
            u.resetFailedAttempts(); // Reset counter to 0.
        }

        // Save the updated user to the file.
        users.save(u);

        // Log the lock or unlock action.
        // "lock ? "LOCK_ACCOUNT" : "UNLOCK_ACCOUNT"" is a ternary: if lock=true use "LOCK_ACCOUNT", else "UNLOCK_ACCOUNT".
        AuditLogger.log(currentAdmin.getUsername(),
                lock ? "LOCK_ACCOUNT" : "UNLOCK_ACCOUNT", username);

        // Print confirmation. Same ternary for "Locked" vs "Unlocked".
        io.println((lock ? "Locked " : "Unlocked ") + username + ".");
    }

    // ── listUsers ─────────────────────────────────────────────────────────────
    // Prints all user accounts to the screen. Called when admin chooses option 8.
    private void listUsers() {
        io.println("\n-- All users --"); // Print the section header.
        // findAll() returns users sorted alphabetically by username.
        // u.toString() prints: "alice [CUSTOMER] Alice Smith lock=false attempts=0"
        // (salt and hash are intentionally NOT included in toString — security principle).
        for (User u : users.findAll()) {
            io.println("  " + u); // Print each user with 2 spaces of indent.
        }
    }

    // ── forcePasswordChange ───────────────────────────────────────────────────
    // Prompts the admin to enter and save a new password.
    // Called automatically on first login AND available as menu option 9.
    private void forcePasswordChange() {
        // Read the new password as a char[] (hidden input if in a real terminal).
        char[] pwd = io.promptPassword("New password: ");

        // Check the new password against the current policy rules.
        String violations = policy.describeViolations(pwd);
        if (violations != null) {
            // Password doesn't meet the rules — show what's wrong and return without saving.
            io.println(violations);
            return;
        }

        // Call AuthService.changePassword() which:
        //   1. Re-validates the password against policy (defense in depth)
        //   2. Generates a new salt
        //   3. Hashes the password with PBKDF2
        //   4. Updates the User object's salt and hash
        //   5. Saves the updated user to the file
        //   6. Logs the change to audit.log
        if (!auth.changePassword(currentAdmin, pwd)) {
            io.error("Failed to change password."); // Something went wrong internally.
            return;
        }

        io.println("Password updated."); // Confirm success.
    }
}
