// This file belongs to the "util" package.
package com.skyroute.shiptrack.util;

// Import for handling file read/write errors.
import java.io.IOException;

// Import for writing text in UTF-8 encoding (supports international characters).
import java.nio.charset.StandardCharsets;

// Import for file operations (reading, writing, checking existence).
import java.nio.file.Files;

// Import for representing a file path.
import java.nio.file.Path;

// Import for converting a string path to a Path object.
import java.nio.file.Paths;

// Import for controlling how files are opened — CREATE creates the file if missing, APPEND adds to the end.
import java.nio.file.StandardOpenOption;

// Import for working with the current date and time.
import java.time.LocalDateTime;

// Import for formatting dates into readable text.
import java.time.format.DateTimeFormatter;

// "public final class" — public: visible everywhere; final: cannot be extended.
// This is a utility class: only static methods, never instantiated.
// Security principle (Non-Repudiation): every important security event is recorded permanently
// so that if something goes wrong, we can answer "who did what and when?".
public final class AuditLogger {

    // The date/time format for log entries: year-month-day hour:minute:second
    // Example output: "2025-05-27 14:30:00"
    // "static final" = one shared formatter for the whole class.
    private static final DateTimeFormatter TS =
            DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    // Private constructor — nobody should create an AuditLogger object.
    private AuditLogger() { /* utility class — not instantiable */ }

    // ── log ──────────────────────────────────────────────────────────────────
    // Records a successful or normal event at the INFO level.
    // Example: log("alice", "LOGIN", "OK")  →  records that alice logged in successfully.
    // actor  = who did the action (username)
    // action = what they did (LOGIN, CREATE_SHIPMENT, etc.)
    // result = what happened (OK, SUCCESS, etc.)
    public static void log(String actor, String action, String result) {
        write("INFO", actor, action, result, null); // Delegate to the internal write() method.
    }

    // ── warn ─────────────────────────────────────────────────────────────────
    // Records a security-relevant warning at the WARN level.
    // Example: warn("bob", "LOGIN", "BAD_PASSWORD attempt=2")
    // Used for failed logins, lockouts, and suspicious activity.
    public static void warn(String actor, String action, String result) {
        write("WARN", actor, action, result, null); // Delegate to the internal write() method.
    }

    // ── error ─────────────────────────────────────────────────────────────────
    // Records an internal system error at the ERROR level.
    // "Throwable t" is the Java error/exception that occurred. Can be null.
    // Example: error("PBKDF2 failed", someException)
    public static void error(String message, Throwable t) {
        // If t (the exception) is null, use null for the detail.
        // Otherwise, build a string: "IOException: file not found" (class name + message).
        // t.getClass().getSimpleName() gives just "IOException", not the full package name.
        write("ERROR", "system", "INTERNAL_ERROR", message,
              t == null ? null : t.getClass().getSimpleName() + ": " + t.getMessage());
    }

    // ── write (private — internal use only) ──────────────────────────────────
    // This is the actual method that builds the log line and writes it to the file.
    // All three public methods (log, warn, error) ultimately call this one.
    private static void write(String level, String actor, String action,
                              String result, String detail) {

        // Build one line of text by joining all fields with the pipe "|" separator.
        // Example: "2025-05-27 14:30:00|INFO|alice|LOGIN|OK|"
        String line = String.join(Constants.FIELD_SEPARATOR,
                LocalDateTime.now().format(TS),        // Current timestamp formatted as text
                level,                                 // "INFO", "WARN", or "ERROR"
                clean(actor),                          // Who did the action (sanitized)
                clean(action),                         // What they did (sanitized)
                clean(result),                         // The outcome (sanitized)
                detail == null ? "" : clean(detail))   // Extra detail, or "" if none
                + System.lineSeparator();              // Add a newline at the end of the line.
        // System.lineSeparator() gives "\r\n" on Windows, "\n" on Linux — the correct newline for this OS.

        try {
            // Get the path to the data/ directory.
            Path dir = Paths.get(Constants.DATA_DIR);

            // If the data/ directory doesn't exist yet, create it (and any parent folders needed).
            if (!Files.exists(dir)) {
                Files.createDirectories(dir);
            }

            // Get the path to the audit log file: data/audit.log
            Path log = Paths.get(Constants.AUDIT_LOG);

            // Write the line to the file.
            // line.getBytes(StandardCharsets.UTF_8) converts the text to raw bytes in UTF-8 encoding.
            // StandardOpenOption.CREATE  → create the file if it doesn't exist.
            // StandardOpenOption.APPEND  → add to the end, never overwrite existing lines.
            Files.write(log, line.getBytes(StandardCharsets.UTF_8),
                    StandardOpenOption.CREATE, StandardOpenOption.APPEND);

        } catch (IOException ioe) {
            // If writing to the log file fails (disk full, permissions, etc.):
            // Print a warning to stderr (the error output stream) — but DO NOT crash the app.
            // Logging failure must never stop the main program from running.
            System.err.println("[AuditLogger] failed to write log: " + ioe.getMessage());
        }
    }

    // ── clean (private helper) ────────────────────────────────────────────────
    // Sanitizes a string before it goes into the log file.
    // This prevents an attacker from injecting pipe characters or newlines that would
    // break the log format or insert fake entries.
    private static String clean(String s) {
        // If the input is null, return an empty string (avoids NullPointerException).
        if (s == null) {
            return "";
        }
        // Replace any pipe "|" with a slash "/" so it doesn't look like a field separator.
        // Replace any newline '\n' or carriage return '\r' with a space so the entry stays on one line.
        return s.replace(Constants.FIELD_SEPARATOR, "/")
                .replace('\n', ' ')
                .replace('\r', ' ');
    }
}
