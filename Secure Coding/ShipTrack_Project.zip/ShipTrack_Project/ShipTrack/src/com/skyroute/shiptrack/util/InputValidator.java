// This file belongs to the "util" package — shared helper classes.
package com.skyroute.shiptrack.util;

// Import for working with regular expressions (patterns for matching text).
import java.util.regex.Pattern;

// "public final class" — public: visible everywhere; final: cannot be extended/subclassed.
// This is a utility class: it only has static methods and cannot be instantiated.
// Security principle: centralizing all input validation here means you never forget to apply it —
// if a new screen is added, it just calls these methods and gets the same checks for free.
public final class InputValidator {

    // Private constructor prevents anyone from writing "new InputValidator()".
    // This is the standard way to say "this class is just a collection of static methods."
    private InputValidator() { /* utility — not instantiable */ }

    // ── REGEX PATTERNS ────────────────────────────────────────────────────────
    // Pattern.compile() pre-compiles the regex once and reuses it on every check.
    // This is more efficient than compiling the regex fresh on every method call.

    // Username pattern: only letters (A-Z, a-z), digits (0-9), dot, underscore, or dash.
    // Must be between 3 and 20 characters long.
    // ^ = start of string, $ = end of string, {3,20} = between 3 and 20 of those chars.
    // The pipe "|" is NOT in this list, so it can never sneak into a username and corrupt the data file.
    private static final Pattern USERNAME_PATTERN =
            Pattern.compile("^[A-Za-z0-9._-]{3,20}$");

    // Phone pattern: an optional "+" at the start, then 7 to 15 digits.
    // \\+? means an optional literal "+" (the \\ is needed because + is special in regex).
    // \\d means a digit (0-9). {7,15} means between 7 and 15 digits.
    private static final Pattern PHONE_PATTERN =
            Pattern.compile("^\\+?\\d{7,15}$");

    // ID number pattern: only digits, between 4 and 15 characters long.
    // \\d means a digit. {4,15} means between 4 and 15 of them.
    private static final Pattern ID_PATTERN =
            Pattern.compile("^\\d{4,15}$");

    // Full name pattern: must start with a letter, then 1 to 49 letters or spaces.
    // Total length: 2 to 50 characters. Digits and special characters are NOT allowed.
    private static final Pattern NAME_PATTERN =
            Pattern.compile("^[A-Za-z][A-Za-z ]{1,49}$");

    // ── isValidUsername ───────────────────────────────────────────────────────
    // Returns true if the string is a valid username, false otherwise.
    // "s != null" prevents a NullPointerException — null is always invalid.
    // "USERNAME_PATTERN.matcher(s).matches()" checks if the ENTIRE string matches the pattern.
    public static boolean isValidUsername(String s) {
        return s != null && USERNAME_PATTERN.matcher(s).matches();
    }

    // ── isValidPhone ──────────────────────────────────────────────────────────
    // Returns true if the string is a valid phone number, false otherwise.
    public static boolean isValidPhone(String s) {
        return s != null && PHONE_PATTERN.matcher(s).matches();
    }

    // ── isValidId ─────────────────────────────────────────────────────────────
    // Returns true if the string is a valid national ID number, false otherwise.
    public static boolean isValidId(String s) {
        return s != null && ID_PATTERN.matcher(s).matches();
    }

    // ── isValidName ───────────────────────────────────────────────────────────
    // Returns true if the string is a valid full name, false otherwise.
    public static boolean isValidName(String s) {
        return s != null && NAME_PATTERN.matcher(s).matches();
    }

    // ── isStorageSafe ─────────────────────────────────────────────────────────
    // A final safety check before saving ANY free-text value to a file.
    // Returns false if the string contains characters that would break the file format.
    // Specifically rejects:
    //   '|'  — our field separator (would split the record incorrectly)
    //   '\n' — newline (would create a fake second line in the file)
    //   '\r' — carriage return (same problem as newline)
    //   anything with ASCII code < 32 — these are invisible control characters
    public static boolean isStorageSafe(String s) {
        // Null is never storage-safe.
        if (s == null) {
            return false;
        }
        // Check every character in the string one by one.
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i); // Get the character at position i.
            // If this character is a pipe, newline, carriage return, or a control character — reject.
            if (c == '|' || c == '\n' || c == '\r' || c < 0x20) {
                return false; // Found a bad character — the string is NOT safe.
            }
        }
        // No bad characters found — the string is safe to store.
        return true;
    }

    // ── allStorageSafe ────────────────────────────────────────────────────────
    // Convenience method: returns true ONLY IF every value in the list is storage-safe.
    // The "String... values" parameter means you can pass any number of strings:
    //   allStorageSafe("alice", "Smith", "12345") — three strings as arguments.
    public static boolean allStorageSafe(String... values) {
        // Loop through each value in the list.
        for (String v : values) {
            // If even one value is NOT storage-safe, return false immediately.
            if (!isStorageSafe(v)) {
                return false;
            }
        }
        // All values passed — return true.
        return true;
    }
}
