// This is the TOP-LEVEL package — the root of the application.
package com.skyroute.shiptrack;

// Scanner reads text the user types in the terminal (keyboard input).
import java.util.Scanner;

// AuthService handles login attempts and password changes.
import com.skyroute.shiptrack.auth.AuthService;

// PasswordHasher is used here to detect if the admin still has the default password.
import com.skyroute.shiptrack.auth.PasswordHasher;

// PasswordPolicy holds the configurable password strength and lockout rules.
import com.skyroute.shiptrack.auth.PasswordPolicy;

// Role is the enum of user types: ADMIN, DISPATCHER, CUSTOMER, DELIVERY_PERSONNEL.
import com.skyroute.shiptrack.model.Role;

// User holds all data about a logged-in user account.
import com.skyroute.shiptrack.model.User;

// ShipmentRepository reads and writes shipments.dat.
import com.skyroute.shiptrack.repository.ShipmentRepository;

// UserRepository reads and writes users.dat.
import com.skyroute.shiptrack.repository.UserRepository;

// AdminMenu is the screen shown to admins after login.
import com.skyroute.shiptrack.ui.AdminMenu;

// CustomerMenu is the screen shown to customers after login.
import com.skyroute.shiptrack.ui.CustomerMenu;

// DispatcherMenu is the screen shown to dispatchers after login.
import com.skyroute.shiptrack.ui.DispatcherMenu;

// DriverMenu is the screen shown to drivers after login.
import com.skyroute.shiptrack.ui.DriverMenu;

// AuditLogger records security events to audit.log.
import com.skyroute.shiptrack.util.AuditLogger;

// ConsoleUI wraps Scanner to provide clean print/prompt methods.
import com.skyroute.shiptrack.util.ConsoleUI;

// InputValidator checks that user input is safe and correctly formatted.
import com.skyroute.shiptrack.util.InputValidator;

// "public class App" is the ENTRY POINT of the entire application.
// Java always looks for "public static void main(String[] args)" to start execution.
// This class intentionally does as little as possible:
//   1. Create all the service objects (wiring/dependency injection)
//   2. Show the top-level menu (Login / Register / Exit)
//   3. After a successful login, hand control to the correct role-based menu
public class App {

    // ── main ──────────────────────────────────────────────────────────────────
    // This is the very first method Java runs when you launch the program.
    // "public static void main(String[] args)" is the required signature for a Java entry point.
    //   public  = visible to the JVM
    //   static  = no App object needs to be created to call this
    //   void    = returns nothing
    //   String[] args = command-line arguments (not used here)
    public static void main(String[] args) {
        // Wrap the entire program in a try/catch for unexpected fatal errors.
        // "Throwable" catches everything — even JVM errors like OutOfMemoryError.
        // This prevents an ugly stack trace from appearing to the user on a crash.
        try {
            // Create an App instance and immediately call runMainLoop().
            // "new App()" creates the object; ".runMainLoop()" calls the method.
            new App().runMainLoop();
        } catch (Throwable t) {
            // If something totally unexpected crashes the app, log it to audit.log...
            AuditLogger.error("Fatal error in main", t);
            // ...and print a friendly message to the error stream (stderr).
            System.err.println("A fatal error occurred. See data/audit.log for details.");
        }
    }

    // ── runMainLoop ───────────────────────────────────────────────────────────
    // Sets up all the service objects and runs the top-level menu loop.
    // This is where all the major components of the app are wired together.
    private void runMainLoop() {

        // ── DEPENDENCY WIRING (Constructor Injection) ────────────────────────
        // Create each service and pass it the objects it depends on.
        // This is the "Constructor Injection" design pattern.
        // Benefits: each class is testable in isolation, dependencies are explicit.

        // Load all users from data/users.dat into memory.
        UserRepository users = new UserRepository();

        // Load all shipments from data/shipments.dat into memory.
        ShipmentRepository shipments = new ShipmentRepository();

        // Load the password policy from data/policy.cfg, or use defaults if the file is missing.
        PasswordPolicy policy = PasswordPolicy.loadOrDefault();

        // Create the authentication service. It needs users (to look up accounts)
        // and policy (to enforce lockout thresholds).
        AuthService auth = new AuthService(users, policy);

        // Create the console UI helper. Scanner(System.in) reads from the keyboard.
        ConsoleUI io = new ConsoleUI(new Scanner(System.in));

        // ── WELCOME BANNER ───────────────────────────────────────────────────
        // Print the application header to the screen.
        io.println("==========================================");
        io.println("  ShipTrack — SkyRoute Solutions");
        io.println("  Secure Coding 00203420 demo build");
        io.println("==========================================");

        // Print the default admin credentials (shown only on first run for convenience).
        // Constants.DEFAULT_ADMIN_USERNAME = "admin", Constants.DEFAULT_ADMIN_PASSWORD = "Admin@123"
        io.println("Default admin (first run only): "
                + com.skyroute.shiptrack.util.Constants.DEFAULT_ADMIN_USERNAME
                + " / " + com.skyroute.shiptrack.util.Constants.DEFAULT_ADMIN_PASSWORD);
        io.println("(Admin must change the password on first login.)");

        // ── MAIN MENU LOOP ───────────────────────────────────────────────────
        // "while (true)" runs forever until the user chooses "Exit" (case 0: return).
        while (true) {
            io.println("");               // Print a blank line for readability.
            io.println("--- Welcome ---"); // Print the menu header.
            io.println("1) Login");        // Option 1: log into an existing account.
            io.println("2) Register as a new Customer"); // Option 2: create a new customer account.
            io.println("0) Exit");         // Option 0: close the application.

            // Prompt the user to type a number. io.promptInt() keeps asking until a valid integer is entered.
            int choice = io.promptInt("> ");

            // Jump to the matching case based on what the user typed.
            switch (choice) {
                case 1: doLogin(io, users, shipments, policy, auth); break; // Go to login flow
                case 2: doRegisterCustomer(io, users, policy);       break; // Go to registration flow
                case 0:
                    io.println("Goodbye."); // Print farewell message.
                    return;                 // "return" exits runMainLoop(), which ends the program.
                default:
                    io.error("Unknown option."); // User typed something not on the menu.
            }
        }
    }

    // ── doLogin ───────────────────────────────────────────────────────────────
    // Handles the login flow: asks for credentials, calls AuthService, then routes to the right menu.
    // Receives all needed services as parameters (passed from runMainLoop).
    private void doLogin(ConsoleUI io, UserRepository users,
                         ShipmentRepository shipments, PasswordPolicy policy,
                         AuthService auth) {

        // Ask the user to type their username. io.prompt() prints the label and reads a line.
        String username = io.prompt("Username: ");

        // Ask the user to type their password. io.promptPassword() hides input if possible,
        // and returns a char[] (array of characters) instead of a String for security.
        char[] password = io.promptPassword("Password: ");

        // Call the authentication service with the credentials. This runs all 4 security layers.
        // Returns an AuthResult with: outcome (OK/FAILED/etc.), user (or null), message.
        AuthService.AuthResult result = auth.login(username, password);

        // Wipe the password from memory IMMEDIATELY after use.
        // Arrays.fill replaces every character in the array with the null character '\0'.
        // This prevents the password from lingering in RAM where it could be found.
        if (password != null) {
            java.util.Arrays.fill(password, '\0');
        }

        // Print the result message to the user (e.g. "Welcome, Alice Smith." or "Invalid credentials.").
        io.println(result.message);

        // If the login was not successful (wrong password, locked account, bad input),
        // stop here and return to the main menu.
        if (result.outcome != AuthService.AuthOutcome.OK) {
            return;
        }

        // ── ROLE-BASED DISPATCH (Least Privilege) ──────────────────────────
        // After a successful login, create and run ONLY the menu that matches this user's role.
        // A customer can NEVER reach AdminMenu because the AdminMenu object is never created for them.
        // This is the core of the "Least Privilege" security principle.
        User u = result.user; // Get the logged-in User object from the result.

        switch (u.getRole()) {
            case ADMIN:
                // Create an AdminMenu and run it. Admins can manage users and policy.
                new AdminMenu(io, u, users, policy, auth).run();
                break;
            case DISPATCHER:
                // Create a DispatcherMenu and run it. Dispatchers can assign and update shipments.
                new DispatcherMenu(io, u, users, shipments).run();
                break;
            case CUSTOMER:
                // Create a CustomerMenu and run it. Customers can only see their own shipments.
                new CustomerMenu(io, u, users, shipments).run();
                break;
            case DELIVERY_PERSONNEL:
                // Create a DriverMenu and run it. Drivers can only see their assigned deliveries.
                new DriverMenu(io, u, shipments).run();
                break;
            default:
                // Should never happen with a well-formed Role enum, but handle it safely.
                io.error("Role not recognised.");
        }
        // After the menu's run() method returns (user logged out), we fall back to the main loop.
    }

    // ── doRegisterCustomer ────────────────────────────────────────────────────
    // Handles the self-registration flow for new customers.
    // Customers register themselves — admins register dispatchers and drivers separately.
    private void doRegisterCustomer(ConsoleUI io, UserRepository users, PasswordPolicy policy) {

        io.println("\n-- New Customer registration --"); // Print the section header.

        // ── STEP 1: Username ────────────────────────────────────────────────
        String username = io.prompt("Choose a username (3-20 letters/digits/._-): ");
        // Validate the format (letters, digits, ._-, 3-20 chars).
        if (!InputValidator.isValidUsername(username)) { io.error("Invalid username."); return; }
        // Check that nobody else already has this username.
        if (users.exists(username)) { io.error("Username already taken."); return; }

        // ── STEP 2: Full name ────────────────────────────────────────────────
        String fullName = io.prompt("Full name: ");
        // Validate: only letters and spaces, 2-50 characters.
        if (!InputValidator.isValidName(fullName)) { io.error("Invalid name."); return; }

        // ── STEP 3: ID number ───────────────────────────────────────────────
        String idNumber = io.prompt("ID number: ");
        // Validate: 4-15 digits only.
        if (!InputValidator.isValidId(idNumber)) { io.error("Invalid ID."); return; }

        // ── STEP 4: Contact number ──────────────────────────────────────────
        String contact = io.prompt("Contact number: ");
        // Validate: optional "+", then 7-15 digits.
        if (!InputValidator.isValidPhone(contact)) { io.error("Invalid phone."); return; }

        // ── STEP 5: Password ────────────────────────────────────────────────
        char[] pwd = io.promptPassword("Choose a password: ");
        // Check the password against the policy rules (length, uppercase, digits, etc.).
        // describeViolations() returns null if the password is acceptable.
        String violations = policy.describeViolations(pwd);
        if (violations != null) {
            // Print the specific violations so the user knows what to fix.
            io.println(violations);
            return; // Stop registration — they need to try again with a better password.
        }

        try {
            // Generate a new random salt and hash the password with PBKDF2.
            // sh[0] = Base64-encoded salt, sh[1] = Base64-encoded hash.
            String[] sh = PasswordHasher.hashWithNewSalt(pwd);

            // Create a new User object with:
            //   - the chosen username
            //   - Role.CUSTOMER (self-registered users are always customers)
            //   - the generated salt and hash
            //   - locked=false (account is active immediately)
            //   - failedAttempts=0 (fresh start)
            //   - the full name, ID, and contact number they entered
            User u = new User(username, Role.CUSTOMER, sh[0], sh[1], false, 0,
                    fullName, idNumber, contact);

            // Save the new user to users.dat.
            users.save(u);

            // Log the successful registration to audit.log.
            AuditLogger.log(username, "REGISTER_CUSTOMER", "OK");

            // Print a welcome message.
            io.println("Welcome, " + fullName + "! You can now log in.");

        } catch (Exception e) {
            // If anything went wrong (e.g. the hash function failed — very rare),
            // show an error message and log it.
            io.error("Registration failed: " + e.getMessage());
            AuditLogger.error("Customer registration failed", e);

        } finally {
            // "finally" ALWAYS runs — even if an exception occurred in the try block.
            // Wipe the password from memory immediately so it's not left in RAM.
            if (pwd != null) {
                java.util.Arrays.fill(pwd, '\0'); // Overwrite every char with '\0' (null byte).
            }
        }
    }
}
