// No package declaration — Jazzer requires the target class to be in default package
// or fully qualified via --target_class. Keeping it in default package for simplicity.

import com.code_intelligence.jazzer.api.FuzzedDataProvider;

import com.skyroute.shiptrack.auth.AuthService;
import com.skyroute.shiptrack.auth.AuthService.AuthOutcome;
import com.skyroute.shiptrack.auth.AuthService.AuthResult;
import com.skyroute.shiptrack.auth.PasswordHasher;
import com.skyroute.shiptrack.auth.PasswordPolicy;
import com.skyroute.shiptrack.model.Role;
import com.skyroute.shiptrack.model.User;
import com.skyroute.shiptrack.repository.UserRepository;
import com.skyroute.shiptrack.util.Constants;

import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.GeneralSecurityException;

/**
 * ============================================================
 * Q10 — Fuzz Testing  |  Feature 1: Login / Authentication
 * ============================================================
 *
 * Tool  : Jazzer (coverage-guided JVM fuzzer)
 * Target: AuthService.login()
 *         PasswordHasher.verify()
 *         PasswordPolicy.describeViolations()
 *
 * What this fuzzer verifies:
 *   - No method throws an unexpected exception for ANY byte sequence
 *   - login() always returns a non-null AuthResult
 *   - verify() always returns true/false (never throws) — Fail Securely
 *   - describeViolations() handles any char[] including garbage data
 *
 * Compile:
 *   javac -cp jazzer_standalone.jar;ShipTrack.jar LoginFuzzer.java
 *
 * Package:
 *   jar -cf LoginFuzzer.jar LoginFuzzer.class
 *
 * Run:
 *   jazzer --cp=ShipTrack.jar;LoginFuzzer.jar --target_class=LoginFuzzer -runs=10000
 */
public class LoginFuzzer {

    // Shared objects — initialised once, reused across all fuzz iterations
    private static AuthService    auth;
    private static PasswordPolicy policy;
    private static UserRepository userRepo;

    /**
     * fuzzerInitialize() is called ONCE by Jazzer before the fuzz loop starts.
     *
     * Sets up:
     *  - A clean data directory and users.dat
     *  - A PasswordPolicy with a very high lockout threshold (100,000) so the
     *    test account does not lock during the fuzz run and every authentication
     *    layer stays reachable
     *  - One known Customer account ("fuzzuser" / "TestPass1!") so the
     *    PBKDF2-verification layer (Layer 4) is exercised by correct-credential calls
     */
    public static void fuzzerInitialize() throws Exception {
        // Wipe leftover data from any previous run
        Files.createDirectories(Paths.get(Constants.DATA_DIR));
        Files.deleteIfExists(Paths.get(Constants.USERS_FILE));
        Files.deleteIfExists(Paths.get(Constants.AUDIT_LOG));
        Files.deleteIfExists(Paths.get(Constants.POLICY_FILE));

        // High maxLoginAttempts so the fuzz account is never locked mid-run
        policy = new PasswordPolicy();
        policy.setMaxLoginAttempts(100_000);

        userRepo = new UserRepository();           // bootstraps the default admin
        auth     = new AuthService(userRepo, policy);

        // Add a known test customer for Layer-4 (PBKDF2) coverage
        try {
            String[] sh = PasswordHasher.hashWithNewSalt("TestPass1!".toCharArray());
            User u = new User(
                    "fuzzuser", Role.CUSTOMER,
                    sh[0], sh[1],
                    false, 0,
                    "Fuzz User", "12345678", "+962700000000");
            userRepo.save(u);
        } catch (GeneralSecurityException e) {
            throw new RuntimeException("fuzzerInitialize: PBKDF2 unavailable", e);
        }

        System.out.println("[LoginFuzzer] Initialised. Test user: fuzzuser / TestPass1!");
    }

    /**
     * fuzzerTestOneInput() is called by Jazzer on every iteration with a
     * different random byte sequence derived from the fuzzer's corpus.
     *
     * Jazzer reports a FINDING if this method:
     *   - throws any uncaught exception
     *   - triggers a failed assert (-ea JVM flag enables assertions in Jazzer)
     *
     * Three targets are exercised per iteration using slices of the same
     * random byte stream, so every run covers all three functions.
     */
    public static void fuzzerTestOneInput(FuzzedDataProvider data) {

        // ==============================================================
        // Target 1 — PasswordHasher.verify()
        // ==============================================================
        // Security-critical: feeding it completely random / invalid Base64
        // strings must NEVER throw an exception.  It must always return
        // false for garbage input (Fail Securely, Ch.2).
        String fuzzSalt     = data.consumeString(64);
        String fuzzHash     = data.consumeString(64);
        String fuzzPassword = data.consumeString(256);

        // Must not throw — even for malformed Base64 or empty strings
        boolean verifyResult = PasswordHasher.verify(
                fuzzPassword.toCharArray(), fuzzSalt, fuzzHash);

        // Garbage salt/hash must never accidentally verify as true
        // (the probability is astronomically small, but we assert defensively)
        assert !(verifyResult && fuzzSalt.length() < 4 && fuzzHash.length() < 4)
                : "verify() returned true for obviously garbage input";

        // ==============================================================
        // Target 2 — PasswordPolicy.describeViolations()
        // ==============================================================
        // Must handle any char[] (null, empty, control chars, Unicode)
        // without throwing.  Returns null (compliant) or a message string.
        String policyInput = data.consumeString(512);
        String violations  = policy.describeViolations(policyInput.toCharArray());
        // No assertion on the VALUE — either null or a string is acceptable.
        // We are verifying it does not CRASH.

        // ==============================================================
        // Target 3 — AuthService.login()
        // ==============================================================
        // Must NEVER return null and NEVER throw any exception, regardless
        // of what random bytes arrive as username or password.
        String username = data.consumeString(30);
        String password = data.consumeString(100);

        AuthResult result = auth.login(username, password.toCharArray());

        // Structural invariants that must hold for every possible input
        assert result         != null : "login() must never return null";
        assert result.outcome != null : "AuthResult.outcome must never be null";
        assert result.message != null : "AuthResult.message must never be null";
        assert result.message.length() > 0 : "AuthResult.message must not be empty";

        // Semantic invariants
        if (result.outcome == AuthOutcome.OK) {
            assert result.user != null
                    : "User object must be present when outcome is OK";
        } else {
            assert result.user == null
                    : "User object must be null when outcome is not OK";
        }
    }
}
