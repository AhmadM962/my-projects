// No package declaration — Jazzer target class in default package.

import com.code_intelligence.jazzer.api.FuzzedDataProvider;

import com.skyroute.shiptrack.model.Shipment;
import com.skyroute.shiptrack.model.ShipmentStatus;

import java.time.format.DateTimeParseException;

/**
 * ============================================================
 * Q10 — Fuzz Testing  |  Feature 2: Shipment State Machine
 * ============================================================
 *
 * Tool  : Jazzer (coverage-guided JVM fuzzer)
 * Target: ShipmentStatus.fromString()
 *         Shipment.advanceTo()
 *         Shipment.fromRecord()
 *
 * What this fuzzer verifies:
 *   - fromString() either returns a valid status OR throws
 *     IllegalArgumentException — nothing else
 *   - advanceTo() NEVER throws for any ShipmentStatus value
 *     and correctly returns true/false per state-machine rules
 *   - fromRecord() handles any garbage string without crashing
 *     unexpectedly (only known, documented exceptions are allowed)
 *
 * No fuzzerInitialize() needed — all three targets are pure
 * in-memory functions with no file I/O.
 *
 * Compile:
 *   javac -cp jazzer_standalone.jar;ShipTrack.jar ShipmentFuzzer.java
 *
 * Package:
 *   jar -cf ShipmentFuzzer.jar ShipmentFuzzer.class
 *
 * Run:
 *   jazzer --cp=ShipTrack.jar;ShipmentFuzzer.jar --target_class=ShipmentFuzzer -runs=10000
 */
public class ShipmentFuzzer {

    /**
     * fuzzerTestOneInput() is called by Jazzer on every iteration.
     * A finding is reported if this method throws an unexpected exception
     * or triggers a failed assert.
     */
    public static void fuzzerTestOneInput(FuzzedDataProvider data) {

        // ==============================================================
        // Target 1 — ShipmentStatus.fromString()
        // ==============================================================
        // The method must either:
        //   (a) Return a non-null ShipmentStatus for any recognised input, OR
        //   (b) Throw IllegalArgumentException for any unrecognised input.
        // It must NEVER throw NullPointerException, ClassCastException,
        // StackOverflowError, or any other unplanned exception type.
        String statusInput = data.consumeString(80);
        try {
            ShipmentStatus parsed = ShipmentStatus.fromString(statusInput);

            // If parsing succeeded, result must be one of the four enum values
            assert parsed != null
                    : "fromString() must not return null on a successful parse";

            boolean isKnownValue = false;
            for (ShipmentStatus known : ShipmentStatus.values()) {
                if (known == parsed) { isKnownValue = true; break; }
            }
            assert isKnownValue
                    : "fromString() returned an unknown status constant: " + parsed;

        } catch (IllegalArgumentException e) {
            // Expected for unrecognised strings — Jazzer does NOT treat this as a finding
        }
        // Any other uncaught exception IS a finding.

        // ==============================================================
        // Target 2 — Shipment.advanceTo()
        // ==============================================================
        // Build a fresh PENDING shipment from fuzzed field values and
        // then try to advance it through every possible target status.
        //
        // advanceTo() must NEVER throw an exception — it is a boolean
        // state-machine gate that always returns true or false.
        // After a successful advance, the shipment's status must equal
        // the requested target.
        String id          = data.consumeString(20);
        String customer    = data.consumeString(30);
        String description = data.consumeString(200);

        Shipment s = Shipment.newRequest(id, customer, description);

        for (ShipmentStatus target : ShipmentStatus.values()) {
            ShipmentStatus before = s.getStatus();
            boolean moved         = s.advanceTo(target);  // must never throw

            if (before == target) {
                // Same-state transition must always be refused
                assert !moved
                        : "advanceTo() must return false when target == current status ("
                        + before + ")";
            }

            if (moved) {
                // Status must have actually changed to the target
                assert s.getStatus() == target
                        : "After advanceTo(" + target + ") returned true, "
                        + "status must be " + target + " but was " + s.getStatus();
            } else {
                // Rejected transition — status must be unchanged
                assert s.getStatus() == before
                        : "After advanceTo() returned false, status must be unchanged";
            }
        }

        // ==============================================================
        // Target 3 — Shipment.fromRecord()
        // ==============================================================
        // Feed random pipe-delimited strings as serialised records.
        // The method must either:
        //   (a) Parse successfully and return a valid Shipment, OR
        //   (b) Throw a documented exception type (IAE, AIOOB, or
        //       DateTimeParseException) for malformed input.
        // It must NEVER throw NullPointerException or any other
        // undocumented exception type.
        String record = data.consumeRemainingAsString();
        try {
            Shipment restored = Shipment.fromRecord(record);

            // Successful parse — all key fields must be present
            assert restored.getId()               != null : "Parsed id must not be null";
            assert restored.getCustomerUsername() != null : "Parsed customerUsername must not be null";
            assert restored.getStatus()           != null : "Parsed status must not be null";
            assert restored.getCreatedAt()        != null : "Parsed createdAt must not be null";
            assert restored.getDriverUsername()   != null : "Parsed driverUsername must not be null";

        } catch (IllegalArgumentException e) {
            // Expected: bad status name or wrong field count
        } catch (ArrayIndexOutOfBoundsException e) {
            // Expected: fewer fields than required
        } catch (DateTimeParseException e) {
            // Expected: createdAt field is not a valid ISO date-time string
        }
        // NullPointerException or any other type would NOT be caught here
        // and would be reported by Jazzer as a finding.
    }
}
