// ======================================
// model.js (FIXED TREE WALK FOR XGBOOST JSON DUMP)
// - Loads url_model_dump.json (array of JSON strings OR array of objects)
// - Loads model_metadata.json (features, threshold, base_score, etc.)
// - Predicts P(legit) for URL-only feature vectors
// ======================================

// NOTE: If you are NOT using "type": "module" in manifest, do NOT use `export`.
// Use window.PhishGuardModel = { loadModel, predictLegitProba } at the bottom.

let _model = null;

function sigmoid(x) {
  return 1 / (1 + Math.exp(-x));
}

// XGBoost dump sometimes is array of JSON strings; sometimes already parsed objects.
function normalizeTrees(rawTrees) {
  return rawTrees.map(t => (typeof t === "string" ? JSON.parse(t) : t));
}

function buildNodeMap(treeObj) {
  const map = new Map();

  function visit(node) {
    map.set(node.nodeid, node);
    if (node.children && Array.isArray(node.children)) {
      for (const ch of node.children) visit(ch);
    }
  }

  // Some dumps wrap nodes under an array; others are single root object
  if (Array.isArray(treeObj)) {
    for (const root of treeObj) visit(root);
  } else {
    visit(treeObj);
  }

  return map;
}

function getRootNodeId(treeObj) {
  // Root is nodeid=0 in standard XGBoost dumps
  // but if wrapped, first element is root.
  if (Array.isArray(treeObj)) return treeObj[0]?.nodeid ?? 0;
  return treeObj.nodeid ?? 0;
}

function walkTree(tree, nodeMap, rootId, featIndex, x) {
  let nid = rootId;

  while (true) {
    const node = nodeMap.get(nid);
    if (!node) {
      throw new Error(`Tree traversal failed: missing nodeid=${nid}`);
    }

    // Leaf?
    if (Object.prototype.hasOwnProperty.call(node, "leaf")) {
      return node.leaf;
    }

    // Internal split node
    const splitName = node.split; // feature name, e.g. "URLLength"
    const fIdx = featIndex.get(splitName);
    const val = (fIdx === undefined) ? NaN : x[fIdx];

    const isMissing = val === undefined || val === null || Number.isNaN(val);

    // For numeric split: go "yes" if val < split_condition
    // (XGBoost uses "<" for 'yes' branch in dumps)
    let nextId;
    if (isMissing) {
      nextId = node.missing;
    } else {
      nextId = (val < node.split_condition) ? node.yes : node.no;
    }

    nid = nextId;
  }
}

function toFeatureVector(features, featureNames) {
  // features can be:
  // 1) Array in correct order
  // 2) Object {featName: value}
  if (Array.isArray(features)) return features.map(v => Number(v) || 0);

  const x = new Array(featureNames.length).fill(0);
  for (let i = 0; i < featureNames.length; i++) {
    const k = featureNames[i];
    const v = features[k];
    x[i] = (v === undefined || v === null) ? 0 : Number(v);
    if (Number.isNaN(x[i])) x[i] = 0;
  }
  return x;
}

async function loadModel() {
  const modelUrl = chrome.runtime.getURL("assets/url_model_dump.json");
  const metaUrl  = chrome.runtime.getURL("assets/model_metadata.json");

  const [modelRes, metaRes] = await Promise.all([fetch(modelUrl), fetch(metaUrl)]);
  if (!modelRes.ok) throw new Error(`Failed to load model dump: ${modelRes.status}`);
  if (!metaRes.ok) throw new Error(`Failed to load metadata: ${metaRes.status}`);

  const rawTrees = await modelRes.json();
  const meta = await metaRes.json();

  const trees = normalizeTrees(rawTrees);

  // Build per-tree node maps for fast inference
  const compiled = trees.map(treeObj => {
    const nodeMap = buildNodeMap(treeObj);
    const rootId  = getRootNodeId(treeObj);
    return { treeObj, nodeMap, rootId };
  });

  const featureNames = meta.features_url_only || meta.features || [];
  if (!featureNames.length) throw new Error("Metadata missing feature list.");

  const featIndex = new Map(featureNames.map((f, i) => [f, i]));

  _model = {
    meta,
    featureNames,
    featIndex,
    compiled,
    baseScore: (meta.base_score !== undefined ? meta.base_score : 0.5), // probability
    // Convert base_score prob -> margin
    baseMargin: (meta.base_margin !== undefined)
      ? meta.base_margin
      : Math.log(( (meta.base_score ?? 0.5) / (1 - (meta.base_score ?? 0.5)) )),
    thresholdLegit: meta.threshold_legit ?? meta.threshold ?? 0.5,
  };

  return _model;
}

function predictLegitProba(features) {
  if (!_model) throw new Error("Model not loaded. Call loadModel() first.");

  const x = toFeatureVector(features, _model.featureNames);

  // Sum leaves to get margin
  let margin = _model.baseMargin;

  for (const t of _model.compiled) {
    margin += walkTree(t.treeObj, t.nodeMap, t.rootId, _model.featIndex, x);
  }

  // Objective is binary:logistic => sigmoid(margin) gives P(class=1)=P(legit)
  return sigmoid(margin);
}

// ======= Export for your extension =======
// If manifest uses "type": "module", you can export.
window.PhishGuardModel = { loadModel, predictLegitProba };

// If NOT using modules, comment out export above and instead do:
// window.PhishGuardModel = { loadModel, predictLegitProba };
