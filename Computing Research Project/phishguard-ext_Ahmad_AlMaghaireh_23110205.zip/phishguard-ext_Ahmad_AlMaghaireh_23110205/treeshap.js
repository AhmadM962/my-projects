// treeshap.js (no modules)
// Exposes window.PhishGuardSHAP

(() => {
  function treeShapSingle(tree, x, featureIndex, phi) {
    function walk(node, path) {
      if (node.leaf !== undefined) {
        if (path.length === 0) return;
        const contrib = node.leaf / path.length;
        for (const feat of path) phi[feat] += contrib;
        return;
      }

      const f = node.split;
      const idx = featureIndex.get(f);
      const v = (idx !== undefined) ? x[idx] : 0.0;

      const goLeft = v < node.split_condition;

      const yesId = node.yes;
      const noId = node.no;
      const children = node.children || [];

      const left = children.find(c => c.nodeid === yesId) || children[0];
      const right = children.find(c => c.nodeid === noId) || children[1];

      walk(goLeft ? left : right, path.concat([f]));
    }

    walk(tree, []);
  }

  function computeTreeShap(model, x) {
    const phi = {};
    for (const f of model.meta.features) phi[f] = 0.0;
    for (const tree of model.trees) {
      treeShapSingle(tree, x, model._featureIndex, phi);
    }
    return phi;
  }

  window.PhishGuardSHAP = { computeTreeShap };
})();
