// =======================
// PhishGuard content script
// =======================

let MODEL = null;

// Tooltip
const tooltip = document.createElement("div");
tooltip.className = "phishguard-tooltip";
document.documentElement.appendChild(tooltip);

function showTooltip(x, y, html) {
  tooltip.innerHTML = html;
  const pad = 14;
  tooltip.style.left = Math.min(x + pad, window.innerWidth - 420) + "px";
  tooltip.style.top = Math.min(y + pad, window.innerHeight - 220) + "px";
  tooltip.classList.add("show");
}
function hideTooltip() {
  tooltip.classList.remove("show");
}

// Fetch model from service worker
async function getModel() {
  if (MODEL) return MODEL;
  const resp = await chrome.runtime.sendMessage({ type: "PHISHGUARD_GET_MODEL" });
  if (!resp?.ok) throw new Error("Failed to load model");
  MODEL = resp.model;

  // Parse each tree JSON string into object
  MODEL.trees = MODEL.dump.map((s) => JSON.parse(s));
  return MODEL;
}

// -----------------------
// URL feature extraction
// -----------------------
function charContinuationRate(s) {
  if (!s || s.length < 2) return 0.0;
  let same = 0;
  for (let i = 1; i < s.length; i++) if (s[i] === s[i - 1]) same++;
  return same / (s.length - 1);
}

function extractFeatures(url, meta) {
  const feats = {};
  const u = (url || "").trim();
  feats.URLLength = u.length;
  feats.IsHTTPS = u.toLowerCase().startsWith("https://") ? 1 : 0;

  const m = u.toLowerCase().match(/^https?:\/\/([^/]+)/);
  const host = m ? m[1] : "";
  feats.DomainLength = host.length;
  feats.NoOfSubDomain = Math.max((host.match(/\./g) || []).length - 1, 0);

  // IP check
  feats.IsDomainIP = /^(?:\d{1,3}\.){3}\d{1,3}$/.test(host) ? 1 : 0;

  // TLD
  const tld = host.includes(".") ? host.split(".").pop() : "";
  feats.TLDLength = tld.length;

  // TLD_freq
  const map = meta.tld_freq_map || {};
  feats.TLD_freq = map[tld] ? Number(map[tld]) : 0.0;

  // char counts
  feats.NoOfLettersInURL = (u.match(/[a-zA-Z]/g) || []).length;
  feats.NoOfDegitsInURL = (u.match(/\d/g) || []).length;

  const allowed = new Set([":", "/", ".", "-", "_", "?", "=", "&", "%"]);
  let otherSpecial = 0;
  for (const ch of u) {
    const isAlnum = /[a-z0-9]/i.test(ch);
    if (!isAlnum && !allowed.has(ch)) otherSpecial++;
  }
  feats.NoOfOtherSpecialCharsInURL = otherSpecial;

  feats.NoOfQMarkInURL = (u.match(/\?/g) || []).length;
  feats.NoOfEqualsInURL = (u.match(/=/g) || []).length;
  feats.NoOfAmpersandInURL = (u.match(/&/g) || []).length;

  const obf = (u.match(/%[0-9a-fA-F]{2}/g) || []).length;
  feats.NoOfObfuscatedChar = obf;
  feats.HasObfuscation = obf > 0 ? 1 : 0;

  const L = Math.max(u.length, 1);
  feats.LetterRatioInURL = feats.NoOfLettersInURL / L;
  feats.DegitRatioInURL = feats.NoOfDegitsInURL / L;
  feats.SpacialCharRatioInURL = feats.NoOfOtherSpecialCharsInURL / L;
  feats.ObfuscationRatio = feats.NoOfObfuscatedChar / L;

  feats.CharContinuationRate = charContinuationRate(u);

  // Build vector in correct order
  const x = meta.features.map((f) => Number(feats[f] ?? 0.0));
  return { feats, x };
}

// -----------------------
// XGBoost tree evaluator
// (works with get_dump("json"))
// -----------------------
function evalNode(node, x, featureIndex) {
  // leaf
  if (node.leaf !== undefined) return node.leaf;

  const fName = node.split;
  const idx = featureIndex.get(fName);
  const val = idx !== undefined ? x[idx] : 0.0;

  // XGBoost uses: go left if val < split_condition
  if (val < node.split_condition) {
    return evalNode(node.children[0], x, featureIndex);
  } else {
    return evalNode(node.children[1], x, featureIndex);
  }
}

function sigmoid(z) {
  return 1 / (1 + Math.exp(-z));
}

function predictRaw(model, x) {
  const featureIndex = model._featureIndex;
  let raw = 0.0;
  for (const tree of model.trees) raw += evalNode(tree, x, featureIndex);
  raw += 0.0; // base_score already inside dumps for most models; keep 0 here
  return raw;
}

function predict(model, x) {
  const raw = predictRaw(model, x);
  const pLegit = sigmoid(raw);            // model trained as P(legit)
  const pPhish = 1.0 - pLegit;
  return { raw, pLegit, pPhish };
}

// -----------------------
// Explanation (fast, browser-friendly)
// We’ll use "global_shap_rank" + actual feature values as a clear explanation.
// Step 3 can upgrade to full TreeSHAP local explanations.
// -----------------------
function explain(model, feats) {
  const top = (model.meta.global_shap_rank || []).slice(0, 3);
  const items = top.map((it) => {
    const f = it.feature;
    const v = feats[f];
    return `<li><b>${f}</b> = ${Number(v ?? 0).toFixed(3)}</li>`;
  }).join("");

  return `
    <div class="title">PhishGuard Explanation</div>
    <div class="small">Top influential features (global SHAP) for this model:</div>
    <ul>${items}</ul>
    <div class="small" style="margin-top:8px;opacity:.85;">
      Note: This is a fast explanation. Step 3 can upgrade to exact local SHAP.
    </div>
  `;
}

// -----------------------
// Main: underline risky URLs
// -----------------------
async function run() {
  const model = await getModel();

  // Precompute feature index map
  model._featureIndex = new Map(model.meta.features.map((f, i) => [f, i]));

  const thresholdLegit = Number(model.meta.threshold_legit ?? 0.5);

  // scan links
  const links = Array.from(document.querySelectorAll("a[href]"));
  for (const a of links) {
    const href = a.href;
    if (!href || !href.startsWith("http")) continue;

    const { feats, x } = extractFeatures(href, model.meta);
    const { pLegit, pPhish } = predict(model, x);

    // Mark phishing if P(legit) < threshold
    const isPhish = pLegit < thresholdLegit;

    if (isPhish) {
      a.classList.add("phishguard-underline");

      a.addEventListener("mouseenter", (ev) => {
        const html = `
          <div class="title">⚠️ Suspicious URL</div>
          <div class="small"><b>P(phish):</b> ${(pPhish * 100).toFixed(2)}% &nbsp; | &nbsp;
          <b>P(legit):</b> ${(pLegit * 100).toFixed(2)}%</div>
          ${explain(model, feats)}
        `;
        showTooltip(ev.clientX, ev.clientY, html);
      });

      a.addEventListener("mousemove", (ev) => {
        tooltip.style.left = Math.min(ev.clientX + 14, window.innerWidth - 420) + "px";
        tooltip.style.top = Math.min(ev.clientY + 14, window.innerHeight - 220) + "px";
      });

      a.addEventListener("mouseleave", hideTooltip);
    }
  }
}

run().catch((e) => console.error("PhishGuard error:", e));
