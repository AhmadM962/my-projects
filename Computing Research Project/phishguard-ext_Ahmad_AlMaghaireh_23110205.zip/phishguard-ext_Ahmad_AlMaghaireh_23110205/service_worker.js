let MODEL = null;

async function loadModelOnce() {
  if (MODEL) return MODEL;

  const metaUrl = chrome.runtime.getURL("model/model_metadata.json");
  const dumpUrl = chrome.runtime.getURL("model/url_model_dump.json");

  const [metaRes, dumpRes] = await Promise.all([fetch(metaUrl), fetch(dumpUrl)]);
  const [meta, dump] = await Promise.all([metaRes.json(), dumpRes.json()]);

  MODEL = {
    meta,
    dump // array of JSON strings (each tree)
  };

  console.log("PhishGuard model loaded:", {
    trees: dump.length,
    features: meta.features.length
  });

  return MODEL;
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  (async () => {
    if (msg?.type === "PHISHGUARD_GET_MODEL") {
      const model = await loadModelOnce();
      sendResponse({ ok: true, model });
    } else {
      sendResponse({ ok: false });
    }
  })();
  return true;
});
